﻿const express = require('express');
const router = express.Router();

// Basic billing routes (placeholder)
router.get('/billing', (req, res) => {
  res.send('Billing page');
});

module.exports = router;
