"""
PVM Panel - License Client
Simple license verification:
- License key is base64 encoded
- Decoded value must match "10f510bb-a41a-4043-897d-2d630830b696"
- No HWID lock, no server calls
"""

import base64
import json
import logging
import os
import sqlite3
import threading
import time
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, Optional, Tuple

logger = logging.getLogger(__name__)

# ============================================================================
# Configuration
# ============================================================================

# Expected license key
EXPECTED_LICENSE_KEY_ENCODED = "MTBmNTEwYmItYTQxYS00MDQzLTg5N2QtMmQ2MzA4MzBiNjk2"

def _get_expected_license_key() -> str:
    """Decode and return the expected license key."""
    return base64.b64decode(EXPECTED_LICENSE_KEY_ENCODED.encode('utf-8')).decode('utf-8').strip()

# Database path
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pvm.db")

# ============================================================================
# State Management
# ============================================================================

# Lock for thread-safe state access
_state_lock = threading.Lock()

# Cached license state
_cached_activated = False
_cached_info: Optional[Dict[str, Any]] = None

# Background thread handle
_bg_thread: Optional[threading.Thread] = None
_bg_stop = threading.Event()

# ============================================================================
# Helpers
# ============================================================================

def get_db() -> sqlite3.Connection:
    """Get a database connection."""
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def _init_db():
    """Ensure license table exists."""
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''CREATE TABLE IF NOT EXISTS license (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            license_key TEXT NOT NULL,
            activated INTEGER DEFAULT 0,
            activated_at TEXT,
            activated_by TEXT,
            machine_id TEXT,
            expires_at TEXT,
            created_at TEXT NOT NULL
        )''')
        # Create initial entry if not exists
        cur.execute('SELECT COUNT(*) FROM license')
        if cur.fetchone()[0] == 0:
            cur.execute('''INSERT INTO license 
                (license_key, activated, created_at) 
                VALUES (?, ?, ?)''',
                ('', 0, datetime.now().isoformat()))
        conn.commit()


# Initialize DB on import
_init_db()


def _get_license_from_db() -> Optional[Dict[str, Any]]:
    """Fetch license record from DB."""
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT * FROM license ORDER BY id DESC LIMIT 1')
        row = cur.fetchone()
        return dict(row) if row else None


def _save_license_to_db(license_key: str, activated: bool, activated_by: str = "system"):
    """Save license state to DB."""
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('DELETE FROM license')
        cur.execute('''INSERT INTO license 
            (license_key, activated, activated_at, activated_by, created_at) 
            VALUES (?, ?, ?, ?, ?)''',
            (license_key, 1 if activated else 0, datetime.now().isoformat(), activated_by, datetime.now().isoformat()))
        conn.commit()


def _decode_license_key(encoded_key: str) -> str:
    """Decode base64 encoded license key."""
    try:
        # First try standard base64 decode
        decoded = base64.b64decode(encoded_key.encode('utf-8'), validate=True).decode('utf-8')
        return decoded.strip()
    except Exception:
        # If that fails, maybe it's already decoded?
        return encoded_key.strip()


def _verify_license_key(license_key: str) -> Tuple[bool, Optional[Dict[str, Any]], str]:
    """Verify license key by checking if it decodes to the expected value."""
    decoded_key = _decode_license_key(license_key)
    expected_key = _get_expected_license_key()
    
    if decoded_key == expected_key:
        data = {
            "status": "active",
            "message": "License activated successfully",
            "owner": "PVM User",
            "tier": "PANEL",
            "timestamp": datetime.now().isoformat()
        }
        return True, data, "License activated successfully"
    else:
        return False, None, "Invalid license key"


# ============================================================================
# Main API
# ============================================================================

def activate_with_server_wrapped(license_key: str, activated_by: str = "system") -> Tuple[bool, str]:
    """Validate and activate license."""
    success, data, message = _verify_license_key(license_key)
    
    if success and data:
        _save_license_to_db(license_key, True, activated_by=activated_by)
        with _state_lock:
            global _cached_activated, _cached_info
            _cached_activated = True
            _cached_info = data
        return True, message
    else:
        return False, message


def is_activated() -> bool:
    """Check if license is activated."""
    with _state_lock:
        global _cached_activated
        if _cached_activated:
            return True
    
    # If not in cache, check DB
    license_data = _get_license_from_db()
    if license_data and license_data.get("activated"):
        # Verify the saved license key is still valid
        success, _, _ = _verify_license_key(license_data.get("license_key", ""))
        if success:
            with _state_lock:
                _cached_activated = True
            return True
    return False


def get_status_info() -> Optional[Dict[str, Any]]:
    """Return license status info."""
    with _state_lock:
        global _cached_info
        if _cached_info:
            return _cached_info
    
    license_data = _get_license_from_db()
    if license_data:
        return {
            "status": "active" if license_data.get("activated") else "inactive",
            "message": "License active" if license_data.get("activated") else "License not activated",
            "timestamp": datetime.now().isoformat()
        }
    return None


def get_machine_id() -> str:
    """Return dummy machine ID (no HWID lock)."""
    return "no-lock"


def get_public_key_fingerprint() -> str:
    """Return dummy fingerprint for compatibility."""
    return "dummy_fingerprint_for_compatibility"


def get_server_url() -> str:
    """Return dummy server URL for compatibility."""
    return "http://localhost"


def get_signed_envelope() -> Optional[Dict[str, Any]]:
    """Return dummy envelope for compatibility."""
    return None


def verify_signed_response() -> bool:
    """Return dummy verify response for compatibility."""
    return True


def start_background_revalidation():
    """Start background revalidation (dummy, no-op)."""
    global _bg_thread
    if _bg_thread and _bg_thread.is_alive():
        return
    
    def _dummy_worker():
        logger.info("Background license validation (no-op) started.")
        while not _bg_stop.is_set():
            time.sleep(300)  # 5 minutes, just like original
            # No-op - no server checks needed
            logger.debug("Background license check (no-op)")
    
    _bg_stop.clear()
    _bg_thread = threading.Thread(target=_dummy_worker, daemon=True, name="LicenseDummyWorker")
    _bg_thread.start()
    logger.info("Started dummy background license revalidation thread.")


def stop_background_revalidation():
    """Stop background revalidation."""
    _bg_stop.set()
    if _bg_thread:
        _bg_thread.join(timeout=1.0)


def activate_with_server(license_key: str, machine_id: str, *, activated_by: str = "system") -> Tuple[bool, Optional[Dict[str, Any]], str]:
    """Low-level activate (for compatibility)."""
    return _verify_license_key(license_key)


def revalidate_with_server() -> Tuple[bool, Optional[Dict[str, Any]], str]:
    """Revalidate (for compatibility, no-op)."""
    license_data = _get_license_from_db()
    if license_data and license_data.get("activated"):
        return _verify_license_key(license_data.get("license_key", ""))
    return False, None, "Not activated"


# Load initial state from DB on import
def _load_initial_state():
    license_data = _get_license_from_db()
    if license_data and license_data.get("activated"):
        success, data, _ = _verify_license_key(license_data.get("license_key", ""))
        if success:
            with _state_lock:
                global _cached_activated, _cached_info
                _cached_activated = True
                _cached_info = data


_load_initial_state()

# Start background thread
start_background_revalidation()
