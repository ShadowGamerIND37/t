#!/bin/bash

# PMS Wings Installer
# Version: 1.0
# Author: Your Name

set -e  # Exit on error
set -o pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Functions
print_info() {
    echo -e "${CYAN}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if user is root
if [[ $EUID -ne 0 ]]; then
   print_error "This script must be run as root"
   exit 1
fi

print_info "Welcome to the Wings Installer!"
echo ""

# Check if we have Wings source code in /root or current directory
SOURCE_DIR=""
if [ "$PWD" = "/root" ] && [ -f "wings.go" ]; then
    SOURCE_DIR="/root"
    print_info "Found Wings source code in /root"
elif [ -f "wings.go" ]; then
    SOURCE_DIR="$PWD"
    print_info "Found Wings source code in $PWD"
fi

# Update system
print_info "Updating system packages..."
apt update -y && apt upgrade -y

# Install dependencies
print_info "Installing required dependencies..."
apt install -y curl tar

# Install Docker
print_info "Installing Docker..."
if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com | sudo bash -
fi

# Check if we need to compile or download
if [ -n "$SOURCE_DIR" ]; then
    print_info "Compiling Wings from source code..."
    apt install -y golang
    cd "$SOURCE_DIR"
    make wings
    cp wings /usr/local/bin/
else
    print_info "Downloading Wings..."
    cd /usr/local/bin
    curl -L -o wings https://github.com/pterodactyl/wings/releases/latest/download/wings_linux_amd64
    chmod +x wings
fi

# Create required directories
print_info "Creating required directories..."
mkdir -p /etc/pterodactyl
mkdir -p /var/lib/pms/volumes
mkdir -p /var/run/wings

print_warning ""
print_warning "========================================"
print_warning "  Next Steps:"
print_warning "========================================"
print_warning ""
print_warning "1. Create a node in your PMS Panel"
print_warning "2. Download the config.yml from the node page"
print_warning "3. Upload the config.yml to /etc/pterodactyl/config.yml"
print_warning ""
print_warning "Then run:"
print_warning "  systemctl daemon-reload"
print_warning "  systemctl enable wings"
print_warning "  systemctl start wings"
print_warning ""

# Create systemd service file (only if it doesn't exist)
if [ ! -f /etc/systemd/system/wings.service ]; then
    print_info "Creating systemd service..."
    cat > /etc/systemd/system/wings.service << 'EOF'
[Unit]
Description=Wings Daemon
After=docker.service
Requires=docker.service
PartOf=docker.service

[Service]
User=root
WorkingDirectory=/etc/pterodactyl
LimitNOFILE=4096
PIDFile=/var/run/wings/wings.pid
ExecStart=/usr/local/bin/wings
Restart=on-failure
StartLimitInterval=180
StartLimitBurst=30
RestartSec=5s

[Install]
WantedBy=multi-user.target
EOF
fi

print_success "Wings installation complete!"
