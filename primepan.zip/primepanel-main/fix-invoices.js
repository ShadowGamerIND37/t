const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./database.db');

console.log('Fixing invoices table...');
db.run('ALTER TABLE invoices ADD COLUMN description TEXT', function(err) {
    if (err) {
        if (!err.message.includes('duplicate column name')) {
            console.error('Error:', err.message);
        } else {
            console.log('✓ Column already exists');
        }
    } else {
        console.log('✓ Added description column to invoices');
    }
    db.close();
});
