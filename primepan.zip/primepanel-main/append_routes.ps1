$outputPath = "C:\Users\Mithun\Downloads\archive_name\panel\backend\routes\servers.js"

$routes = @'

    // ================================================
    // SERVER ROUTES - DASHBOARD
    // ================================================

    app.get('\''/servers/:id/dashboard'\'', requireAuth, async (req, res) => {
      try {
          const serverId = req.params.id;
          if (!await isAuthorized(req, serverId)) {
              return res.status(403).send('\''Access denied'\'');
          }
          const server = await dbGet(`\n            SELECT s.*, \n                   a.ip AS allocation_ip, a.alias AS allocation_alias, a.port AS allocation_port,\n                   n.name AS node_name, n.maintenance_mode AS node_maintenance_mode\n            FROM servers s\n            LEFT JOIN allocations a ON s.id = a.server_id\n            LEFT JOIN nodes n ON s.node_id = n.id\n            WHERE s.id = ?\n          `\', [serverId]);
          if (!server) {
              return res.status(404).send('\''Server not found'\'');
          }
          
          if (server.node_maintenance_mode === 1) {
              return res.status(403).render('\''error'\'', await getTemplateVars(req, null, { 
                  message: '\''This node is currently in maintenance mode. Please try again later.'\'', 
                  status: 403, 
                  title: '\''Maintenance Mode'\'' 
              }));
          }
          let uptime = '\''Offline'\'';
          let uptimeSeconds = 0;
          let cpu = '\''N/A'\'';
          let memory = '\''N/A'\'';
          let onlineCount = 0;
          const running = await isServerRunning(serverId);
          
          if (running) {
              let startTime = serverStartTimes[serverId];
              if (!startTime) {
                  startTime = loadServerStartTime(serverId);
                  if (startTime) {
                      serverStartTimes[serverId] = startTime;
                      console.log(`\''Loaded start time from file for server ${serverId} in dashboard route'\'`);
                  }
              }
              
              if (startTime) {
                  const diff = Date.now() - startTime;
                  uptimeSeconds = Math.floor(diff / 1000);
                  const days = Math.floor(diff / 86400000);
                  const hrs = Math.floor((diff % 86400000) / 3600000);
                  const mins = Math.floor((diff % 3600000) / 60000);
                  const secs = Math.floor((diff % 60000) / 1000);
                  
                  if (days > 0) {
                      uptime = `${days}d ${hrs}h ${mins}m`\';
                  } else if (hrs > 0) {
                      uptime = `${hrs}h ${mins}m ${secs}s`\';
                  } else if (mins > 0) {
                      uptime = `${mins}m ${secs}s`\';
                  } else {
                      uptime = `${secs}s`\';
                  }
              } else {
                  uptime = '\''Unknown'\'';
              }
              
              const pid = await getPidByPort(server.port);
              if (pid) {
                try {
                  const stats = await pidusage(pid);
                  cpu = stats.cpu.toFixed(1);
                  memory = (stats.memory / 1024 / 1024).toFixed(1);
                } catch (e) {
                  console.error('\''Pidusage error:'\'', e);
                }
              }
          }
          onlineCount = (onlinePlayers[serverId] && onlinePlayers[serverId].length) || 0;
          let logContent = '\'''\'';
          const logPath = path.join(SERVERS_DIR, serverId.toString(), '\''logs'\'', '\''latest.log'\'');
          if (fs.existsSync(logPath)) {
              try {
                  const stats = fs.statSync(logPath);
                  const maxRead = 100 * 1024;
                  const readLength = Math.min(stats.size, maxRead);
                  const buffer = Buffer.alloc(readLength);
                  const fd = fs.openSync(logPath, '\''r'\'');
                  fs.readSync(fd, buffer, 0, readLength, stats.size - readLength);
                  logContent = buffer.toString('\''utf8'\'');
                  fs.closeSync(fd);
              } catch {}
          }
          const allServers = await dbAll('\''SELECT * FROM servers'\'');
          const totalServers = allServers.length;
          res.render('\''servers/dashboard'\'', await getTemplateVars(req, server, {
              uptime,
              cpu,
              memory,
              logContent,
              onlineCount,
              totalServers,
              onlinePlayers: onlinePlayers[serverId] || [],
              currentPage: '\''dashboard'\'',
              activePage: '\''dashboard'\'',
              query: req.query,
              liveStats: liveStats[serverId] || {},
              title: `${server.name} - Dashboard`\'
          }));
      } catch (err) {
          console.error('\''Server dashboard error:'\'', err);
          res.status(500).send('\''Failed to load dashboard'\'');
      }
    });
'@

Add-Content -Path $outputPath -Value $routes
Write-Host "Dashboard route appended"
