const fs = require('fs');
const code = fs.readFileSync('./backend/routes/servers.js', 'utf8');

// Track brace depth with proper comment/string/template/regex handling
// Strategy: strip comments, then count braces in the remaining code
function stripCommentsAndStrings(code) {
  let result = '';
  let i = 0;
  const len = code.length;

  while (i < len) {
    const c = code[i];
    const n = i + 1 < len ? code[i + 1] : '';
    
    // Line comment
    if (c === '/' && n === '/') {
      while (i < len && code[i] !== '\n') result += ' '; // skip rest of line
      if (i < len && code[i] === '\n') result += '\n';
      continue;
    }
    
    // Block comment
    if (c === '/' && n === '*') {
      result += '  ';
      i += 2;
      while (i < len && !(code[i] === '*' && code[i+1] === '/')) {
        if (code[i] === '\n') result += '\n';
        else result += ' ';
        i++;
      }
      if (i < len) { result += '  '; i += 2; }
      continue;
    }
    
    // String literal
    if (c === '"' || c === "'") {
      const quote = c;
      result += quote;
      i++;
      while (i < len && code[i] !== quote) {
        if (code[i] === '\\') { result += '\\\\'; i += 2; continue; }
        if (code[i] === '\n') { result += '\n'; i++; break; } // unterminated string
        result += ' ';
        i++;
      }
      if (i < len) { result += quote; i++; }
      continue;
    }
    
    // Template literal
    if (c === '`') {
      result += '`';
      i++;
      let tDepth = 0;
      while (i < len && !(code[i] === '`' && tDepth === 0)) {
        if (code[i] === '\\') { result += '\\\\'; i += 2; continue; }
        if (code[i] === '$' && code[i+1] === '{') {
          result += '{{';
          i += 2;
          tDepth++;
          continue;
        }
        if (code[i] === '}' && tDepth > 0) {
          // This } might close the template expr, or might be part of deeper nested
          // Count nesting by tracking } that match template ${
          result += '}';
          i++;
          tDepth--; // This is approximate - may not be right for nested templates
          continue;
        }
        if (code[i] === '\n') result += '\n';
        else result += ' ';
        i++;
      }
      if (i < len) { result += '`'; i++; }
      continue;
    }
    
    // Regex literal - tricky, just output the char as-is
    if (c === '/' && i > 0) {
      // Check if this is a division or regex start - simplified heuristic
      // If preceded by operator/certain keywords, it's likely regex
      const pre = result.trimEnd();
      if (pre.length > 0 && '=(,[!&|?:;{'.includes(pre[pre.length-1])) {
        // Regex literal
        result += '/';
        i++;
        while (i < len && code[i] !== '/') {
          if (code[i] === '\\') { result += '/'; i += 2; continue; }
          result += ' ';
          i++;
        }
        if (i < len) { result += '/'; i++; } // closing /
        // Skip flags
        while (i < len && /[gimsuyd]/.test(code[i])) { result += code[i]; i++; }
        continue;
      }
    }
    
    result += c;
    i++;
  }
  return result;
}

const stripped = stripCommentsAndStrings(code);
const strippedLines = stripped.split('\n');

// Count braces in stripped code
let depth = 0;
let lineDepths = [];

for (let lineIdx = 0; lineIdx < strippedLines.length; lineIdx++) {
  const line = strippedLines[lineIdx];
  for (const c of line) {
    if (c === '{') depth++;
    if (c === '}') depth--;
  }
  lineDepths.push({line: lineIdx + 1, depth, text: code.split('\n')[lineIdx]?.trim().substring(0, 80) || ''});
}

console.log('Final depth:', depth);

// Find lines where depth has net positive (unmatched opens at module level)
// Expected depth pattern:
// Lines 1-24 (top-level): depth 0
// Line 24 (module.exports = ...): depth 1  
// Through all routes: depth varies but returns to 1 at certain points
// Line 5091 (};): depth 0

console.log('\nDepth trace from line 5070:');
for (let i = 5069; i < lineDepths.length; i++) {
  console.log(`${lineDepths[i].line}: d=${lineDepths[i].depth} ${lineDepths[i].text}`);
}

console.log('\n\nLooking for structural patterns...');
// Find where depth is 1 (expected baseline in module body)
// At route boundaries, depth should be 1 before app.get/post (module body level)
// After route's });, depth should return to 1
for (let i = 0; i < lineDepths.length; i++) {
  const ld = lineDepths[i];
  // Check if line ends with }); and depth is wrong
  if (ld.text.trim().startsWith('});') && ld.depth !== 1 && i > 10) {
    // This might be at the end of a route handler
    console.log(`Route close at line ${ld.line}: depth=${ld.depth}, "${ld.text}"`);
  }
}
