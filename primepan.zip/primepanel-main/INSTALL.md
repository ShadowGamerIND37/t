# PMS Panel Installation Guide

## Automatic Installation (One-Liner)

```bash
bash <(curl -s https://example.com/install.sh)
```

## Manual Installation

### Prerequisites
- Ubuntu 20.04+ or Debian 11+
- Node.js 18+
- npm

### Step 1: Install Dependencies

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Java (for Minecraft servers)
sudo apt install openjdk-21-jdk -y

# Install Node.js 23
curl -sL https://deb.nodesource.com/setup_23.x | sudo bash -
sudo apt install -y nodejs

# Verify installations
java -version
node -v
npm -v
```

### Step 2: Download PMS Panel

```bash
# Create directory
mkdir -p /var/www/pms
cd /var/www/pms

# Download the panel (replace with your actual download URL)
# git clone https://github.com/yourusername/pms-panel.git .
# Or upload your files
```

### Step 3: Install Panel Dependencies

```bash
npm install
```

### Step 4: Configure Panel

The first time you start the panel, it will guide you through installation!

### Step 5: Start Panel

```bash
# Development (not for production)
npm start

# Production with PM2
npm install pm2@latest -g
pm2 start app.js --name pms-panel
pm2 startup
pm2 save
```

## Installing Wings on Nodes

### One-Liner Installation

After creating a node in the panel, run this on your node server:

```bash
bash <(curl -s https://example.com/install-wings.sh)
```

### Manual Wings Installation

```bash
# Install Docker
curl -fsSL https://get.docker.com | sudo bash -

# Download Wings
cd /usr/local/bin
curl -L -o wings https://github.com/pterodactyl/wings/releases/latest/download/wings_linux_amd64
chmod +x wings

# Create directories
mkdir -p /etc/pterodactyl
mkdir -p /var/lib/pms/volumes

# Download config.yml from your panel and place it at /etc/pterodactyl/config.yml

# Create systemd service
cat > /etc/systemd/system/wings.service << 'EOF'
[Unit]
Description=PMS Wings Daemon
After=docker.service
Requires=docker.service
PartOf=docker.service

[Service]
User=root
WorkingDirectory=/etc/pterodactyl
LimitNOFILE=4096
PIDFile=/var/run/wings/wings.pid
ExecStart=/usr/local/bin/wings
Restart=on-failure
StartLimitInterval=180
StartLimitBurst=30
RestartSec=5s

[Install]
WantedBy=multi-user.target
EOF

# Start Wings
systemctl daemon-reload
systemctl enable wings
systemctl start wings
```
