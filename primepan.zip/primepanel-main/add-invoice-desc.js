const Database = require('better-sqlite3');
const path = require('path');

const dbPath = path.join(__dirname, 'billing.sqlite');
console.log('Connecting to:', dbPath);
const db = new Database(dbPath);
console.log('Connected to billing database');

try {
    console.log('Adding "description" column to invoices');
    db.exec(`ALTER TABLE invoices ADD COLUMN description TEXT`);
    console.log('Added "description" column to invoices');
    console.log('✅ Done');
} catch (err) {
    if (err.message && !err.message.includes('duplicate column')) {
        console.error(err.message);
        console.log('ℹ️ Column already exists');
    } else {
        console.error(err);
    }
}

db.close();
