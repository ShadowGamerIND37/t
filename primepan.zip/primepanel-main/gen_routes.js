const fs = require('fs');
const path = require('path');

const appJsPath = path.join(__dirname, 'app.js');
const outputPath = path.join(__dirname, 'backend', 'routes', 'servers.js');

function readLines(start, end) {
    const content = fs.readFileSync(appJsPath, 'utf8');
    const lines = content.split('\n');
    return lines.slice(start - 1, end).join('\n');
}

function stripLineNumbers(code) {
    return code.replace(/^\d+:\s*/gm, '');
}

let output = `const path = require('path');
const fs = require('fs');
const { spawn, exec } = require('child_process');
const util = require('util');
const execAsync = util.promisify(exec);
const multer = require('multer');
const archiver = require('archiver');
const unzipper = require('unzipper');
const axios = require('axios');
const pidusage = require('pidusage');
const sanitize = require('sanitize-filename');
const zlib = require('zlib');
const prismarineNbt = require('prismarine-nbt');
const { promisify } = require('util');
const os = require('os');
const net = require('net');
const { Rcon } = require('rcon-client');
const { v4: uuidv4 } = require('uuid');
const yaml = require('js-yaml');
const crypto = require('crypto');
const { promisify: pPromisify } = require('util');
const nbtParse = promisify(prismarineNbt.parse);

module.exports = function(app, deps) {
    const { 
        dbGet, dbAll, dbRun, db,
        globalSettings, liveStats, serverProcesses, onlinePlayers,
        serverStartTimes, serverLogWatchers, networkStats, totalBandwidthUsed,
        requireAuth, requireAdmin, isAuthorized,
        getTemplateVars,
        isServerRunning, startServer, stopServer, restartServer, sendCommand, isProcessRunning, isJavaProcess,
        fetchMinecraftVersions, getAvailableServerSoftware, isValidMinecraftVersion,
        resolveServerPath, formatFileSize, parseProperties, writeProperties, getDirSize,
        loadServerStartTime, saveServerStartTime, deleteServerStartTime,
        logServerActivity, createNotification,
        downloadServerJar, downloadPluginJar, getInstalledPlugins,
        findAvailablePortForServerType, ensureServerPortForType, updateServerConfigurationPort,
        startLogTail, processLogLine,
        updateLiveStats, startMonitoring,
        DATA_DIR, SERVERS_DIR, APP_DIR
    } = deps;

    const __panelRoot = APP_DIR || path.resolve(__dirname, '..', '../..');

    // ================================================
    // PROGRESS TRACKING
    // ================================================
    const installProgress = {};
    const deleteProgress = {};
    const reinstallProgress = {};
    function setInstallProgress(serverId, message, percent, complete, error) {
        installProgress[serverId] = { message, percent, complete, error, updatedAt: Date.now() };
    }
    function setDeleteProgress(serverId, message, percent, complete, error) {
        deleteProgress[serverId] = { message, percent, complete, error, updatedAt: Date.now() };
    }
    function setReinstallProgress(serverId, message, percent, complete, error) {
        reinstallProgress[serverId] = { message, percent, complete, error, updatedAt: Date.now() };
    }
    function delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // ================================================
    // HELPER FUNCTIONS
    // ================================================

`;

// Helper functions (with function keyword, extracted from app.js)
const helpers = [
    { name: 'isNodeInMaintenance', start: 69, end: 73 },
    { name: 'sanitizeServerProperties', start: 2385, end: 2400 },
    { name: 'writePropertiesString', start: 2403, end: 2407 },
    { name: 'sanitizeVelocityToml', start: 2410, end: 2440 },
    { name: 'sanitizeBungeeCordConfig', start: 2443, end: 2471 },
    { name: 'checkAndAcceptEula', start: 2803, end: 2828 },
    { name: 'autoEnableRcon', start: 2858, end: 2921 },
    { name: 'queryOnlinePlayersRcon', start: 3567, end: 3613 },
    { name: 'queryOnlinePlayers', start: 3616, end: 3642 },
    { name: 'getPidByPort', start: 3643, end: 3679 },
    { name: 'readPlayerFile', start: 4435, end: 4446 },
    { name: 'writePlayerFile', start: 4447, end: 4454 },
    { name: 'getUUID', start: 4455, end: 4463 },
    { name: 'executeCommand', start: 4465, end: 4468 },
    { name: 'getOnlinePlayers', start: 4469, end: 4471 },
    { name: 'setWorldSeed', start: 4563, end: 4577 },
    { name: 'extractPluginInfo', start: 10057, end: 10119 },
    { name: 'parseVelocityToml', start: 8785, end: 8830 },
    { name: 'getDefaultVelocityConfig', start: 8833, end: 8892 },
    { name: 'writeVelocityToml', start: 8895, end: 8957 },
    { name: 'formatTomlValue', start: 8960, end: 8971 },
    { name: 'updateVelocityConfig', start: 8974, end: 8977 },
    { name: 'getDefaultProperties', start: 11737, end: 11767 }
];

for (const h of helpers) {
    let code = readLines(h.start, h.end);
    // Fix indentation: remove leading spaces to normalize to 4-space
    const lines = code.split('\n');
    const fixedLines = lines.map(line => {
        // Remove leading spaces that are more than 4
        const match = line.match(/^(\s*)/);
        if (match) {
            const leading = match[1].length;
            if (leading > 4) {
                return '    ' + line.slice(4);
            }
        }
        return line;
    });
    output += fixedLines.join('\n') + '\n\n';
}

// Multer instances
output += `    // Multer instances
    const upload = multer({
        dest: path.join(__panelRoot, 'uploads/'),
        limits: { fileSize: 10 * 1024 * 1024 * 1024 }
    });

    const modUpload = multer({ dest: 'uploads/', limits: { fileSize: 200 * 1024 * 1024 } });

    const iconUpload = multer({ dest: 'uploads/', limits: { fileSize: 5 * 1024 * 1024 }, fileFilter: (req, f, cb) => cb(null, /image\\/(png|jpeg|jpg)/.test(f.mimetype)) });

`;

// Now add all route sections in order
const routeSections = [
    { name: 'dashboard', start: 7376, end: 7494 },
    { name: 'stats', start: 7497, end: 7552 },
    { name: 'console', start: 7555, end: 7612 },
    { name: 'activity+eula', start: 7614, end: 7667 },
    { name: 'power', start: 7693, end: 7862 },
    { name: 'files', start: 7866, end: 8398 },
    { name: 'subusers', start: 8403, end: 8473 },
    { name: 'settings', start: 8477, end: 8630 },
    { name: 'velocity_routes', start: 8637, end: 8778 },
    { name: 'delete', start: 8980, end: 9049 },
    { name: 'reinstall', start: 9050, end: 9157 },
    { name: 'startup', start: 9161, end: 9276 },
    { name: 'backups', start: 9280, end: 9727 },
    { name: 'plugins_list', start: 9731, end: 10054 },
    { name: 'players', start: 10123, end: 10518 },
    { name: 'worlds', start: 10524, end: 11092 },
    { name: 'worlds_marketplace', start: 11095, end: 11596 },
    { name: 'properties', start: 11603, end: 11734 },
    { name: 'progress_routes', start: 12529, end: 12574 },
    { name: 'mods_etc', start: 12578, end: 12863 }
];

for (const rs of routeSections) {
    let code = readLines(rs.start, rs.end);
    
    // Replace __dirname with __panelRoot for backup/temp paths
    // But be careful: only replace when used with 'backups' or 'temp'
    code = code.replace(/__dirname/g, '__panelRoot');
    
    // Replace global.serverProcesses with serverProcesses
    code = code.replace(/global\.serverProcesses/g, 'serverProcesses');
    
    // Fix: the 'port' variable used in line 12745 references the server's listen port
    // Replace with process.env.PORT || 3000
    code = code.replace(/\bport\b(?=\s*[)\),])/g, '(process.env.PORT || 3000)');
    
    output += code + '\n';
}

// Close the module
output += '\n};\n';

fs.writeFileSync(outputPath, output, 'utf8');
const stats = fs.statSync(outputPath);
console.log('Generated routes file successfully');
console.log('File size:', (stats.size / 1024).toFixed(1), 'KB');
console.log('Line count:', output.split('\n').length);
