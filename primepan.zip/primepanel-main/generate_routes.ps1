$outputPath = "C:\Users\Mithun\Downloads\archive_name\panel\backend\routes\servers.js"

# ===== PART 1: IMPORTS, MODULE EXPORTS, PROGRESS TRACKING, HELPERS =====
$part1 = @'
const path = require('path');
const fs = require('fs');
const { spawn, exec } = require('child_process');
const util = require('util');
const execAsync = util.promisify(exec);
const multer = require('multer');
const archiver = require('archiver');
const unzipper = require('unzipper');
const axios = require('axios');
const pidusage = require('pidusage');
const sanitize = require('sanitize-filename');
const zlib = require('zlib');
const prismarineNbt = require('prismarine-nbt');
const { promisify } = require('util');
const os = require('os');
const net = require('net');
const { Rcon } = require('rcon-client');
const { v4: uuidv4 } = require('uuid');
const yaml = require('js-yaml');
const crypto = require('crypto');
const { promisify: pPromisify } = require('util');
const nbtParse = promisify(prismarineNbt.parse);

module.exports = function(app, deps) {
    const { 
        dbGet, dbAll, dbRun, db,
        globalSettings, liveStats, serverProcesses, onlinePlayers,
        serverStartTimes, serverLogWatchers, networkStats, totalBandwidthUsed,
        requireAuth, requireAdmin, isAuthorized,
        getTemplateVars,
        isServerRunning, startServer, stopServer, restartServer, sendCommand, isProcessRunning, isJavaProcess,
        fetchMinecraftVersions, getAvailableServerSoftware, isValidMinecraftVersion,
        resolveServerPath, formatFileSize, parseProperties, writeProperties, getDirSize,
        loadServerStartTime, saveServerStartTime, deleteServerStartTime,
        logServerActivity, createNotification,
        downloadServerJar, downloadPluginJar, getInstalledPlugins,
        findAvailablePortForServerType, ensureServerPortForType, updateServerConfigurationPort,
        startLogTail, processLogLine,
        updateLiveStats, startMonitoring,
        DATA_DIR, SERVERS_DIR, APP_DIR
    } = deps;

    const __panelRoot = APP_DIR || path.resolve(__dirname, '..', '../..');

    // ================================================
    // PROGRESS TRACKING
    // ================================================
    const installProgress = {};
    const deleteProgress = {};
    const reinstallProgress = {};
    function setInstallProgress(serverId, message, percent, complete, error) {
        installProgress[serverId] = { message, percent, complete, error, updatedAt: Date.now() };
    }
    function setDeleteProgress(serverId, message, percent, complete, error) {
        deleteProgress[serverId] = { message, percent, complete, error, updatedAt: Date.now() };
    }
    function setReinstallProgress(serverId, message, percent, complete, error) {
        reinstallProgress[serverId] = { message, percent, complete, error, updatedAt: Date.now() };
    }
    function delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // ================================================
    // HELPER FUNCTIONS
    // ================================================

    async function extractPluginInfo(jarPath, filename) {
        try {
            const AdmZip = require('adm-zip');
            const zip = new AdmZip(jarPath);
            let pluginYml = zip.getEntry('plugin.yml');
            if (!pluginYml) {
                pluginYml = zip.getEntry('paper-plugin.yml');
            }
            if (!pluginYml) {
                pluginYml = zip.getEntry('bungee.yml');
            }
            if (pluginYml) {
                const content = zip.readAsText(pluginYml);
                const yaml = require('js-yaml');
                const data = yaml.load(content);
                return {
                    name: data.name || filename.replace('.jar', ''),
                    version: data.version || 'Unknown',
                    description: data.description || null,
                    author: data.author || (data.authors && data.authors[0]) || null,
                    website: data.website || null,
                    main: data.main || null
                };
            }
            const manifest = zip.getEntry('META-INF/MANIFEST.MF');
            if (manifest) {
                const content = zip.readAsText(manifest);
                const versionMatch = content.match(/Implementation-Version:\s*(.+)/i);
                if (versionMatch) {
                    return {
                        name: filename.replace('.jar', ''),
                        version: versionMatch[1].trim(),
                        description: null,
                        author: null,
                        website: null
                    };
                }
            }
            return {
                name: filename.replace('.jar', ''),
                version: 'Unknown',
                description: null,
                author: null,
                website: null
            };
        } catch (err) {
            console.error('Error extracting plugin info from ' + filename + ':', err.message);
            return {
                name: filename.replace('.jar', ''),
                version: 'Unknown',
                description: null,
                author: null,
                website: null
            };
        }
    }

    function parseVelocityToml(content) {
        const config = {};
        const lines = content.split('\n');
        let currentSection = null;
        for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed || trimmed.startsWith('#')) continue;
            if (trimmed.startsWith('[') && trimmed.endsWith(']')) {
                currentSection = trimmed.slice(1, -1);
                if (!config[currentSection]) config[currentSection] = {};
                continue;
            }
            const equalIndex = trimmed.indexOf('=');
            if (equalIndex === -1) continue;
            const key = trimmed.substring(0, equalIndex).trim();
            let value = trimmed.substring(equalIndex + 1).trim();
            if (value.startsWith('"') && value.endsWith('"')) {
                value = value.slice(1, -1);
            } else if (value === 'true' || value === 'false') {
                value = value === 'true';
            } else if (!isNaN(value)) {
                value = parseInt(value);
            } else if (value.startsWith('[') && value.endsWith(']')) {
                value = value.slice(1, -1).split(',').map(v => v.trim().replace(/"/g, ''));
            }
            if (currentSection) {
                config[currentSection][key] = value;
            } else {
                config[key] = value;
            }
        }
        return config;
    }

    function getDefaultVelocityConfig(server) {
        return {
            'config-version': '2.6',
            'bind': '0.0.0.0:' + server.port,
            'motd': server.name || 'A Velocity Server',
            'show-max-players': 500,
            'online-mode': true,
            'prevent-client-proxy-connections': false,
            'player-info-forwarding-mode': 'MODERN',
            'forwarding-secret-file': 'forwarding.secret',
            'announce-forge': false,
            'kick-existing-players': false,
            'ping-passthrough': 'DISABLED',
            'enable-player-address-logging': true,
            'bungee-plugin-message-channel': true,
            'show-ping-requests': false,
            'failover-on-unexpected-server-disconnect': true,
            'announce-proxy-commands': true,
            'log-command-executions': false,
            'log-player-connections': true,
            'servers': {
                'lobby': 'localhost:25565',
                'survival': 'localhost:25566'
            },
            'try': ['lobby'],
            'forced-hosts': {},
            'advanced': {
                'compression-threshold': 256,
                'compression-level': -1,
                'login-ratelimit': 3000,
                'connection-timeout': 5000,
                'read-timeout': 30000,
                'haproxy-protocol': false,
                'tcp-fast-open': false,
                'bungee-plugin-message-channel': true,
                'show-ping-requests': false,
                'failover-on-unexpected-server-disconnect': true,
                'announce-proxy-commands': true,
                'log-command-executions': false,
                'log-player-connections': true
            },
            'query': {
                'enabled': false,
                'port': server.port + 1,
                'map': 'Velocity',
                'show-plugins': false
            }
        };
    }

    function writeVelocityToml(config, filePath) {
        let content = '# Velocity Configuration\n';
        content += '# Generated by Minecraft Server Panel\n\n';
        const mainKeys = ['config-version', 'bind', 'motd', 'show-max-players', 'online-mode', 
                         'prevent-client-proxy-connections', 'player-info-forwarding-mode', 
                         'forwarding-secret-file', 'announce-forge', 'kick-existing-players',
                         'ping-passthrough', 'enable-player-address-logging', 'bungee-plugin-message-channel',
                         'show-ping-requests', 'failover-on-unexpected-server-disconnect',
                         'announce-proxy-commands', 'log-command-executions', 'log-player-connections'];
        for (const key of mainKeys) {
            if (config[key] !== undefined) {
                content += key + ' = ' + formatTomlValue(config[key]) + '\n';
            }
        }
        content += '\n';
        if (config.servers) {
            content += '[servers]\n';
            for (const [name, address] of Object.entries(config.servers)) {
                content += name + ' = "' + address + '"\n';
            }
            content += '\n';
        }
        if (config.try && Array.isArray(config.try)) {
            content += 'try = [' + config.try.map(s => '"' + s + '"').join(', ') + ']\n\n';
        }
        if (config['forced-hosts']) {
            content += '[forced-hosts]\n';
            for (const [host, server] of Object.entries(config['forced-hosts'])) {
                content += '"' + host + '" = "' + server + '"\n';
            }
            content += '\n';
        }
        if (config.advanced) {
            content += '[advanced]\n';
            for (const [key, value] of Object.entries(config.advanced)) {
                content += key + ' = ' + formatTomlValue(value) + '\n';
            }
            content += '\n';
        }
        if (config.query) {
            content += '[query]\n';
            for (const [key, value] of Object.entries(config.query)) {
                content += key + ' = ' + formatTomlValue(value) + '\n';
            }
            content += '\n';
        }
        fs.writeFileSync(filePath, content, 'utf8');
    }

    function formatTomlValue(value) {
        if (typeof value === 'string') {
            return '"' + value + '"';
        } else if (typeof value === 'boolean') {
            return value.toString();
        } else if (typeof value === 'number') {
            return value.toString();
        } else if (Array.isArray(value)) {
            return '[' + value.map(v => '"' + v + '"').join(', ') + ']';
        }
        return '"' + value + '"';
    }

    async function updateVelocityConfig(serverId, config) {
        const configPath = resolveServerPath(serverId, 'velocity.toml');
        writeVelocityToml(config, configPath);
    }

    async function isNodeInMaintenance(nodeId) {
        if (!nodeId) return false;
        const node = await dbGet('SELECT maintenance_mode FROM nodes WHERE id = ?', [nodeId]);
        return node && node.maintenance_mode === 1;
    }

    function sanitizeServerProperties(content, serverPort) {
        try {
            const properties = parseProperties(content);
            properties['server-port'] = serverPort;
            return writePropertiesString(properties);
        } catch (err) {
            console.error('Error sanitizing server.properties:', err);
            throw err;
        }
    }

    function writePropertiesString(properties) {
        return Object.entries(properties)
            .map(([key, value]) => key + '=' + value)
            .join('\n') + '\n';
    }

    function sanitizeVelocityToml(content, serverPort) {
        try {
            const bindRegex = /bind\s*=\s*"[^"]*"/g;
            const correctBind = 'bind = "0.0.0.0:' + serverPort + '"';
            if (bindRegex.test(content)) {
                content = content.replace(bindRegex, correctBind);
            } else {
                const lines = content.split('\n');
                const insertIndex = lines.findIndex(function(line) { 
                    return line.trim() && !line.trim().startsWith('#');
                });
                if (insertIndex >= 0) {
                    lines.splice(insertIndex, 0, correctBind);
                } else {
                    lines.unshift(correctBind);
                }
                content = lines.join('\n');
            }
            return content;
        } catch (err) {
            console.error('Error sanitizing velocity.toml:', err);
            throw err;
        }
    }

    function sanitizeBungeeCordConfig(content, serverPort) {
        try {
            const hostRegex = /host:\s*([^:]+):(\d+)/g;
            content = content.replace(hostRegex, function(match, ip, port) {
                return 'host: 0.0.0.0:' + serverPort;
            });
            const listenRegex = /listen:\s*([^:]+):(\d+)/g;
            content = content.replace(listenRegex, function(match, ip, port) {
                return 'listen: 0.0.0.0:' + serverPort;
            });
            const bindLocalRegex = /bind_local_address:\s*([^:]+):(\d+)/g;
            content = content.replace(bindLocalRegex, function(match, ip, port) {
                return 'bind_local_address: 0.0.0.0:' + serverPort;
            });
            return content;
        } catch (err) {
            console.error('Error sanitizing BungeeCord config.yml:', err);
            throw err;
        }
    }

    function checkAndAcceptEula(serverId, accept) {
        if (accept === undefined) accept = false;
        try {
            const serverDir = resolveServerPath(serverId);
            const eulaPath = path.join(serverDir, 'eula.txt');
            if (!fs.existsSync(eulaPath)) {
                fs.writeFileSync(eulaPath, '#By changing the setting below to TRUE you are indicating your agreement to our EULA (https://aka.ms/MinecraftEULA)\n#Fri Jun 13 2025 00:00:00 GMT\n#Server Properties (default)\n#Fri Jun 13 2025 00:00:00 GMT\neula=false\n', 'utf8');
                return { accepted: false, exists: true };
            }
            const content = fs.readFileSync(eulaPath, 'utf8');
            const isAccepted = /eula\s*=\s*true/i.test(content);
            if (accept && !isAccepted) {
                const newContent = content.replace(/eula\s*=\s*false/i, 'eula=true');
                fs.writeFileSync(eulaPath, newContent, 'utf8');
                return { accepted: true, exists: true };
            }
            return { accepted: isAccepted, exists: true };
        } catch (err) {
            console.error('Error checking EULA:', err);
            return { accepted: false, exists: false, error: err.message };
        }
    }

    async function autoEnableRcon(serverId) {
        try {
            const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
            if (!server) return false;
            const propertiesPath = resolveServerPath(serverId, 'server.properties');
            if (!fs.existsSync(propertiesPath)) {
                console.log('server.properties not found for server ' + serverId);
                return false;
            }
            let content = fs.readFileSync(propertiesPath, 'utf8');
            if (content.includes('enable-rcon=true')) {
                console.log('RCON already enabled for server ' + serverId);
                return true;
            }
            const rconPort = server.port + 1000;
            const rconPassword = 'admin123';
            const rconSettings = '\n# RCON Settings (Auto-enabled by panel)\nenable-rcon=true\nrcon.port=' + rconPort + '\nrcon.password=' + rconPassword + '\n';
            content = content.replace(/enable-rcon=.*/g, '');
            content = content.replace(/rcon\.port=.*/g, '');
            content = content.replace(/rcon\.password=.*/g, '');
            content = content.trim() + '\n' + rconSettings;
            fs.writeFileSync(propertiesPath, content, 'utf8');
            const settings = JSON.parse(server.settings || '{}');
            settings.rcon = true;
            settings['rcon.port'] = rconPort;
            settings['rcon.password'] = rconPassword;
            await dbRun('UPDATE servers SET settings = ? WHERE id = ?', [
                JSON.stringify(settings), serverId
            ]);
            console.log('RCON auto-enabled for server ' + serverId + ' on port ' + rconPort);
            return true;
        } catch (err) {
            console.error('Failed to auto-enable RCON for server ' + serverId + ':', err);
            return false;
        }
    }

    function readPlayerFile(serverId, fileName) {
        const filePath = resolveServerPath(serverId, fileName);
        if (fs.existsSync(filePath)) {
            try {
                return JSON.parse(fs.readFileSync(filePath, 'utf8')) || [];
            } catch (err) {
                console.error('Error reading ' + fileName + ' for server ' + serverId, err);
                return [];
            }
        }
        return [];
    }

    function writePlayerFile(serverId, fileName, data) {
        const filePath = resolveServerPath(serverId, fileName);
        try {
            fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
        } catch (err) {
            console.error('Error writing ' + fileName + ' for server ' + serverId, err);
        }
    }

    async function getUUID(name) {
        try {
            const { data } = await axios.get('https://api.mojang.com/users/profiles/minecraft/' + name);
            const id = data.id;
            return id.substr(0,8) + '-' + id.substr(8,4) + '-' + id.substr(12,4) + '-' + id.substr(16,4) + '-' + id.substr(20);
        } catch {
            return null;
        }
    }

    function executeCommand(serverId, cmd) {
        sendCommand(serverId, cmd).catch(function(err) { console.error('Execute command failed:', err); });
        return true;
    }

    function getOnlinePlayers(serverId) {
        return onlinePlayers[serverId] || [];
    }

    async function queryOnlinePlayersRcon(serverId) {
        try {
            const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
            if (!server) return false;
            const rcon = new Rcon({
                host: 'localhost',
                port: 25575,
                password: 'admin123'
            });
            await rcon.connect();
            const response = await rcon.send('list');
            await rcon.end();
            console.log('RCON response for server ' + serverId + ':', response);
            const listMatch = response.match(/There are \d+(?:\/| of a max of )\d+ players online:\s*(.*)/i);
            if (listMatch) {
                const playerList = listMatch[1].trim();
                let players = [];
                if (playerList && playerList !== '') {
                    players = playerList.split(',').map(function(p) { return p.trim(); }).filter(function(p) { return p && p !== ''; });
                }
                onlinePlayers[serverId] = players;
                console.log('Updated online players for server ' + serverId + ' via RCON:', players);
                return true;
            }
            return false;
        } catch (err) {
            console.log('RCON not available for server ' + serverId + ' (this is normal if RCON is not configured)');
            return false;
        }
    }

    async function queryOnlinePlayers(serverId) {
        try {
            const rconSuccess = await queryOnlinePlayersRcon(serverId);
            if (rconSuccess) return true;
            const sp = serverProcesses && serverProcesses[serverId];
            if (sp && !sp.killed && sp.stdin && sp.stdin.writable) {
                sp.stdin.write('list\n');
                console.log('Queried online players for server ' + serverId + ' via stdin');
                return true;
            } else {
                console.log('Server ' + serverId + ' player query skipped - server may be stopped or RCON not configured');
                if (!onlinePlayers[serverId]) {
                    onlinePlayers[serverId] = [];
                }
                return false;
            }
        } catch (err) {
            console.error('Failed to query online players for server ' + serverId + ':', err);
            return false;
        }
    }

    async function setWorldSeed(worldDir, newSeed) {
        try {
            const levelPath = path.join(worldDir, 'level.dat');
            const buf = fs.readFileSync(levelPath);
            const uncompressed = zlib.gunzipSync(buf);
            const parsed = await nbtParse(uncompressed);
            if (!parsed.value.Data) parsed.value.Data = { type: 'compound', value: {} };
            parsed.value.Data.value.Seed = { type: 'long', value: BigInt(newSeed) };
            const written = prismarineNbt.writeUncompressed(parsed);
            const compressed = zlib.gzipSync(written);
            fs.writeFileSync(levelPath, compressed);
        } catch (err) {
            throw err;
        }
    }

    function getDefaultProperties(server) {
        return {
            'server-ip': '',
            'server-port': server.port,
            'motd': server.name || 'Minecraft Server',
            'max-players': 20,
            'gamemode': 'survival',
            'difficulty': 'normal',
            'hardcore': false,
            'pvp': true,
            'allow-flight': false,
            'level-name': 'world',
            'level-seed': '',
            'level-type': 'minecraft:normal',
            'generate-structures': true,
            'spawn-animals': true,
            'spawn-monsters': true,
            'view-distance': 10,
            'simulation-distance': 10,
            'max-tick-time': 60000,
            'online-mode': true,
            'white-list': false,
            'enforce-whitelist': false,
            'spawn-protection': 16,
            'enable-command-block': false,
            'function-permission-level': 2,
            'op-permission-level': 4,
            'resource-pack': '',
            'resource-pack-sha1': ''
        };
    }

    // ================================================
    // MULTER INSTANCES
    // ================================================
    const upload = multer({
        dest: path.join(__panelRoot, 'uploads/'),
        limits: { fileSize: 10 * 1024 * 1024 * 1024 }
    });

    const modUpload = multer({ dest: 'uploads/', limits: { fileSize: 200 * 1024 * 1024 } });

    const iconUpload = multer({ dest: 'uploads/', limits: { fileSize: 5 * 1024 * 1024 }, fileFilter: function(req, f, cb) { cb(null, /image\/(png|jpeg|jpg)/.test(f.mimetype)); } });
'@
Set-Content -Path $outputPath -Value $part1 -NoNewline
Write-Host "Part 1 written successfully"
