const sqlite3 = require('sqlite3').verbose();
const { v4: uuidv4 } = require('uuid');
const path = require('path');

const db = new sqlite3.Database(path.join(__dirname, 'database.db'));

const userId = 1;
const keyName = 'Test API Key';
const permissions = ['read', 'write', 'admin'];
const apiKey = 'mcpanel_' + uuidv4().replace(/-/g, '');

db.run(
    'INSERT INTO api_keys (user_id, name, key, permissions) VALUES (?, ?, ?, ?)',
    [userId, keyName, apiKey, JSON.stringify(permissions)],
    function(err) {
        if (err) {
            console.error('Error inserting API key:', err);
        } else {
            console.log('API key created successfully!');
            console.log('Key:', apiKey);
            console.log('Name:', keyName);
            console.log('Permissions:', permissions);
        }
        db.close();
    }
);
