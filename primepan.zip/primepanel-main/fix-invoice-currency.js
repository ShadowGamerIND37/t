const sqlite3 = require('sqlite3');
const db = new sqlite3.Database('./database.db');

console.log('Adding currency column to invoices...');
db.run('ALTER TABLE invoices ADD COLUMN currency TEXT DEFAULT "USD"', function(err) {
    if (err) {
        if (!err.message.includes('duplicate column name')) {
            console.error('Error:', err.message);
        } else {
            console.log('✓ Currency column already exists');
        }
    } else {
        console.log('✓ Added currency column to invoices');
    }
    db.close();
});
