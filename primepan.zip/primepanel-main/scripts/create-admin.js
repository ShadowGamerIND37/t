// Create/update admin user
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');

const DB_PATH = path.resolve(__dirname, '..', 'database.db');
const db = new sqlite3.Database(DB_PATH);

db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT DEFAULT 'user',
        status TEXT DEFAULT 'active',
        display_name TEXT,
        profile_picture TEXT,
        theme_preference TEXT DEFAULT 'dark',
        theme_primary_color TEXT DEFAULT '#2d6a4f',
        theme_accent_color TEXT DEFAULT '#40916c',
        language TEXT DEFAULT 'en',
        timezone TEXT DEFAULT 'UTC',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.get('SELECT id FROM users WHERE username = ?', ['admin'], (err, row) => {
        if (err) { console.error('Error:', err); return; }
        if (row) {
            console.log('Admin user already exists with id:', row.id);
            const hashedPassword = bcrypt.hashSync('admin123', 10);
            db.run('UPDATE users SET password = ? WHERE id = ?', [hashedPassword, row.id]);
            console.log('Admin password updated');
        } else {
            const hashedPassword = bcrypt.hashSync('admin123', 10);
            db.run('INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)',
                ['admin', 'admin@example.com', hashedPassword, 'admin'],
                function() { console.log('Admin user created with id:', this.lastID); }
            );
        }
    });
});

setTimeout(() => {
    db.close();
    console.log('Done');
}, 1500);
