const sqlite3 = require('sqlite3');
const db = new sqlite3.Database('./database.db');

console.log('Checking invoices table...');
db.all(`PRAGMA table_info(invoices)`, (err, rows) => {
    if (err) {
        console.error(err);
        process.exit(1);
    }
    console.log('Columns in invoices:');
    rows.forEach(row => console.log(`- ${row.name}`));
    db.close();
});
