#!/usr/bin/env node
const http = require('http');
const https = require('https');
const jwt = require('jsonwebtoken');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');

const connString = process.argv[2] || process.env.DAEMON_CONNECTION_STRING;
if (!connString) {
    console.error('Usage: node daemon/index.js <connection-string>');
    console.error('Or set DAEMON_CONNECTION_STRING env variable');
    process.exit(1);
}

let config;
try {
    const json = Buffer.from(connString, 'base64').toString('utf8');
    config = JSON.parse(json);
} catch (e) {
    console.error('Invalid connection string:', e.message);
    process.exit(1);
}

const { panel_url, node_uuid, token_id, token } = config;
console.log(`Connecting to panel: ${panel_url}`);
console.log(`Node UUID: ${node_uuid}`);

// Track local server processes: { serverId: ChildProcess }
const serverProcesses = {};
const serverDirs = {};
const DATA_DIR = path.join(os.homedir(), 'pms-servers');

function createJWT() {
    return jwt.sign(
        { iss: 'pms-daemon', sub: node_uuid, jti: token_id, scopes: ['*'],
          iat: Math.floor(Date.now() / 1000), nbf: Math.floor(Date.now() / 1000),
          exp: Math.floor(Date.now() / 1000) + 300 },
        token,
        { header: { kid: token_id } }
    );
}

function apiRequest(method, path, data = null) {
    return new Promise((resolve, reject) => {
        const jwToken = createJWT();
        const url = new URL(path, panel_url);
        const lib = url.protocol === 'https:' ? https : http;
        const req = lib.request({
            hostname: url.hostname, port: url.port,
            path: url.pathname + url.search, method,
            headers: {
                'Authorization': `Bearer ${jwToken}`,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }, (res) => {
            let body = '';
            res.on('data', c => body += c);
            res.on('end', () => {
                try { resolve(JSON.parse(body)); }
                catch { resolve(body); }
            });
        });
        req.on('error', reject);
        if (data) req.write(JSON.stringify(data));
        req.end();
    });
}

function isServerRunning(serverId) {
    const proc = serverProcesses[serverId];
    if (!proc) return false;
    try { return proc.exitCode === null; }
    catch { return false; }
}

async function startServerProcess(serverId, serverDir) {
    if (isServerRunning(serverId)) {
        console.log(`  Server ${serverId} already running`);
        return;
    }
    
    const serverJar = path.join(serverDir, 'server.jar');
    if (!fs.existsSync(serverJar)) {
        console.log(`  server.jar not found at ${serverDir}, downloading...`);
        const jarUrl = `https://api.papermc.io/v2/projects/paper/versions/1.20.4/builds/latest/downloads/paper-1.20.4.jar`;
        await downloadFile(jarUrl, serverJar);
    }
    
    const serverProcess = spawn('java', ['-Xms512M', '-Xmx1024M', '-jar', 'server.jar', 'nogui'], {
        cwd: serverDir, stdio: ['pipe', 'pipe', 'pipe']
    });
    
    serverProcesses[serverId] = serverProcess;
    console.log(`  Started server ${serverId} (PID: ${serverProcess.pid})`);
    
    serverProcess.on('exit', (code, signal) => {
        console.log(`  Server ${serverId} exited (code: ${code}, signal: ${signal})`);
        delete serverProcesses[serverId];
    });
    
    serverProcess.stdout.on('data', (data) => {
        // Could send console output to panel in future
    });
}

function stopServerProcess(serverId) {
    const proc = serverProcesses[serverId];
    if (!proc) return;
    try {
        if (process.platform === 'win32') {
            spawn('taskkill', ['/PID', proc.pid.toString(), '/F', '/T']);
        } else {
            proc.kill('SIGTERM');
            setTimeout(() => { try { proc.kill('SIGKILL'); } catch {} }, 5000);
        }
        delete serverProcesses[serverId];
        console.log(`  Stopped server ${serverId}`);
    } catch (e) {
        console.error(`  Failed to stop server ${serverId}:`, e.message);
    }
}

function downloadFile(url, dest) {
    return new Promise((resolve, reject) => {
        const file = fs.createWriteStream(dest);
        const lib = url.startsWith('https') ? https : http;
        lib.get(url, (res) => {
            res.pipe(file);
            file.on('finish', () => { file.close(); resolve(); });
        }).on('error', reject);
    });
}

async function sendHeartbeat() {
    try {
        // Collect server statuses
        const serverStatuses = Object.keys(serverProcesses).map(id => ({
            server_id: parseInt(id),
            running: isServerRunning(id)
        }));
        
        const stats = {
            hostname: os.hostname(),
            platform: os.platform(),
            uptime: process.uptime(),
            memory: process.memoryUsage(),
            load: os.loadavg(),
            totalmem: os.totalmem(),
            freemem: os.freemem(),
            server_statuses: serverStatuses
        };
        
        const res = await apiRequest('POST', '/api/wings/heartbeat', stats);
        console.log(`[${new Date().toLocaleTimeString()}] Heartbeat sent`);
        
        // Handle node-level commands
        if (res && res.command) {
            console.log(`Node command received: ${res.command}`);
            if (res.command === 'restart') {
                console.log('Restarting daemon...');
                setTimeout(() => process.exit(0), 1000);
            } else if (res.command === 'stop') {
                console.log('Stopping daemon...');
                setTimeout(() => process.exit(0), 1000);
            }
        }
        
        // Handle server commands
        if (res && res.server_commands && res.server_commands.length > 0) {
            for (const cmd of res.server_commands) {
                console.log(`Server command: ${cmd.action} server ${cmd.server_id}`);
                const serverDir = path.join(DATA_DIR, String(cmd.server_id));
                fs.mkdirSync(serverDir, { recursive: true });
                serverDirs[cmd.server_id] = serverDir;
                
                switch (cmd.action) {
                    case 'start':
                        await startServerProcess(cmd.server_id, serverDir);
                        break;
                    case 'stop':
                        stopServerProcess(cmd.server_id);
                        break;
                    case 'restart':
                        stopServerProcess(cmd.server_id);
                        await new Promise(r => setTimeout(r, 2000));
                        await startServerProcess(cmd.server_id, serverDir);
                        break;
                    case 'kill':
                        stopServerProcess(cmd.server_id);
                        break;
                }
            }
        }
    } catch (e) {
        console.error('Heartbeat failed:', e.message);
    }
}

console.log('Daemon connected and sending heartbeats...');
console.log(`Servers directory: ${DATA_DIR}`);
fs.mkdirSync(DATA_DIR, { recursive: true });
sendHeartbeat();
setInterval(sendHeartbeat, 30000);
