#!/bin/bash

# PMS Panel Installer
# Version: 1.0
# Author: Your Name

set -e  # Exit on error
set -o pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Functions
print_info() {
    echo -e "${CYAN}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if user is root
if [[ $EUID -ne 0 ]]; then
   print_error "This script must be run as root"
   exit 1
fi

print_info "Welcome to the PMS Panel Installer!"
print_info "This script will install and configure the PMS Panel for you"
echo ""

# Determine source directory
SOURCE_DIR=""
PANEL_DIR="/var/www/pms"

# Function to check if directory has panel files
has_panel_files() {
    local dir="$1"
    # Check for multiple panel files to be sure
    if [ -f "$dir/app.js" ] || [ -f "$dir/package.json" ] || [ -f "$dir/init-database.js" ]; then
        return 0
    fi
    return 1
}

# Check common locations
if [ "$PWD" = "/root" ] && has_panel_files "/root"; then
    SOURCE_DIR="/root"
    print_info "Found panel files in /root"
elif [ "$PWD" = "/var/www/pms" ] && has_panel_files "/var/www/pms"; then
    SOURCE_DIR="/var/www/pms"
    print_info "Found panel files in /var/www/pms"
elif has_panel_files "$PWD"; then
    SOURCE_DIR="$PWD"
    print_info "Found panel files in $PWD"
else
    print_warning "Warning: Could not automatically detect panel files!"
    print_warning "Please upload your panel files to /root or /var/www/pms and run the script again"
fi

# Update system
print_info "Updating system packages..."
apt update -y && apt upgrade -y

# Install dependencies
print_info "Installing required dependencies..."
apt install -y curl git software-properties-common ca-certificates gnupg lsb-release

# Install Java
print_info "Installing OpenJDK 21..."
apt install -y openjdk-21-jdk

# Install Node.js
print_info "Installing Node.js 23..."
mkdir -p /etc/apt/keyrings
curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | gpg --dearmor -o /etc/apt/keyrings/nodesource.gpg
echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_23.x nodistro main" | tee /etc/apt/sources.list.d/nodesource.list
apt update -y
apt install -y nodejs

# Verify installations
print_info "Verifying installations..."
java -version
node -v
npm -v

# Set up panel directory
if [ "$SOURCE_DIR" != "$PANEL_DIR" ]; then
    print_info "Setting up panel directory at $PANEL_DIR"
    mkdir -p "$PANEL_DIR"
    
    if [ -n "$SOURCE_DIR" ]; then
        # Copy files from source directory
        print_info "Copying panel files from $SOURCE_DIR to $PANEL_DIR"
        cp -r "$SOURCE_DIR"/* "$PANEL_DIR"/
    fi
fi

# Create other required directories
print_info "Setting up other required directories..."
mkdir -p /var/lib/pms/volumes

# Ensure we're in the right directory
cd "$PANEL_DIR"

# Install npm dependencies
print_info "Installing panel dependencies..."
if [ ! -d "node_modules" ]; then
    npm install
fi

# Install PM2 for process management
print_info "Installing PM2..."
if ! command -v pm2 &> /dev/null; then
    npm install pm2@latest -g
fi

# Start panel
print_info "Starting PMS Panel..."
pm2 start app.js --name pms-panel -f

# Save PM2 configuration
pm2 save
pm2 startup systemd -u root --hp /root -f

print_success ""
print_success "========================================"
print_success "  PMS Panel Installation Complete!"
print_success "========================================"
print_success ""
print_success "Your panel is installed in: $PANEL_DIR"
print_success "Access it at: http://$(hostname -I | awk '{print $1}'):3000"
print_success ""
print_success "Useful commands:"
print_success "  pm2 status    - Check panel status"
print_success "  pm2 logs pms-panel  - View panel logs"
print_success "  pm2 restart pms-panel - Restart panel"
print_success ""
