const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const crypto = require('crypto');
const { DB_PATH } = require('../config');

const db = new sqlite3.Database(DB_PATH, (err) => {
    if (err) {
        console.error('Failed to open database:', err);
        process.exit(1);
    }
    console.log('Connected to SQLite database');
});

function dbGet(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.get(sql, params, (err, row) => err ? reject(err) : resolve(row));
    });
}

function dbAll(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows || []));
    });
}

function dbRun(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function (err) {
            err ? reject(err) : resolve({ lastID: this.lastID, changes: this.changes });
        });
    });
}

function initDatabase(globalSettings, app) {
    return new Promise((resolve) => {
        db.serialize(() => {
            createTables();
            runMigrations();
            createAdminUser();
            insertDefaultSettings();
            loadSettings(globalSettings, app, resolve);
        });
    });
}

function createTables() {
    db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT DEFAULT 'user',
        status TEXT DEFAULT 'active',
        display_name TEXT,
        profile_picture TEXT,
        theme_preference TEXT DEFAULT 'dark',
        theme_primary_color TEXT DEFAULT '#2d6a4f',
        theme_accent_color TEXT DEFAULT '#40916c',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        type TEXT DEFAULT 'info',
        icon TEXT DEFAULT 'info-circle',
        is_read BOOLEAN DEFAULT 0,
        action_url TEXT,
        action_text TEXT,
        server_id INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id),
        FOREIGN KEY (server_id) REFERENCES servers (id)
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS user_profiles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL UNIQUE,
        display_name TEXT,
        bio TEXT,
        location TEXT,
        website TEXT,
        profile_picture TEXT,
        theme_preference TEXT DEFAULT 'dark',
        theme_primary_color TEXT DEFAULT '#2d6a4f',
        theme_accent_color TEXT DEFAULT '#40916c',
        language TEXT DEFAULT 'en',
        timezone TEXT DEFAULT 'UTC',
        email_notifications BOOLEAN DEFAULT 1,
        push_notifications BOOLEAN DEFAULT 1,
        security_notifications BOOLEAN DEFAULT 1,
        notification_frequency TEXT DEFAULT 'immediate',
        quiet_hours_start TEXT,
        quiet_hours_end TEXT,
        two_factor_enabled BOOLEAN DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS notification_preferences (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        category TEXT NOT NULL,
        enabled BOOLEAN DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
        UNIQUE(user_id, category)
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS user_activity (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        action TEXT NOT NULL,
        description TEXT,
        ip_address TEXT,
        user_agent TEXT,
        metadata TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS locations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        short TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS nodes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        uuid TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        description TEXT,
        location_id INTEGER NOT NULL,
        public BOOLEAN DEFAULT 1,
        fqdn TEXT NOT NULL,
        scheme TEXT NOT NULL DEFAULT 'https',
        behind_proxy BOOLEAN DEFAULT 0,
        maintenance_mode BOOLEAN DEFAULT 0,
        memory INTEGER NOT NULL,
        memory_overallocate INTEGER DEFAULT 0,
        disk INTEGER NOT NULL,
        disk_overallocate INTEGER DEFAULT 0,
        upload_size INTEGER DEFAULT 100,
        daemon_token_id TEXT NOT NULL,
        daemon_token TEXT NOT NULL,
        daemon_listen INTEGER DEFAULT 8080,
        daemon_sftp INTEGER DEFAULT 2022,
        daemon_base TEXT DEFAULT '/var/lib/pms/volumes',
        mode TEXT DEFAULT 'local',
        last_heartbeat DATETIME,
        stats TEXT,
        daemon_ip TEXT,
        pending_command TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (location_id) REFERENCES locations (id)
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS allocations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        node_id INTEGER NOT NULL,
        ip TEXT NOT NULL,
        alias TEXT,
        port INTEGER NOT NULL,
        server_id INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (node_id) REFERENCES nodes (id),
        FOREIGN KEY (server_id) REFERENCES servers (id)
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS servers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        owner_id INTEGER NOT NULL,
        node_id INTEGER,
        ram INTEGER NOT NULL,
        cpu INTEGER DEFAULT 1,
        disk INTEGER DEFAULT 1024,
        port INTEGER NOT NULL,
        server_ip TEXT DEFAULT '',
        ip_alias TEXT,
        port_alias TEXT,
        additional_ports TEXT DEFAULT '[]',
        status TEXT DEFAULT 'stopped',
        version TEXT DEFAULT 'latest',
        server_type TEXT DEFAULT 'vanilla',
        settings TEXT DEFAULT '{}',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (owner_id) REFERENCES users (id),
        FOREIGN KEY (node_id) REFERENCES nodes (id)
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS subusers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        server_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        permissions TEXT DEFAULT '[]',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (server_id) REFERENCES servers(id),
        FOREIGN KEY (user_id) REFERENCES users(id)
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS backups (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        server_id INTEGER NOT NULL,
        file TEXT NOT NULL,
        name TEXT,
        description TEXT,
        size TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (server_id) REFERENCES servers(id)
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS file_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        server_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        action TEXT NOT NULL,
        file_path TEXT NOT NULL,
        details TEXT DEFAULT '{}',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (server_id) REFERENCES servers(id),
        FOREIGN KEY (user_id) REFERENCES users(id)
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS server_activity (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        server_id INTEGER NOT NULL,
        user_id INTEGER,
        action TEXT NOT NULL,
        details TEXT,
        ip_address TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS panel_settings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        key TEXT UNIQUE NOT NULL,
        value TEXT NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS announcements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        type TEXT DEFAULT 'info',
        is_active INTEGER DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Billing tables
    db.run(`CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        category TEXT,
        type TEXT,
        is_active BOOLEAN DEFAULT 1,
        is_featured BOOLEAN DEFAULT 0,
        sort_order INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS plans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER REFERENCES products(id) ON DELETE CASCADE,
        name TEXT NOT NULL,
        description TEXT,
        price DECIMAL(10, 2) NOT NULL,
        currency TEXT DEFAULT 'USD',
        billing_cycle TEXT DEFAULT 'monthly',
        is_recurring BOOLEAN DEFAULT 1,
        is_active BOOLEAN DEFAULT 1,
        sort_order INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS plan_resources (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        plan_id INTEGER REFERENCES plans(id) ON DELETE CASCADE,
        resource_type TEXT NOT NULL,
        resource_value INTEGER NOT NULL,
        unit TEXT
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS addons (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        price DECIMAL(10, 2) NOT NULL,
        currency TEXT DEFAULT 'USD',
        billing_cycle TEXT DEFAULT 'monthly',
        is_active BOOLEAN DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        amount DECIMAL(10, 2) NOT NULL,
        currency TEXT DEFAULT 'USD',
        payment_method TEXT,
        payment_gateway TEXT,
        gateway_transaction_id TEXT,
        status TEXT,
        metadata TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS invoices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        number TEXT NOT NULL UNIQUE,
        amount DECIMAL(10, 2) NOT NULL,
        tax_amount DECIMAL(10, 2) DEFAULT 0,
        currency TEXT DEFAULT 'USD',
        status TEXT DEFAULT 'draft',
        due_date DATETIME,
        paid_at DATETIME,
        notes TEXT,
        metadata TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS invoice_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoice_id INTEGER REFERENCES invoices(id) ON DELETE CASCADE,
        description TEXT NOT NULL,
        quantity INTEGER DEFAULT 1,
        unit_price DECIMAL(10, 2) NOT NULL,
        total DECIMAL(10, 2) NOT NULL,
        metadata TEXT
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS subscriptions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        plan_id INTEGER REFERENCES plans(id),
        addons TEXT,
        status TEXT,
        next_billing_date DATETIME,
        trial_ends_at DATETIME,
        cancelled_at DATETIME,
        metadata TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS wallets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        balance DECIMAL(10, 2) DEFAULT 0,
        currency TEXT DEFAULT 'USD',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS wallet_transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        amount DECIMAL(10, 2) NOT NULL,
        type TEXT NOT NULL,
        description TEXT,
        reference_id TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS coupons (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT NOT NULL UNIQUE,
        name TEXT,
        description TEXT,
        discount_type TEXT,
        discount_value DECIMAL(10, 2) NOT NULL,
        max_uses INTEGER,
        current_uses INTEGER DEFAULT 0,
        valid_from DATETIME,
        valid_until DATETIME,
        is_active BOOLEAN DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS affiliates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        referral_code TEXT NOT NULL UNIQUE,
        total_referrals INTEGER DEFAULT 0,
        total_earnings DECIMAL(10, 2) DEFAULT 0,
        balance DECIMAL(10, 2) DEFAULT 0,
        is_active BOOLEAN DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS affiliate_referrals (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        affiliate_id INTEGER REFERENCES affiliates(id) ON DELETE CASCADE,
        referred_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        commission_amount DECIMAL(10, 2),
        status TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS tickets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        subject TEXT NOT NULL,
        priority TEXT,
        category TEXT,
        status TEXT,
        assigned_to INTEGER REFERENCES users(id),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS ticket_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ticket_id INTEGER REFERENCES tickets(id) ON DELETE CASCADE,
        user_id INTEGER REFERENCES users(id),
        message TEXT NOT NULL,
        is_internal BOOLEAN DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS company_settings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        key TEXT NOT NULL UNIQUE,
        value TEXT,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS api_keys (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        name TEXT NOT NULL,
        key TEXT NOT NULL UNIQUE,
        permissions TEXT DEFAULT '["read"]',
        is_active BOOLEAN DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS server_commands (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        node_id INTEGER NOT NULL,
        server_id INTEGER NOT NULL,
        action TEXT NOT NULL CHECK(action IN ('start','stop','restart','kill')),
        status TEXT DEFAULT 'pending' CHECK(status IN ('pending','delivered','executed','failed')),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (node_id) REFERENCES nodes(id),
        FOREIGN KEY (server_id) REFERENCES servers(id)
    )`);
}

function runMigrations() {
    const migrations = [
        'ALTER TABLE notifications ADD COLUMN category TEXT DEFAULT "general"',
        'ALTER TABLE notifications ADD COLUMN metadata TEXT',
        'ALTER TABLE notifications ADD COLUMN updated_at DATETIME DEFAULT CURRENT_TIMESTAMP',
        'ALTER TABLE servers ADD COLUMN node_id INTEGER',
        'ALTER TABLE servers ADD COLUMN uuid TEXT',
        'ALTER TABLE backups ADD COLUMN uuid TEXT',
        'ALTER TABLE nodes ADD COLUMN mode TEXT DEFAULT "local"',
        'ALTER TABLE nodes ADD COLUMN last_heartbeat DATETIME',
        'ALTER TABLE nodes ADD COLUMN stats TEXT',
        'ALTER TABLE nodes ADD COLUMN daemon_ip TEXT',
        'ALTER TABLE nodes ADD COLUMN pending_command TEXT'
    ];

    migrations.forEach(sql => {
        db.run(sql, (err) => {
            if (err && !err.message.includes('duplicate column name')) {
                // Silently ignore - column already exists
            }
        });
    });

    // Refresh heartbeat for existing nodes so they show online after upgrade
    db.run("UPDATE nodes SET last_heartbeat = datetime('now') WHERE last_heartbeat IS NULL");
    // Set mode for existing nodes that predate the mode column
    db.run("UPDATE nodes SET mode = 'local' WHERE mode IS NULL");
}

function createAdminUser() {
    db.get('SELECT * FROM users WHERE username = ?', ['admin'], (err, row) => {
        if (!row) {
            const hashedPassword = bcrypt.hashSync('admin123', 10);
            db.run('INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)',
                ['admin', 'admin@example.com', hashedPassword, 'admin']
            );
            console.log('Admin user created (username: admin, password: admin123)');
        }
    });
}

function insertDefaultSettings() {
    const defaults = [
        { key: 'company_name', value: 'MC Hosting' },
        { key: 'company_email', value: 'support@example.com' },
        { key: 'company_address', value: '123 Main Street' },
        { key: 'currency', value: 'USD' }
    ];

    defaults.forEach(setting => {
        db.run(`INSERT OR IGNORE INTO company_settings (key, value) VALUES (?, ?)`,
            [setting.key, setting.value]
        );
    });

    // Create wallets for existing users
    db.all('SELECT id FROM users', [], (err, users) => {
        if (users) {
            users.forEach(user => {
                db.run('INSERT OR IGNORE INTO wallets (user_id, balance) VALUES (?, 0)', [user.id]);
            });
        }
    });
}

function loadSettings(globalSettings, app, resolve) {
    db.all('SELECT * FROM panel_settings', (err, rows) => {
        if (!err && rows) {
            rows.forEach(row => {
                try {
                    globalSettings[row.key] = JSON.parse(row.value);
                } catch {
                    globalSettings[row.key] = row.value;
                }
            });
        }
        globalSettings.maintenanceMode = false;
        app.locals.globalSettings = globalSettings;
        resolve();
    });
}

module.exports = { db, dbGet, dbAll, dbRun, initDatabase };
