const axios = require('axios');
const { SERVER_SOFTWARE } = require('../config/software');

async function fetchMinecraftVersions(serverType = 'vanilla', limit = null) {
    try {
        const software = SERVER_SOFTWARE[serverType];
        let versions = [];

        switch (serverType) {
            case 'vanilla':
                try {
                    const vanillaResponse = await axios.get(software.manifestUrl, { timeout: 10000 });
                    versions = vanillaResponse.data.versions
                        .filter(v => v.type === 'release')
                        .map(v => v.id);
                } catch (err) {
                    versions = getCompleteMinecraftVersions();
                }
                break;

            case 'paper':
            case 'waterfall':
            case 'velocity':
                try {
                    const paperResponse = await axios.get(software.manifestUrl, { timeout: 10000 });
                    versions = paperResponse.data.versions
                        .filter(v => !/-pre\d*$|-rc\d*$/i.test(v))
                        .reverse();
                } catch (err) {
                    versions = getCommonModernVersions();
                }
                break;

            case 'purpur':
                try {
                    const purpurResponse = await axios.get(software.manifestUrl, { timeout: 10000 });
                    versions = purpurResponse.data.versions
                        .filter(v => /^\d+\.\d+/.test(v) && !/-pre\d*$|-rc\d*$/i.test(v))
                        .reverse();
                } catch (err) {
                    versions = getCommonModernVersions();
                }
                break;

            case 'fabric':
            case 'quilt':
                try {
                    const fabricResponse = await axios.get(software.manifestUrl, { timeout: 10000 });
                    versions = fabricResponse.data
                        .filter(v => v.stable)
                        .map(v => v.version);
                } catch (err) {
                    versions = getCommonModernVersions();
                }
                break;

            case 'forge':
                try {
                    const forgeResponse = await axios.get(software.manifestUrl, { timeout: 10000 });
                    const promos = forgeResponse.data.promos;
                    versions = Object.keys(promos)
                        .filter(key => key.includes('-recommended') || key.includes('-latest'))
                        .map(key => key.split('-')[0])
                        .filter((v, i, arr) => arr.indexOf(v) === i)
                        .sort((a, b) => compareVersions(b, a));
                } catch (err) {
                    versions = getForgeCompatibleVersions();
                }
                break;

            case 'mohist':
                try {
                    const mohistResponse = await axios.get(software.manifestUrl, { timeout: 10000 });
                    versions = mohistResponse.data.versions.reverse();
                } catch (err) {
                    versions = getCommonModernVersions();
                }
                break;

            case 'spigot':
            case 'bukkit':
                versions = getSpigotCompatibleVersions();
                break;

            case 'bedrock':
                versions = getBedrockVersions();
                break;

            case 'nukkit':
                versions = ['1.20.1', '1.19.4', '1.19.2', '1.18.2', '1.17.1', '1.16.5'];
                break;

            case 'bungeecord':
                versions = getProxyCompatibleVersions();
                break;

            default:
                versions = getCompleteMinecraftVersions();
        }

        if (limit && limit > 0 && versions.length > limit) {
            versions = versions.slice(0, limit);
        }

        return versions.length > 0 ? versions : getCompleteMinecraftVersions();
    } catch (err) {
        return getCompleteMinecraftVersions();
    }
}

function getCompleteMinecraftVersions() {
    return [
        '1.21.11', '1.21.10', '1.21.9', '1.21.8', '1.21.7', '1.21.6',
        '1.21.5', '1.21.4', '1.21.3', '1.21.2', '1.21.1', '1.21',
        '1.20.6', '1.20.5', '1.20.4', '1.20.2', '1.20.1', '1.20',
        '1.19.4', '1.19.2', '1.19', '1.18.2', '1.18',
        '1.17.1', '1.17', '1.16.5', '1.16.1', '1.16',
        '1.15.2', '1.14.4', '1.13.2', '1.12.2', '1.11.2', '1.10.2',
        '1.9.4', '1.8.9', '1.8', '1.7.10', '1.7.2', '1.6.4'
    ];
}

function getCommonModernVersions() {
    return [
        '1.21.11', '1.21.10', '1.21.9', '1.21.8', '1.21.7', '1.21.6',
        '1.21.5', '1.21.4', '1.21.3', '1.21.2', '1.21.1', '1.21',
        '1.20.6', '1.20.5', '1.20.4', '1.20.2', '1.20.1', '1.20',
        '1.19.4', '1.19.2', '1.19', '1.18.2', '1.18',
        '1.17.1', '1.17', '1.16.5', '1.16.1', '1.16'
    ];
}

function getForgeCompatibleVersions() {
    return [
        '1.21.1', '1.21', '1.20.6', '1.20.4', '1.20.1', '1.20',
        '1.19.4', '1.19.2', '1.19', '1.18.2', '1.18.1', '1.17.1',
        '1.16.5', '1.16.4', '1.16.3', '1.16.1', '1.15.2', '1.14.4',
        '1.13.2', '1.12.2', '1.11.2', '1.10.2', '1.9.4', '1.8.9', '1.7.10'
    ];
}

function getSpigotCompatibleVersions() {
    return [
        '1.21.4', '1.21.3', '1.21.2', '1.21.1', '1.21',
        '1.20.6', '1.20.4', '1.20.2', '1.20.1', '1.20',
        '1.19.4', '1.19.3', '1.19.2', '1.19.1', '1.19',
        '1.18.2', '1.18.1', '1.18', '1.17.1', '1.17',
        '1.16.5', '1.16.4', '1.16.3', '1.16.2', '1.16.1',
        '1.15.2', '1.15.1', '1.14.4', '1.13.2', '1.12.2',
        '1.11.2', '1.10.2', '1.9.4', '1.8.8'
    ];
}

function getBedrockVersions() {
    return [
        '1.21.44', '1.21.43', '1.21.42', '1.21.41', '1.21.40',
        '1.21.31', '1.21.30', '1.21.23', '1.21.22', '1.21.21', '1.21.20',
        '1.21.2', '1.21.1', '1.21.0',
        '1.20.81', '1.20.80', '1.20.73', '1.20.72', '1.20.71', '1.20.70',
        '1.20.62', '1.20.61', '1.20.60', '1.20.51', '1.20.50',
        '1.20.41', '1.20.40', '1.20.32', '1.20.31', '1.20.30',
        '1.20.15', '1.20.12', '1.20.11', '1.20.10', '1.20.1', '1.20.0'
    ];
}

function getProxyCompatibleVersions() {
    return [
        '1.21.x', '1.20.x', '1.19.x', '1.18.x', '1.17.x', '1.16.x',
        '1.15.x', '1.14.x', '1.13.x', '1.12.x', '1.11.x', '1.10.x',
        '1.9.x', '1.8.x', '1.7.x'
    ];
}

function compareVersions(a, b) {
    const aParts = a.split('.').map(Number);
    const bParts = b.split('.').map(Number);
    for (let i = 0; i < Math.max(aParts.length, bParts.length); i++) {
        const aPart = aParts[i] || 0;
        const bPart = bParts[i] || 0;
        if (aPart > bPart) return 1;
        if (aPart < bPart) return -1;
    }
    return 0;
}

function isValidMinecraftVersion(version) {
    const patterns = [
        /^\d+\.\d+(\.\d+)?$/,
        /^\d+\.\d+\.\d+-\w+$/,
        /^\d+w\d+[a-z]$/,
        /^latest$/i,
        /^snapshot$/i
    ];
    return patterns.some(pattern => pattern.test(version.trim()));
}

module.exports = {
    fetchMinecraftVersions,
    compareVersions,
    isValidMinecraftVersion,
    getCompleteMinecraftVersions,
    getCommonModernVersions,
    getForgeCompatibleVersions,
    getSpigotCompatibleVersions,
    getBedrockVersions,
    getProxyCompatibleVersions
};
