const path = require('path');
const fs = require('fs');
const { SERVERS_DIR } = require('../config');

function resolveServerPath(serverId, requestedPath = '') {
    const base = path.resolve(SERVERS_DIR, serverId.toString());
    const full = path.resolve(path.join(base, requestedPath || ''));
    if (!full.startsWith(base)) throw new Error('Invalid path');
    return full;
}

function formatFileSize(bytes) {
    if (!bytes || bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function parseProperties(content) {
    const properties = {};
    content.split('\n').forEach(line => {
        line = line.trim();
        if (line && !line.startsWith('#')) {
            const [key, ...valueParts] = line.split('=');
            const value = valueParts.join('=').trim();
            if (key && value !== undefined) {
                if (value === 'true' || value === 'false') {
                    properties[key.trim()] = value === 'true';
                } else if (!isNaN(parseInt(value, 10))) {
                    properties[key.trim()] = parseInt(value, 10);
                } else {
                    properties[key.trim()] = value;
                }
            }
        }
    });
    return properties;
}

function writeProperties(properties, filePath) {
    const content = Object.entries(properties)
        .map(([key, value]) => `${key}=${value}`)
        .join('\n');
    fs.writeFileSync(filePath, content, 'utf8');
}

function writePropertiesString(properties) {
    return Object.entries(properties)
        .map(([key, value]) => `${key}=${value}`)
        .join('\n') + '\n';
}

function getDirSize(dir) {
    try {
        let size = 0;
        const walk = (p) => {
            const stats = fs.statSync(p);
            if (stats.isDirectory()) {
                fs.readdirSync(p).forEach(f => walk(path.join(p, f)));
            } else {
                size += stats.size;
            }
        };
        walk(dir);
        return size;
    } catch (err) {
        return 0;
    }
}

function generateRandomToken(length = 64) {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
}

function generateRandomSecret() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < 32; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

module.exports = {
    resolveServerPath,
    formatFileSize,
    parseProperties,
    writeProperties,
    writePropertiesString,
    getDirSize,
    generateRandomToken,
    generateRandomSecret
};
