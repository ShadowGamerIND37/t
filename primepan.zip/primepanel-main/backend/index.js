// PMS Backend - Panel Management System
// Modular backend for the Minecraft Server Panel

const config = require('./config');
const core = require('./core');

const serverLifecycle = require('./services/server/lifecycle');
const serverStats = require('./services/server/stats');
const serverLog = require('./services/server/log');
const serverDownload = require('./services/server/download');
const serverPort = require('./services/server/port');

const notificationService = require('./services/notification');
const activityService = require('./services/activity');
const pluginSearch = require('./services/plugin/search');
const wingsService = require('./services/wings/node');
const licenseService = require('./services/license');

const versionUtils = require('./core/versions');

const middleware = require('./middleware');
const routes = require('./routes');

module.exports = {
    config,
    core,
    services: {
        server: {
            lifecycle: serverLifecycle,
            stats: serverStats,
            log: serverLog,
            download: serverDownload,
            port: serverPort
        },
        notification: notificationService,
        activity: activityService,
        plugin: pluginSearch,
        wings: wingsService,
        license: licenseService
    },
    versions: versionUtils,
    middleware,
    routes
};
