// PMS Route Modules
const authMain = require('./auth-main');
const profileNotifications = require('./profile-notifications');
const servers = require('./servers');
const admin = require('./admin');

module.exports = {
    authMain,
    profileNotifications,
    servers,
    admin
};
