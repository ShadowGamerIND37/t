const path = require("path");
const fs = require("fs");
const bcrypt = require("bcryptjs");
const multer = require("multer");
const archiver = require("archiver");
const unzipper = require("unzipper");
const axios = require("axios");
const sanitize = require("sanitize-filename");
const { v4: uuidv4 } = require("uuid");
const crypto = require("crypto");
const yaml = require("js-yaml");
const os = require("os");
const net = require("net");

module.exports = function(app, deps) {
    const { 
        dbGet, dbAll, dbRun, db,
        globalSettings, liveStats, serverProcesses, onlinePlayers,
        requireAuth, requireAdmin, isAuthorized,
        getTemplateVars,
        isServerRunning, startServer, stopServer, restartServer, sendCommand,
        resolveServerPath, formatFileSize, parseProperties, writeProperties, getDirSize,
        logServerActivity, createNotification,
        downloadServerJar, updateServerConfigurationPort, ensureServerPortForType,
        findAvailablePortForServerType, getPortInformation, validateAndFixAllServerPorts,
        generateRandomToken, createNodeJWT, getNodeConnectionAddress, wingsRequest,
        fetchMinecraftVersions, getAvailableServerSoftware,
        DATA_DIR, SERVERS_DIR, APP_DIR,
        io, serverStartTimes, transferServer, DB_PATH,
        validateLicenseKey
    } = deps;

    const __panelRoot = APP_DIR || path.resolve(__dirname, "..", "..");

    // Multer config
    const upload = multer({
        dest: path.join(__panelRoot, "uploads/"),
        limits: { fileSize: 10 * 1024 * 1024 * 1024 }
    });

    // Payment gateway screenshot upload
    const pgUpload = multer({ dest: path.join(__panelRoot, "uploads/"), limits: { fileSize: 5 * 1024 * 1024 }, fileFilter: (req, file, cb) => cb(null, /image/.test(file.mimetype)) });
    const paymentScreenshotUpload = multer({ dest: path.join(__panelRoot, "uploads/"), limits: { fileSize: 10 * 1024 * 1024 }, fileFilter: (req, file, cb) => cb(null, /image\/(png|jpeg|jpg|gif|webp)/i.test(file.mimetype)) });

    // Helper: Save global settings to database
    function saveGlobalSettings() {
        app.locals.globalSettings = globalSettings;
        Object.entries(globalSettings).forEach(([key, value]) => {
            db.run(`INSERT OR REPLACE INTO panel_settings (key, value) VALUES (?, ?)`,
                [key, JSON.stringify(value)],
                (err) => {
                    if (err) console.error("Error saving setting:", err);
                }
            );
        });
    }

    // Helper functions for version display
    function getVersionDisplayString(version) {
        if (typeof version === "string") return version;
        if (typeof version === "object" && version !== null) {
            return version.version || version.tag || version.name || version.v || String(version);
        }
        return String(version);
    }

    function normalizeVersion(version) {
        return getVersionDisplayString(version).replace(/^v/i, "");
    }

    // Helper function to copy directory recursively
    function copyDirectoryRecursive(source, destination) {
        if (!fs.existsSync(destination)) {
            fs.mkdirSync(destination, { recursive: true });
        }
        const entries = fs.readdirSync(source, { withFileTypes: true });
        for (const entry of entries) {
            const srcPath = path.join(source, entry.name);
            const destPath = path.join(destination, entry.name);
            if (entry.isDirectory()) {
                copyDirectoryRecursive(srcPath, destPath);
            } else {
                fs.copyFileSync(srcPath, destPath);
            }
        }
    }

    // License verification - uses external license manager via backend/services/license.js
    // verifyLicenseKey is provided via deps

    // Progress tracking (shared via deps)
    const { installProgress, deleteProgress, reinstallProgress,
            setInstallProgress, setDeleteProgress, setReinstallProgress } = deps;
    function delay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

// ================================================
app.get('/admin', requireAdmin, async (req, res) => {
    try {
        const users = await dbAll('SELECT * FROM users ORDER BY created_at DESC');
        const servers = await dbAll('SELECT * FROM servers ORDER BY created_at DESC');
     
        res.render('admin/index', await getTemplateVars(req, null, {
            users,
            servers,
            stats: {
                totalUsers: users.length,
                totalServers: servers.length,
                activeServers: servers.filter(s => s.status === 'running').length
            },
            systemInfo: {
                cpuCores: os.cpus().length,
                totalMemory: Math.round(os.totalmem() / 1024 / 1024 / 1024) + ' GB',
                freeMemory: Math.round(os.freemem() / 1024 / 1024 / 1024) + ' GB',
                platform: os.platform(),
                nodeVersion: process.version,
                uptime: process.uptime()
            },
            title: 'Admin Dashboard'
        }));
    } catch (err) {
        console.error('Admin dashboard error:', err);
        res.status(500).render('error', await getTemplateVars(req, null, { message: 'Failed to load admin panel', status: 500, title: 'Error' }));
    }
});

// API Key Management
app.get('/admin/api', requireAdmin, async (req, res) => {
    try {
        const users = await dbAll('SELECT id, username FROM users');
        const apiKeys = await dbAll(`
            SELECT api_keys.*, users.username 
            FROM api_keys 
            JOIN users ON api_keys.user_id = users.id 
            ORDER BY api_keys.created_at DESC
        `);
        
        res.render('admin/api', await getTemplateVars(req, null, {
            users,
            apiKeys,
            title: 'API Key Management'
        }));
    } catch (err) {
        console.error('API keys page error:', err);
        res.status(500).render('error', await getTemplateVars(req, null, { 
            message: 'Failed to load API keys', 
            status: 500, 
            title: 'Error' 
        }));
    }
});

// Create API key
app.post('/admin/api/keys', requireAdmin, async (req, res) => {
    try {
        const { name, userId, permissions } = req.body;
        const { v4: uuidv4 } = require('uuid');
        const apiKey = 'mcpanel_' + uuidv4().replace(/-/g, '');
        
        await dbRun(
            'INSERT INTO api_keys (user_id, name, key, permissions) VALUES (?, ?, ?, ?)',
            [userId, name, apiKey, JSON.stringify(permissions || ['read'])]
        );
        
        res.status(201).json({ success: true, key: apiKey });
    } catch (err) {
        console.error('Create API key error:', err);
        res.status(500).json({ success: false, error: 'Failed to create API key' });
    }
});

// Delete API key
app.delete('/admin/api/keys/:id', requireAdmin, async (req, res) => {
    try {
        await dbRun('DELETE FROM api_keys WHERE id = ?', [req.params.id]);
        res.json({ success: true });
    } catch (err) {
        console.error('Delete API key error:', err);
        res.status(500).json({ success: false, error: 'Failed to delete API key' });
    }
});

// User management
app.get('/admin/users', requireAdmin, async (req, res) => {
  try {
      const search = req.query.search || '';
      const role = req.query.role || '';
      const status = req.query.status || '';
      
      let query = 'SELECT * FROM users WHERE 1=1';
      const params = [];
      
      if (search) {
          query += ' AND (username LIKE ? OR email LIKE ?)';
          const term = `%${search}%`;
          params.push(term, term);
      }
      
      if (role) {
          query += ' AND role = ?';
          params.push(role);
      }
      
      if (status) {
          query += ' AND status = ?';
          params.push(status);
      }
      
      query += ' ORDER BY created_at DESC';
      const users = await dbAll(query, params);
      
      res.render('admin/users', await getTemplateVars(req, null, {
          users,
          search,
          role,
          status,
          title: 'User Management'
      }));
  } catch (err) {
      console.error('Admin users error:', err);
      res.status(500).render('error', await getTemplateVars(req, null, {
          message: 'Failed to load users',
          status: 500,
          title: 'Error'
      }));
  }
});

// User create page
app.get('/admin/users/create', requireAdmin, async (req, res) => {
  try {
      res.render('admin/user-create', await getTemplateVars(req, null, {
          title: 'Create User'
      }));
  } catch (err) {
      console.error('User create page error:', err);
      res.status(500).render('error', await getTemplateVars(req, null, {
          message: 'Failed to load create page',
          status: 500,
          title: 'Error'
      }));
  }
});

// User edit page
app.get('/admin/users/:id/edit', requireAdmin, async (req, res) => {
  try {
      const userId = req.params.id;
      console.log('=== USER EDIT ROUTE HIT ===');
      console.log('User edit page requested for user ID:', userId);
      console.log('Full URL:', req.url);
      console.log('Path:', req.path);
      console.log('Params:', req.params);
      
      const editUser = await dbGet('SELECT * FROM users WHERE id = ?', [userId]);
      
      if (!editUser) {
          console.log('User not found:', userId);
          return res.status(404).render('error', await getTemplateVars(req, null, {
              message: `User with ID ${userId} not found`,
              status: 404,
              title: 'User Not Found'
          }));
      }
      
      console.log('User found:', editUser.username);
      res.render('admin/user-edit', await getTemplateVars(req, null, {
          editUser,
          title: `Edit User - ${editUser.username}`
      }));
  } catch (err) {
      console.error('User edit page error:', err);
      res.status(500).render('error', await getTemplateVars(req, null, {
          message: 'Failed to load edit page',
          status: 500,
          title: 'Error'
      }));
  }
});

app.post('/admin/users/create', requireAdmin, async (req, res) => {
    try {
        console.log('Create user request received:', {
            body: req.body,
            hasUsername: !!req.body.username,
            hasEmail: !!req.body.email,
            hasPassword: !!req.body.password,
            hasRole: !!req.body.role
        });
        
        const { username, email, password, role, status } = req.body;
     
        if (!username || !email || !password || !role) {
            console.log('Validation failed: Missing required fields');
            return res.status(400).json({ error: 'All fields are required' });
        }
        
        // Validate username format
        if (!/^[a-zA-Z0-9_-]+$/.test(username)) {
            console.log('Validation failed: Invalid username format');
            return res.status(400).json({ error: 'Username can only contain letters, numbers, underscores, and hyphens' });
        }
        
        // Validate username length
        if (username.length < 3 || username.length > 32) {
            console.log('Validation failed: Invalid username length');
            return res.status(400).json({ error: 'Username must be between 3 and 32 characters' });
        }
        
        // Validate password length
        if (password.length < 6) {
            console.log('Validation failed: Password too short');
            return res.status(400).json({ error: 'Password must be at least 6 characters' });
        }
     
        const existing = await dbGet(
            'SELECT * FROM users WHERE username = ? OR email = ?',
            [username, email]
        );
     
        if (existing) {
            console.log('Validation failed: Username or email already exists');
            return res.status(400).json({ error: 'Username or email already exists' });
        }
     
        console.log('Creating user:', username);
        const hashedPassword = await bcrypt.hash(password, 10);
        await dbRun(
            'INSERT INTO users (username, email, password, role, status) VALUES (?, ?, ?, ?, ?)',
            [username, email, hashedPassword, role, status || 'active']
        );
     
        console.log('User created successfully:', username);
        
        // Redirect to users list instead of JSON response
        res.redirect('/admin/users');
    } catch (err) {
        console.error('Create user error:', err);
        res.status(500).json({ error: 'Failed to create user: ' + err.message });
    }
});

app.post('/admin/users/:id/update', requireAdmin, async (req, res) => {
    try {
        console.log('Update user request received:', {
            userId: req.params.id,
            body: req.body,
            hasUsername: !!req.body.username,
            hasEmail: !!req.body.email,
            hasRole: !!req.body.role,
            hasStatus: !!req.body.status,
            hasPassword: !!req.body.password
        });
        
        const { username, email, role, status, password } = req.body;
        const userId = req.params.id;
     
        if (!username || !email || !role || !status) {
            console.log('Validation failed: Missing required fields');
            return res.status(400).json({ error: 'All fields are required' });
        }
        
        // Validate username format
        if (!/^[a-zA-Z0-9_-]+$/.test(username)) {
            console.log('Validation failed: Invalid username format');
            return res.status(400).json({ error: 'Username can only contain letters, numbers, underscores, and hyphens' });
        }
        
        // Validate username length
        if (username.length < 3 || username.length > 32) {
            console.log('Validation failed: Invalid username length');
            return res.status(400).json({ error: 'Username must be between 3 and 32 characters' });
        }
     
        const existing = await dbGet(
            'SELECT * FROM users WHERE (username = ? OR email = ?) AND id != ?',
            [username, email, userId]
        );
     
        if (existing) {
            console.log('Validation failed: Username or email already in use');
            return res.status(400).json({ error: 'Username or email already in use' });
        }
        
        // Update user with or without password
        if (password && password.length > 0) {
            // Validate password length
            if (password.length < 6) {
                console.log('Validation failed: Password too short');
                return res.status(400).json({ error: 'Password must be at least 6 characters' });
            }
            
            console.log('Updating user with new password:', username);
            const hashedPassword = await bcrypt.hash(password, 10);
            await dbRun(
                'UPDATE users SET username = ?, email = ?, role = ?, status = ?, password = ? WHERE id = ?',
                [username, email, role, status, hashedPassword, userId]
            );
        } else {
            console.log('Updating user without password change:', username);
            await dbRun(
                'UPDATE users SET username = ?, email = ?, role = ?, status = ? WHERE id = ?',
                [username, email, role, status, userId]
            );
        }
     
        console.log('User updated successfully:', username);
        
        // Redirect to users list instead of JSON response
        res.redirect('/admin/users');
    } catch (err) {
        console.error('Update user error:', err);
        res.status(500).json({ error: 'Failed to update user: ' + err.message });
    }
});
app.post('/admin/users/:id/delete', requireAdmin, async (req, res) => {
    try {
        const userId = req.params.id;
        
        console.log('Delete user request received:', { userId });
     
        // Check if user has servers
        const userServers = await dbAll('SELECT * FROM servers WHERE owner_id = ?', [userId]);
        if (userServers.length > 0) {
            console.log('Validation failed: User has active servers');
            return res.status(400).json({
                error: 'Cannot delete user with active servers'
            });
        }
     
        console.log('Deleting user:', userId);
        await dbRun('DELETE FROM users WHERE id = ?', [userId]);
        console.log('User deleted successfully:', userId);
        
        // Redirect to users list instead of JSON response
        res.redirect('/admin/users');
    } catch (err) {
        console.error('Delete user error:', err);
        res.status(500).json({ error: 'Failed to delete user: ' + err.message });
    }
});
// Server management
app.get('/admin/servers', requireAdmin, async (req, res) => {
  try {
      const search = req.query.search ? req.query.search.trim() : '';
      const type = req.query.type ? req.query.type.trim() : '';
      const status = req.query.status ? req.query.status.trim() : '';
      
      let query = `
          SELECT s.*, 
                 u.username AS owner_name,
                 a.ip AS allocation_ip, a.alias AS allocation_alias, a.port AS allocation_port,
                 n.name AS node_name
          FROM servers s
          LEFT JOIN users u ON s.owner_id = u.id
          LEFT JOIN allocations a ON s.id = a.server_id
          LEFT JOIN nodes n ON s.node_id = n.id
      `;
      const params = [];
      const conditions = [];
      
      if (search) {
          conditions.push('(s.name LIKE ? OR u.username LIKE ?)');
          const term = `%${search}%`;
          params.push(term, term);
      }
      
      if (type) {
          conditions.push('s.server_type = ?');
          params.push(type);
      }
      
      if (status) {
          conditions.push('s.status = ?');
          params.push(status);
      }
      
      if (conditions.length > 0) {
          query += ' WHERE ' + conditions.join(' AND ');
      }
      
      query += ' ORDER BY s.created_at DESC';
      const servers = await dbAll(query, params);
      
      res.render('admin/servers', await getTemplateVars(req, null, {
          servers,
          search,
          type,
          status,
          title: 'Server Management'
      }));
  } catch (err) {
      console.error('Admin servers error:', err);
      res.status(500).render('error', await getTemplateVars(req, null, {
          message: 'Failed to load servers',
          status: 500,
          title: 'Error'
      }));
  }
});
// New GET route for server create form
app.get('/admin/servers/create', requireAdmin, async (req, res) => {
    try {
        const users = await dbAll('SELECT id, username, email FROM users ORDER BY username ASC');
        const nodes = await dbAll('SELECT * FROM nodes WHERE maintenance_mode = 0 ORDER BY name ASC');
        // Get all available allocations (not assigned to any server)
        const allocations = await dbAll(`
            SELECT a.*, n.name AS node_name 
            FROM allocations a 
            JOIN nodes n ON a.node_id = n.id 
            WHERE a.server_id IS NULL 
            ORDER BY n.name, a.port ASC
        `);
        res.render('admin/server-create', await getTemplateVars(req, null, {
            users,
            nodes,
            allocations,
            title: 'Create Server'
        }));
    } catch (err) {
        console.error('Server create form error:', err);
        res.status(500).render('error', await getTemplateVars(req, null, {
            message: 'Failed to load create form',
            status: 500,
            title: 'Error'
        }));
    }
});

// GET route for server edit form
app.get('/admin/servers/:id/edit', requireAdmin, async (req, res) => {
    try {
        const serverId = req.params.id;
        const editServer = await dbGet(
            'SELECT s.*, u.username AS owner_name FROM servers s LEFT JOIN users u ON s.owner_id = u.id WHERE s.id = ?',
            [serverId]
        );
        
        if (!editServer) {
            return res.status(404).render('error', await getTemplateVars(req, null, {
                message: 'Server not found',
                status: 404,
                title: 'Error'
            }));
        }
        
        const users = await dbAll('SELECT id, username, email FROM users ORDER BY username ASC');
        const nodes = await dbAll('SELECT * FROM nodes ORDER BY name ASC');
        const currentNode = editServer.node_id ? await dbGet('SELECT * FROM nodes WHERE id = ?', [editServer.node_id]) : null;
        
        res.render('admin/server-edit', await getTemplateVars(req, null, {
            editServer,
            users,
            nodes,
            currentNode,
            title: `Edit Server - ${editServer.name}`
        }));
    } catch (err) {
        console.error('Server edit page error:', err);
        res.status(500).render('error', await getTemplateVars(req, null, {
            message: 'Failed to load edit page',
            status: 500,
            title: 'Error'
        }));
    }
});

// POST route for server update
app.post('/admin/servers/:id/update', requireAdmin, async (req, res) => {
    try {
        const serverId = req.params.id;
        const { name, owner_id, version, port, ram, cpu, disk } = req.body;
        
        if (!name || !owner_id || !version || !port || !ram || !cpu || !disk) {
            return res.status(400).json({ error: 'All fields are required' });
        }
        
        // Validate name length
        if (name.length < 3 || name.length > 64) {
            return res.status(400).json({ error: 'Server name must be between 3 and 64 characters' });
        }
        
        // Validate port range
        const portNum = parseInt(port);
        if (isNaN(portNum) || portNum < 1024 || portNum > 65535) {
            return res.status(400).json({ error: 'Port must be between 1024 and 65535' });
        }
        
        // Validate RAM
        const ramNum = parseInt(ram);
        if (isNaN(ramNum) || ramNum < 512) {
            return res.status(400).json({ error: 'RAM must be at least 512 MB' });
        }
        
        // Validate CPU
        const cpuNum = parseInt(cpu);
        if (isNaN(cpuNum) || cpuNum < 1) {
            return res.status(400).json({ error: 'CPU must be at least 1 core' });
        }
        
        // Validate Disk
        const diskNum = parseInt(disk);
        if (isNaN(diskNum) || diskNum < 1024) {
            return res.status(400).json({ error: 'Disk must be at least 1024 MB (1 GB)' });
        }
        
        // Check if port is already in use by another server
        const portCheck = await dbGet(
            'SELECT * FROM servers WHERE port = ? AND id != ?',
            [portNum, serverId]
        );
        
        if (portCheck) {
            return res.status(400).json({ error: 'Port is already in use by another server' });
        }
        
        await dbRun(
            'UPDATE servers SET name = ?, owner_id = ?, version = ?, port = ?, ram = ?, cpu = ?, disk = ? WHERE id = ?',
            [name, owner_id, version, portNum, ramNum, cpuNum, diskNum, serverId]
        );
        
        res.redirect('/admin/servers');
    } catch (err) {
        console.error('Update server error:', err);
        res.status(500).json({ error: 'Failed to update server' });
    }
});

// API endpoint to fetch versions for a server type (public - no auth required)
app.get('/api/versions/:serverType', async (req, res) => {
    try {
        const serverType = req.params.serverType;
        const limit = req.query.limit ? parseInt(req.query.limit) : 20;
        
        const versions = await fetchMinecraftVersions(serverType, limit);
        res.json({ success: true, versions });
    } catch (err) {
        console.error('Fetch versions error:', err);
        res.status(500).json({ error: 'Failed to fetch versions' });
    }
});

// API endpoint to get port information for a specific server
app.get('/api/servers/:id/port-info', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }
        
        const portInfo = getPortInformation(serverId, server.server_type, server.port);
        res.json({ success: true, portInfo });
        
    } catch (err) {
        console.error('Error getting port information:', err);
        res.status(500).json({ error: 'Failed to get port information' });
    }
});

// API endpoint to get available port ranges and server type information
app.get('/api/port-ranges', requireAuth, (req, res) => {
    try {
        const ranges = {
            'Java Edition': PORT_CONFIG.JAVA_EDITION,
            'Proxy Servers': PORT_CONFIG.PROXY_SERVERS,
            'Bedrock Edition': PORT_CONFIG.BEDROCK_EDITION
        };
        
        res.json({
            success: true,
            ranges: ranges,
            reservedPorts: PORT_CONFIG.RESERVED_PORTS,
            serverTypes: {
                java: ['vanilla', 'paper', 'purpur', 'spigot', 'bukkit', 'fabric', 'forge', 'quilt', 'mohist', 'catserver'],
                proxy: ['velocity', 'bungeecord', 'waterfall'],
                bedrock: ['bedrock', 'nukkit']
            },
            protectionLevels: {
                'Java Edition': 'Standard Protection - Automatic port management in range 25565-25665',
                'Proxy Servers': 'High Protection - Network isolation in dedicated range 25700-25799',
                'Bedrock Edition': 'Medium Protection - Cross-platform compatibility in range 19132-19232'
            }
        });
        
    } catch (err) {
        console.error('Error getting port ranges:', err);
        res.status(500).json({ error: 'Failed to get port ranges' });
    }
});
app.post('/admin/servers/create', requireAdmin, async (req, res) => {
    try {
        let { name, owner_id, ram, cpu, disk, port, version, server_type, server_ip = '', ip_alias = '', port_alias = '', allocation_id } = req.body;
        
        // Trim and validate required fields
        if (!name || (name = name.trim()) === '') {
            return res.status(400).json({ error: 'Server name is required' });
        }
        if (!owner_id || isNaN(owner_id) || (owner_id = parseInt(owner_id)) <= 0) {
            return res.status(400).json({ error: 'Valid owner user ID is required' });
        }
        if (!ram || isNaN(ram) || (ram = parseInt(ram)) < 512) {
            return res.status(400).json({ error: 'RAM must be at least 512 MB' });
        }
        
        let nodeId = null;
        let assignedPort = null;
        let serverIp = server_ip;
        let allocationAlias = ip_alias;
        
        if (allocation_id) {
            // Use the selected allocation
            const allocation = await dbGet('SELECT * FROM allocations WHERE id = ?', [allocation_id]);
            if (!allocation) {
                return res.status(400).json({ error: 'Invalid allocation selected' });
            }
            if (allocation.server_id) {
                return res.status(400).json({ error: 'This allocation is already in use' });
            }
            nodeId = allocation.node_id;
            assignedPort = allocation.port;
            serverIp = allocation.ip;
            allocationAlias = allocation.alias || ip_alias;
        } else {
            // If no allocation, use the old method
            if (!port || isNaN(port) || (port = parseInt(port)) < 1024 || port > 65535) {
                return res.status(400).json({ error: 'Valid port between 1024-65535 is required' });
            }
            // Smart Port Protection: Assign port based on server type
            assignedPort = await findAvailablePortForServerType(server_type);
            console.log(`Auto-assigned ${getPortRangeForServerType(server_type).CATEGORY} port ${assignedPort} for new ${server_type} server: ${name}`);
        }
        
        // Validate CPU
        cpu = parseInt(cpu) || 2;
        if (isNaN(cpu) || cpu < 1) {
            return res.status(400).json({ error: 'CPU must be at least 1 core' });
        }
        
        // Validate Disk
        disk = parseInt(disk) || 10240;
        if (isNaN(disk) || disk < 1024) {
            return res.status(400).json({ error: 'Disk must be at least 1024 MB (1 GB)' });
        }
        version = (version && version.trim()) || 'latest';
        server_type = (server_type && server_type.trim()) || 'vanilla';
        ip_alias = (ip_alias && ip_alias.trim()) || '';
        port_alias = (port_alias && port_alias.trim()) || '';
        // Check if owner exists
        const owner = await dbGet('SELECT * FROM users WHERE id = ?', [owner_id]);
        if (!owner) {
            return res.status(404).json({ error: 'Owner user not found' });
        }
        
        // Insert into database
        const serverUuid = uuidv4();
        const result = await dbRun(
            `INSERT INTO servers (uuid, name, owner_id, ram, cpu, disk, port, server_ip, ip_alias, port_alias, version, server_type, settings, node_id)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                serverUuid,
                name,
                owner_id,
                ram,
                cpu,
                disk,
                assignedPort,
                serverIp,
                allocationAlias,
                port_alias,
                version,
                server_type,
                JSON.stringify({ autoRestart: true }),
                nodeId
            ]
        );
        const sId = result.lastID.toString();
        
        // If we used an allocation, mark it as used
        if (allocation_id) {
            await dbRun('UPDATE allocations SET server_id = ? WHERE id = ?', [sId, allocation_id]);
        }
        
        setInstallProgress(sId, 'Initializing server...', 5);

        // Create server directory
        const serverDir = path.join(SERVERS_DIR, sId);
        fs.mkdirSync(serverDir, { recursive: true });
        setInstallProgress(sId, 'Creating directory...', 10);
        
        // Return serverId immediately, then do the rest async!
        res.json({ success: true, serverId: sId });

        // Do the rest of installation asynchronously so the user can see the install animation!
        (async () => {
            try {
                setInstallProgress(sId, 'Downloading server jar...', 20);
                const actualVersion = await downloadServerJar(server_type, version, serverDir);
                setInstallProgress(sId, 'Download complete', 70);
                
                if (version === 'latest') {
                    await dbRun('UPDATE servers SET version = ? WHERE id = ?', [actualVersion, sId]);
                }
                
                setInstallProgress(sId, 'Creating eula.txt...', 80);
                fs.writeFileSync(path.join(serverDir, 'eula.txt'), 'eula=true\n', 'utf8');
                
                setInstallProgress(sId, 'Creating server.properties...', 90);
                const properties = {
                    'server-port': assignedPort,
                    'server-ip': serverIp,
                    'max-players': 20,
                    'online-mode': true,
                    'view-distance': 10,
                    'simulation-distance': 10,
                    'motd': name
                };
                writeProperties(properties, path.join(serverDir, 'server.properties'));
                
                setInstallProgress(sId, 'Starting server...', 95);
                try {
                    await deps.startServer(sId);
                    setInstallProgress(sId, 'Server is online!', 100, true);
                } catch (startErr) {
                    console.error('Auto-start error:', startErr);
                    setInstallProgress(sId, 'Installation complete. Click Start to run.', 100, true);
                }
                
            } catch(e) {
                console.error('Server installation error:', e);
                setInstallProgress(sId, `Error: ${e.message}`, 0, true, e.message);
            }
        })();
        
    } catch (err) {
        console.error('Create server error:', err);
        res.status(500).json({ error: 'Failed to create server. Check server logs.' });
    }
});
app.post('/admin/servers/:id/update', requireAdmin, async (req, res) => {
    try {
        const serverId = req.params.id;
        let { name, ram, cpu, disk, server_ip = '', ip_alias = '', port_alias = '' } = req.body;
        if (!name || (name = name.trim()) === '') {
            return res.status(400).json({ error: 'Server name is required' });
        }
        if (!ram || isNaN(ram) || (ram = parseInt(ram)) < 512) {
            return res.status(400).json({ error: 'RAM must be at least 512 MB' });
        }
        if (server_ip && net.isIP(server_ip) === 0) {
            return res.status(400).json({ error: 'Invalid IP address' });
        }
        cpu = parseInt(cpu) || 1;
        disk = parseInt(disk) || 1024;
        ip_alias = (ip_alias && ip_alias.trim()) || '';
        port_alias = (port_alias && port_alias.trim()) || '';
        
        // Get current server info (port is auto-managed and cannot be changed)
        const currentServer = await dbGet('SELECT port FROM servers WHERE id = ?', [serverId]);
        if (!currentServer) {
            return res.status(404).json({ error: 'Server not found' });
        }
        // Update server (port is auto-managed and not changed)
        await dbRun(
            'UPDATE servers SET name = ?, ram = ?, cpu = ?, disk = ?, server_ip = ?, ip_alias = ?, port_alias = ? WHERE id = ?',
            [name, ram, cpu, disk, server_ip, ip_alias, port_alias, serverId]
        );
        
        // Ensure server.properties has correct port (auto-managed)
        await updateServerPropertiesPort(serverId, currentServer.port);
        
        res.json({ 
            success: true, 
            message: 'Server updated successfully! (Port is auto-managed and cannot be changed)',
            port: currentServer.port
        });
    } catch (err) {
        console.error('Update server error:', err);
        res.status(500).json({ error: 'Failed to update server' });
    }
});
app.post('/admin/servers/:id/delete', requireAdmin, async (req, res) => {
    try {
        const serverId = req.params.id;
        console.log('Deleting server:', serverId);

        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }

        // Initialize delete progress
        setDeleteProgress(serverId, 'Initializing...', 0, false, null);
        res.json({ success: true, redirectTo: `/servers/${serverId}/deleting` });

        // Run delete in background
        (async () => {
            try {
                await delay(300);
                // Step 1: Stop server
                setDeleteProgress(serverId, 'Stopping server...', 10, false, null);
                await stopServer(serverId, true);
                await delay(500);

                // Step 1.5: Free up the allocation if any
                await dbRun('UPDATE allocations SET server_id = NULL WHERE server_id = ?', [serverId]);

                // Step 2: Delete server files
                setDeleteProgress(serverId, 'Deleting server files...', 30, false, null);
                const serverDir = path.join(SERVERS_DIR, serverId);
                if (fs.existsSync(serverDir)) {
                    fs.rmSync(serverDir, { recursive: true, force: true });
                }
                await delay(500);

                // Step 3: Delete backups
                setDeleteProgress(serverId, 'Deleting backups...', 55, false, null);
                const backupDir = path.join(__panelRoot, 'backups', serverId);
                if (fs.existsSync(backupDir)) {
                    fs.rmSync(backupDir, { recursive: true, force: true });
                }
                await delay(500);

                // Step 4: Remove from database
                setDeleteProgress(serverId, 'Removing from database...', 80, false, null);
                await dbRun('DELETE FROM servers WHERE id = ?', [serverId]);
                await delay(500);

                // Step 5: Clean up
                setDeleteProgress(serverId, 'Cleaning up...', 95, false, null);
                delete global.serverProcesses[serverId];
                delete serverStartTimes[serverId];
                delete onlinePlayers[serverId];
                delete liveStats[serverId];
                delete installProgress[serverId];
                // Don't delete deleteProgress yet!
                await delay(500);

                setDeleteProgress(serverId, 'Server deleted successfully!', 100, true, null);
                console.log('Server deleted successfully:', serverId);
            } catch (err) {
                console.error('Delete server error:', err);
                setDeleteProgress(serverId, `Error: ${err.message}`, 0, true, err.message);
            }
        })();
    } catch (err) {
        console.error('Delete server error:', err);
        res.status(500).json({ error: 'Failed to delete server: ' + err.message });
    }
});

// Reinstall server (change version/type with advanced options)
app.post('/admin/servers/:id/reinstall', requireAdmin, async (req, res) => {
    try {
        const serverId = req.params.id;
        const { server_type, version, cleanOptions = {} } = req.body;

        if (!server_type || !version) {
            return res.status(400).json({ error: 'Server type and version are required' });
        }

        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }

        // Initialize reinstall progress
        setReinstallProgress(serverId, 'Initializing...', 0, false, null);
        res.json({ success: true, redirectTo: `/servers/${serverId}/reinstalling` });

        // Run reinstall in background
        (async () => {
            try {
                await delay(300);
                const serverDir = resolveServerPath(serverId);
                const cleaningActions = [];

                // Step 1: Stop server if running
                setReinstallProgress(serverId, 'Stopping server...', 10, false, null);
                if (await isServerRunning(serverId)) {
                    await stopServer(serverId, true);
                }
                await delay(500);

                // Step 2: Backup important files
                setReinstallProgress(serverId, 'Backing up important files...', 25, false, null);
                const backupFiles = ['server.properties', 'ops.json', 'whitelist.json', 'banned-players.json', 'banned-ips.json'];
                const backupData = {};
                backupFiles.forEach(file => {
                    const filePath = path.join(serverDir, file);
                    if (fs.existsSync(filePath)) {
                        backupData[file] = fs.readFileSync(filePath, 'utf8');
                    }
                });
                await delay(500);

                // Always delete server core files
                setReinstallProgress(serverId, 'Cleaning core files...', 35, false, null);
                const coreFilesToDelete = ['server.jar', 'libraries', 'versions', 'cache'];
                coreFilesToDelete.forEach(file => {
                    const filePath = path.join(serverDir, file);
                    if (fs.existsSync(filePath)) {
                        const stats = fs.statSync(filePath);
                        if (stats.isDirectory()) {
                            fs.rmSync(filePath, { recursive: true, force: true });
                        } else {
                            fs.unlinkSync(filePath);
                        }
                    }
                });
                await delay(500);

                // Optional cleaning based on user selection
                if (cleanOptions.cleanPlugins) {
                    const pluginsDir = path.join(serverDir, 'plugins');
                    if (fs.existsSync(pluginsDir)) {
                        fs.rmSync(pluginsDir, { recursive: true, force: true });
                        fs.mkdirSync(pluginsDir, { recursive: true });
                        cleaningActions.push('Plugins');
                    }
                }
                if (cleanOptions.cleanWorlds) {
                    const worldFolders = ['world', 'world_nether', 'world_the_end'];
                    worldFolders.forEach(worldFolder => {
                        const worldPath = path.join(serverDir, worldFolder);
                        if (fs.existsSync(worldPath)) {
                            fs.rmSync(worldPath, { recursive: true, force: true });
                            cleaningActions.push(worldFolder);
                        }
                    });
                }
                if (cleanOptions.cleanLogs) {
                    const logsDir = path.join(serverDir, 'logs');
                    if (fs.existsSync(logsDir)) {
                        fs.rmSync(logsDir, { recursive: true, force: true });
                        fs.mkdirSync(logsDir, { recursive: true });
                        cleaningActions.push('Logs');
                    }
                }
                if (cleanOptions.cleanConfigs) {
                    const configFolders = ['config', 'configurations'];
                    configFolders.forEach(configFolder => {
                        const configPath = path.join(serverDir, configFolder);
                        if (fs.existsSync(configPath)) {
                            fs.rmSync(configPath, { recursive: true, force: true });
                            cleaningActions.push('Configs');
                        }
                    });
                    const configFiles = ['bukkit.yml', 'spigot.yml', 'paper.yml', 'purpur.yml', 'commands.yml', 'help.yml'];
                    configFiles.forEach(file => {
                        const filePath = path.join(serverDir, file);
                        if (fs.existsSync(filePath)) {
                            fs.unlinkSync(filePath);
                        }
                    });
                }
                if (cleanOptions.cleanBackups) {
                    const backupsDir = path.join(__panelRoot, 'backups', serverId.toString());
                    if (fs.existsSync(backupsDir)) {
                        fs.rmSync(backupsDir, { recursive: true, force: true });
                        fs.mkdirSync(backupsDir, { recursive: true });
                        cleaningActions.push('Backups');
                    }
                }
                await delay(500);

                // Step 3: Download server jar
                setReinstallProgress(serverId, 'Downloading server jar...', 50, false, null);
                console.log(`🔄 Reinstalling server with ${server_type} ${version}...`);
                const actualVersion = await downloadServerJar(server_type, version, serverDir);
                await delay(500);

                // Step 4: Update database
                setReinstallProgress(serverId, 'Updating database...', 65, false, null);
                await dbRun(
                    'UPDATE servers SET server_type = ?, version = ? WHERE id = ?',
                    [server_type, actualVersion, serverId]
                );
                await delay(500);

                // Step 5: Restore backed up files and write EULA
                setReinstallProgress(serverId, 'Restoring configuration...', 75, false, null);
                Object.entries(backupData).forEach(([file, content]) => {
                    fs.writeFileSync(path.join(serverDir, file), content, 'utf8');
                });
                const eulaPath = path.join(serverDir, 'eula.txt');
                if (!fs.existsSync(eulaPath)) {
                    fs.writeFileSync(eulaPath, 'eula=true\n', 'utf8');
                }
                await delay(500);

                // Step 6: Finalize
                setReinstallProgress(serverId, 'Finalizing...', 95, false, null);
                await delay(500);
                let message = `✅ Server reinstalled successfully with ${server_type} ${actualVersion}!`;
                if (cleaningActions.length > 0) {
                    message += `\nCleaned: ${cleaningActions.join(', ')}`;
                }
                setReinstallProgress(serverId, 'Server reinstalled successfully!', 100, true, null);
            } catch (err) {
                console.error('Reinstall server error:', err);
                setReinstallProgress(serverId, `Error: ${err.message}`, 0, true, err.message);
            }
        })();
    } catch (err) {
        console.error('Reinstall server error:', err);
        res.status(500).json({ error: 'Failed to reinstall server: ' + err.message });
    }
});
// ================================================
// ADMIN SETTINGS ROUTES
// ================================================
app.get('/admin/settings', requireAdmin, async (req, res) => {
    res.render('admin/settings', await getTemplateVars(req, null, {
        settings: globalSettings,
        title: 'Panel Settings',
        DB_PATH,
        SERVERS_DIR
    }));
});
app.post('/admin/settings/general', requireAdmin, async (req, res) => {
    try {
        const { panelName, panelDescription, footerText, registrationEnabled, maxServersPerUser, defaultRam, defaultPort, defaultCurrency, billingEnabled } = req.body;
     
        globalSettings.panelName = panelName || globalSettings.panelName;
        globalSettings.panelDescription = panelDescription || globalSettings.panelDescription;
        globalSettings.footerText = footerText || globalSettings.footerText;
        globalSettings.registrationEnabled = registrationEnabled === 'true';
        globalSettings.maxServersPerUser = parseInt(maxServersPerUser) || 5;
        globalSettings.defaultRam = parseInt(defaultRam) || 1024;
        globalSettings.defaultPort = parseInt(defaultPort) || 25565;
        if (defaultCurrency) globalSettings.defaultCurrency = defaultCurrency;
        globalSettings.billingEnabled = billingEnabled !== 'false';
     
        saveGlobalSettings();
     
        res.json({ success: true, message: 'General settings updated' });
    } catch (err) {
        console.error('Update general settings error:', err);
        res.status(500).json({ error: 'Failed to update settings' });
    }
});
app.post('/admin/settings/icons', requireAdmin, upload.fields([
    { name: 'siteIcon', maxCount: 1 },
    { name: 'headerIcon', maxCount: 1 }
]), async (req, res) => {
    try {
        const publicDir = path.join(__panelRoot, 'public');
     
        if (req.files.siteIcon) {
            const file = req.files.siteIcon[0];
            const ext = path.extname(file.originalname);
            const destPath = path.join(publicDir, 'site-icon' + ext);
         
            fs.renameSync(file.path, destPath);
            globalSettings.siteIcon = '/site-icon' + ext;
        }
     
        if (req.files.headerIcon) {
            const file = req.files.headerIcon[0];
            const ext = path.extname(file.originalname);
            const destPath = path.join(publicDir, 'header-icon' + ext);
         
            fs.renameSync(file.path, destPath);
            globalSettings.headerIcon = '/header-icon' + ext;
        }
     
        saveGlobalSettings();
     
        res.json({ success: true, message: 'Icons updated successfully' });
    } catch (err) {
        console.error('Update icons error:', err);
        res.status(500).json({ error: 'Failed to update icons' });
    }
});
app.post('/admin/settings/theme', requireAdmin, async (req, res) => {
    try {
        const { theme, customCss } = req.body;
     
        globalSettings.theme = theme || 'default';
     
        if (customCss) {
            const cssPath = path.join(__panelRoot, 'public', 'custom-theme.css');
            fs.writeFileSync(cssPath, customCss, 'utf8');
        }
     
        saveGlobalSettings();
     
        res.json({ success: true, message: 'Theme updated successfully' });
    } catch (err) {
        console.error('Update theme error:', err);
        res.status(500).json({ error: 'Failed to update theme' });
    }
});

// Video Background Settings
app.post('/admin/settings/video-background', requireAdmin, async (req, res) => {
    try {
        const { videoBackgroundUrl } = req.body;
        
        // Validate URL format if provided
        if (videoBackgroundUrl && videoBackgroundUrl.trim() !== '') {
            const urlPattern = /^https?:\/\/.+\.(mp4|webm|ogg)$/i;
            if (!urlPattern.test(videoBackgroundUrl)) {
                return res.status(400).json({ 
                    error: 'Invalid video URL. Must be a direct link to .mp4, .webm, or .ogg file' 
                });
            }
        }
        
        // Update global settings
        globalSettings.videoBackgroundUrl = videoBackgroundUrl && videoBackgroundUrl.trim() !== '' 
            ? videoBackgroundUrl.trim() 
            : null;
        
        saveGlobalSettings();
        
        res.json({ 
            success: true, 
            message: videoBackgroundUrl ? 'Video background updated successfully' : 'Video background removed successfully'
        });
    } catch (err) {
        console.error('Update video background error:', err);
        res.status(500).json({ error: 'Failed to update video background' });
    }
});

// API endpoint to validate and fix all server ports (admin only)
app.post('/admin/validate-ports', requireAdmin, async (req, res) => {
    try {
        const result = await validateAndFixAllServerPorts();
        res.json({
            success: true,
            message: 'Port validation completed successfully',
            ...result
        });
    } catch (err) {
        console.error('Error validating ports:', err);
        res.status(500).json({ error: 'Failed to validate ports: ' + err.message });
    }
});

// ================================================
// LOCATIONS MANAGEMENT ROUTES
// ================================================
app.get('/admin/locations', requireAdmin, async (req, res) => {
    try {
        const locations = await dbAll('SELECT * FROM locations ORDER BY name ASC');
        res.render('admin/locations', {
            user: req.session.user,
            settings: globalSettings,
            locations: locations
        });
    } catch (err) {
        console.error('Error fetching locations:', err);
        req.flash('error', 'Failed to load locations');
        res.redirect('/admin');
    }
});

app.get('/admin/locations/create', requireAdmin, async (req, res) => {
    try {
        res.render('admin/locations/create', {
            user: req.session.user,
            settings: globalSettings
        });
    } catch (err) {
        console.error('Error showing create location form:', err);
        req.flash('error', 'Failed to load form');
        res.redirect('/admin/locations');
    }
});

app.post('/admin/locations/create', requireAdmin, async (req, res) => {
    try {
        const { name, description, short } = req.body;
        await dbRun(
            'INSERT INTO locations (name, description, short) VALUES (?, ?, ?)',
            [name, description, short]
        );
        req.flash('success', 'Location created successfully');
        res.redirect('/admin/locations');
    } catch (err) {
        console.error('Error creating location:', err);
        req.flash('error', 'Failed to create location');
        res.redirect('/admin/locations/create');
    }
});

app.get('/admin/locations/:id/edit', requireAdmin, async (req, res) => {
    try {
        const location = await dbGet('SELECT * FROM locations WHERE id = ?', [req.params.id]);
        if (!location) {
            req.flash('error', 'Location not found');
            return res.redirect('/admin/locations');
        }
        res.render('admin/locations/edit', {
            user: req.session.user,
            settings: globalSettings,
            location: location
        });
    } catch (err) {
        console.error('Error fetching location:', err);
        req.flash('error', 'Failed to load location');
        res.redirect('/admin/locations');
    }
});

app.post('/admin/locations/:id/update', requireAdmin, async (req, res) => {
    try {
        const { name, description, short } = req.body;
        await dbRun(
            'UPDATE locations SET name = ?, description = ?, short = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
            [name, description, short, req.params.id]
        );
        req.flash('success', 'Location updated successfully');
        res.redirect('/admin/locations');
    } catch (err) {
        console.error('Error updating location:', err);
        req.flash('error', 'Failed to update location');
        res.redirect(`/admin/locations/${req.params.id}/edit`);
    }
});

app.post('/admin/locations/:id/delete', requireAdmin, async (req, res) => {
    try {
        await dbRun('DELETE FROM locations WHERE id = ?', [req.params.id]);
        req.flash('success', 'Location deleted successfully');
        res.redirect('/admin/locations');
    } catch (err) {
        console.error('Error deleting location:', err);
        req.flash('error', 'Failed to delete location');
        res.redirect('/admin/locations');
    }
});

// ================================================
// NODES MANAGEMENT ROUTES
// ================================================
app.get('/admin/nodes', requireAdmin, async (req, res) => {
    try {
        const nodes = await dbAll(`
            SELECT n.*, l.name as location_name 
            FROM nodes n 
            LEFT JOIN locations l ON n.location_id = l.id 
            ORDER BY n.name ASC
        `);
        
        // All nodes are considered online (heartbeat tracking is a future feature)
        const nodesWithStatus = nodes.map(node => ({
            ...node,
            is_online: true
        }));
        
        res.render('admin/nodes', {
            user: req.session.user,
            settings: globalSettings,
            nodes: nodesWithStatus
        });
    } catch (err) {
        console.error('Error fetching nodes:', err);
        req.flash('error', 'Failed to load nodes');
        res.redirect('/admin');
    }
});

app.get('/admin/nodes/create', requireAdmin, async (req, res) => {
    try {
        const locations = await dbAll('SELECT * FROM locations ORDER BY name ASC');
        res.render('admin/nodes/create', await getTemplateVars(req, null, {
            locations: locations
        }));
    } catch (err) {
        console.error('Error showing create node form:', err);
        req.flash('error', 'Failed to load form');
        res.redirect('/admin/nodes');
    }
});

app.post('/admin/nodes/create', requireAdmin, async (req, res) => {
    try {
        const {
            name,
            description,
            location_id,
            public: isPublic,
            fqdn,
            scheme,
            behind_proxy,
            memory,
            memory_overallocate,
            disk,
            disk_overallocate,
            upload_size,
            daemon_listen,
            daemon_sftp,
            daemon_base,
            mode
        } = req.body;

        const uuid = uuidv4();
        const daemonTokenId = generateRandomToken(16);
        const daemonToken = generateRandomToken(64);
        const now = new Date().toISOString();

        await dbRun(`
            INSERT INTO nodes (
                uuid, name, description, location_id, public, fqdn, scheme,
                behind_proxy, memory, memory_overallocate, disk, disk_overallocate,
                upload_size, daemon_token_id, daemon_token, daemon_listen,
                daemon_sftp, daemon_base, mode, last_heartbeat
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
            uuid, name, description, location_id, isPublic === 'on' ? 1 : 0, fqdn, scheme,
            behind_proxy === 'on' ? 1 : 0, parseInt(memory), parseInt(memory_overallocate),
            parseInt(disk), parseInt(disk_overallocate), parseInt(upload_size),
            daemonTokenId, daemonToken, parseInt(daemon_listen),
            parseInt(daemon_sftp), daemon_base, mode || 'local', now
        ]);

        req.flash('success', 'Node created successfully');
        res.redirect('/admin/nodes');
    } catch (err) {
        console.error('Error creating node:', err);
        req.flash('error', 'Failed to create node: ' + err.message);
        res.redirect('/admin/nodes/create');
    }
});

app.get('/admin/nodes/:id', requireAdmin, async (req, res) => {
    try {
        const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [req.params.id]);
        if (!node) {
            req.flash('error', 'Node not found');
            return res.redirect('/admin/nodes');
        }
        
        // All nodes are considered online (heartbeat tracking is a future feature)
        node.is_online = true;
        
        // Parse stats if available
        try {
            node.parsed_stats = node.stats ? JSON.parse(node.stats) : null;
        } catch (e) {
            node.parsed_stats = null;
        }
        
        const location = await dbGet('SELECT * FROM locations WHERE id = ?', [node.location_id]);
        const allocations = await dbAll('SELECT * FROM allocations WHERE node_id = ?', [node.id]);
        const servers = await dbAll('SELECT * FROM servers WHERE node_id = ?', [node.id]);
        
        // Generate connection string for remote daemon
        const protocol = req.protocol;
        const host = req.get('host');
        const panelUrl = `${protocol}://${host}`;
        const { generateConnectionString } = require('../services/wings/node');
        const connectionString = generateConnectionString(node, panelUrl);
        
        res.render('admin/nodes/view', await getTemplateVars(req, null, {
            node: node,
            location: location,
            allocations: allocations,
            servers: servers,
            connectionString: connectionString
        }));
    } catch (err) {
        console.error('Error fetching node:', err);
        req.flash('error', 'Failed to load node');
        res.redirect('/admin/nodes');
    }
});

app.get('/admin/nodes/:id/edit', requireAdmin, async (req, res) => {
    try {
        const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [req.params.id]);
        if (!node) {
            req.flash('error', 'Node not found');
            return res.redirect('/admin/nodes');
        }
        const locations = await dbAll('SELECT * FROM locations ORDER BY name ASC');
        res.render('admin/nodes/edit', await getTemplateVars(req, null, {
            node: node,
            locations: locations
        }));
    } catch (err) {
        console.error('Error fetching node:', err);
        req.flash('error', 'Failed to load node');
        res.redirect('/admin/nodes');
    }
});

app.post('/admin/nodes/:id/update', requireAdmin, async (req, res) => {
    try {
        const {
            name,
            description,
            location_id,
            public,
            fqdn,
            scheme,
            behind_proxy,
            maintenance_mode,
            memory,
            memory_overallocate,
            disk,
            disk_overallocate,
            upload_size,
            daemon_listen,
            daemon_sftp,
            daemon_base,
            mode
        } = req.body;

        await dbRun(`
            UPDATE nodes SET
                name = ?,
                description = ?,
                location_id = ?,
                public = ?,
                fqdn = ?,
                scheme = ?,
                behind_proxy = ?,
                maintenance_mode = ?,
                memory = ?,
                memory_overallocate = ?,
                disk = ?,
                disk_overallocate = ?,
                upload_size = ?,
                daemon_listen = ?,
                daemon_sftp = ?,
                daemon_base = ?,
                mode = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        `, [
            name, description, location_id, public === 'on' ? 1 : 0, fqdn, scheme,
            behind_proxy === 'on' ? 1 : 0, maintenance_mode === 'on' ? 1 : 0,
            parseInt(memory), parseInt(memory_overallocate), parseInt(disk),
            parseInt(disk_overallocate), parseInt(upload_size), parseInt(daemon_listen),
            parseInt(daemon_sftp), daemon_base, mode || 'local', req.params.id
        ]);

        req.flash('success', 'Node updated successfully');
        res.redirect(`/admin/nodes/${req.params.id}`);
    } catch (err) {
        console.error('Error updating node:', err);
        req.flash('error', 'Failed to update node: ' + err.message);
        res.redirect(`/admin/nodes/${req.params.id}/edit`);
    }
});

app.get('/admin/nodes/:id/configuration', requireAdmin, async (req, res) => {
    try {
        const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [req.params.id]);
        if (!node) {
            req.flash('error', 'Node not found');
            return res.redirect('/admin/nodes');
        }
        
        // Generate wings config
        const config = {
            debug: false,
            uuid: node.uuid,
            token_id: node.daemon_token_id,
            token: node.daemon_token,
            api: {
                host: '0.0.0.0',
                port: node.daemon_listen,
                ssl: {
                    enabled: !node.behind_proxy && node.scheme === 'https',
                    cert: `/etc/letsencrypt/live/${node.fqdn}/fullchain.pem`,
                    key: `/etc/letsencrypt/live/${node.fqdn}/privkey.pem`
                },
                upload_limit: node.upload_size
            },
            system: {
                data: node.daemon_base,
                sftp: {
                    bind_port: node.daemon_sftp
                }
            },
            allowed_mounts: [],
            remote: `${req.protocol}://${req.get('host')}`
        };

        // Set headers to download as config.yml
        res.setHeader('Content-Type', 'application/yaml');
        res.setHeader('Content-Disposition', `attachment; filename="config.yml"`);
        res.send(require('js-yaml').dump(config, { indent: 2 }));
    } catch (err) {
        console.error('Error generating node config:', err);
        req.flash('error', 'Failed to generate configuration');
        res.redirect(`/admin/nodes/${req.params.id}`);
    }
});

app.post('/admin/nodes/:id/delete', requireAdmin, async (req, res) => {
    try {
        await dbRun('DELETE FROM nodes WHERE id = ?', [req.params.id]);
        req.flash('success', 'Node deleted successfully');
        res.redirect('/admin/nodes');
    } catch (err) {
        console.error('Error deleting node:', err);
        req.flash('error', 'Failed to delete node');
        res.redirect('/admin/nodes');
    }
});

app.post('/admin/nodes/:id/restart', requireAdmin, async (req, res) => {
    try {
        const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [req.params.id]);
        if (!node) {
            req.flash('error', 'Node not found');
            return res.redirect('/admin/nodes');
        }
        await dbRun('UPDATE nodes SET pending_command = ? WHERE id = ?', ['restart', req.params.id]);
        req.flash('success', 'Restart command sent to node (will execute on next heartbeat)');
        res.redirect(`/admin/nodes/${req.params.id}`);
    } catch (err) {
        console.error('Error sending restart:', err);
        req.flash('error', 'Failed to send restart command');
        res.redirect(`/admin/nodes/${req.params.id}`);
    }
});

app.post('/admin/nodes/:id/stop', requireAdmin, async (req, res) => {
    try {
        const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [req.params.id]);
        if (!node) {
            req.flash('error', 'Node not found');
            return res.redirect('/admin/nodes');
        }
        await dbRun('UPDATE nodes SET pending_command = ? WHERE id = ?', ['stop', req.params.id]);
        req.flash('success', 'Stop command sent to node (will execute on next heartbeat)');
        res.redirect(`/admin/nodes/${req.params.id}`);
    } catch (err) {
        console.error('Error sending stop:', err);
        req.flash('error', 'Failed to send stop command');
        res.redirect(`/admin/nodes/${req.params.id}`);
    }
});

// Toggle maintenance mode for node
app.post('/admin/nodes/:id/maintenance', requireAdmin, async (req, res) => {
    try {
        const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [req.params.id]);
        if (!node) {
            return res.status(404).json({ error: 'Node not found' });
        }
        
        const newMaintenanceMode = !node.maintenance_mode;
        await dbRun('UPDATE nodes SET maintenance_mode = ? WHERE id = ?', [newMaintenanceMode ? 1 : 0, req.params.id]);
        
        if (newMaintenanceMode) {
            // Stop all servers on this node
            const servers = await dbAll('SELECT * FROM servers WHERE node_id = ?', [req.params.id]);
            for (const server of servers) {
                try {
                    // Stop the server if it's running
                    await stopServer(server.id, false);
                } catch (err) {
                    console.error(`Error stopping server ${server.id} for maintenance:`, err);
                }
            }
        }
        
        res.json({ 
            success: true, 
            maintenance_mode: newMaintenanceMode,
            message: newMaintenanceMode ? 'Maintenance mode enabled' : 'Maintenance mode disabled'
        });
    } catch (err) {
        console.error('Error toggling maintenance mode:', err);
        res.status(500).json({ error: 'Failed to toggle maintenance mode' });
    }
});

// Install Wings on node
app.post('/admin/nodes/:id/install-wings', requireAdmin, async (req, res) => {
    try {
        const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [req.params.id]);
        if (!node) {
            req.flash('error', 'Node not found');
            return res.redirect('/admin/nodes');
        }

        const { sshHost, sshPort, sshUser, sshPassword, sshKey } = req.body;
        
        // Generate the config YAML
        const config = {
            debug: false,
            uuid: node.uuid,
            token_id: node.daemon_token_id,
            token: node.daemon_token,
            api: {
                host: '0.0.0.0',
                port: node.daemon_listen,
                ssl: {
                    enabled: !node.behind_proxy && node.scheme === 'https',
                    cert: `/etc/letsencrypt/live/${node.fqdn}/fullchain.pem`,
                    key: `/etc/letsencrypt/live/${node.fqdn}/privkey.pem`
                },
                upload_limit: node.upload_size
            },
            system: {
                data: node.daemon_base,
                sftp: {
                    bind_port: node.daemon_sftp
                }
            },
            allowed_mounts: [],
            remote: `${req.protocol}://${req.get('host')}`
        };
        const yamlConfig = require('js-yaml').dump(config, { indent: 2 });
        const base64Config = Buffer.from(yamlConfig).toString('base64');

        // The Wings install script (bash)
        const installScript = `#!/bin/bash
set -e

# Variables
WINGS_VERSION="latest"
CONFIG_BASE64="${base64Config}"
DAEMON_BASE="${node.daemon_base}"

# Create directories
mkdir -p /etc/pterodactyl
mkdir -p $DAEMON_BASE

# Download Wings
cd /usr/local/bin
curl -L -o wings https://github.com/pterodactyl/wings/releases/latest/download/wings_linux_amd64
chmod +x wings

# Write config
echo "$CONFIG_BASE64" | base64 -d > /etc/pterodactyl/config.yml

# Create systemd service
cat > /etc/systemd/system/wings.service << 'EOF'
[Unit]
Description=Pterodactyl Wings Daemon
After=docker.service
Requires=docker.service
PartOf=docker.service

[Service]
User=root
WorkingDirectory=/etc/pterodactyl
LimitNOFILE=4096
PIDFile=/var/run/wings/wings.pid
ExecStart=/usr/local/bin/wings
Restart=on-failure
StartLimitInterval=180
StartLimitBurst=30
RestartSec=5s

[Install]
WantedBy=multi-user.target
EOF

# Reload systemd and start Wings
systemctl daemon-reload
systemctl enable wings
systemctl start wings

echo "Wings installation complete!"
`;

        // Now let's execute this script via SSH if we have credentials
        if (sshHost && sshPort && sshUser && (sshPassword || sshKey)) {
            const Client = require('ssh2').Client;
            const conn = new Client();
            
            const connConfig = {
                host: sshHost,
                port: parseInt(sshPort, 10),
                username: sshUser
            };

            if (sshPassword) {
                connConfig.password = sshPassword;
            } else if (sshKey) {
                connConfig.privateKey = Buffer.from(sshKey);
            }

            conn.on('ready', () => {
                console.log('SSH connection established');
                
                // Upload and execute the script
                conn.exec(installScript, (err, stream) => {
                    if (err) {
                        console.error('SSH exec error:', err);
                        req.flash('error', 'Failed to install Wings: ' + err.message);
                        return res.redirect(`/admin/nodes/${req.params.id}`);
                    }
                    
                    stream.on('close', (code, signal) => {
                        console.log('SSH stream closed. Code:', code);
                        conn.end();
                        if (code === 0) {
                            req.flash('success', 'Wings installed successfully!');
                        } else {
                            req.flash('error', 'Wings installation failed with exit code: ' + code);
                        }
                        res.redirect(`/admin/nodes/${req.params.id}`);
                    }).on('data', (data) => {
                        console.log('SSH output:', data.toString());
                    }).stderr.on('data', (data) => {
                        console.error('SSH stderr:', data.toString());
                    });
                });
            }).connect(connConfig);
        } else {
            // If no SSH credentials, just show the script to the user
            res.setHeader('Content-Type', 'text/plain');
            res.setHeader('Content-Disposition', 'attachment; filename="install-wings.sh"');
            res.send(installScript);
        }
    } catch (err) {
        console.error('Error installing Wings:', err);
        req.flash('error', 'Failed to install Wings: ' + err.message);
        res.redirect(`/admin/nodes/${req.params.id}`);
    }
});

// Add allocations to a node
app.post('/admin/nodes/:id/allocations', requireAdmin, async (req, res) => {
    try {
        console.log('Add allocations request body:', req.body); // Debug log
        const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [req.params.id]);
        console.log('Found node:', node); // Debug log
        if (!node) {
            req.flash('error', 'Node not found');
            return res.redirect('/admin/nodes');
        }
        
        const { ip, alias, port_start, port_end } = req.body;
        const startPort = parseInt(port_start);
        const endPort = port_end ? parseInt(port_end) : startPort;
        console.log('Allocations params:', { ip, alias, port_start, port_end, startPort, endPort }); // Debug log
        
        // Add each port in the range
        let addedCount = 0;
        for (let port = startPort; port <= endPort; port++) {
            // Check if allocation already exists for this node, ip, and port
            const existing = await dbGet('SELECT id FROM allocations WHERE node_id = ? AND ip = ? AND port = ?', [node.id, ip, port]);
            console.log('Checking port', port, 'exists:', existing); // Debug log
            if (!existing) {
                await dbRun('INSERT INTO allocations (node_id, ip, alias, port) VALUES (?, ?, ?, ?)', [node.id, ip, alias || null, port]);
                addedCount++;
                console.log('Added allocation added:', { node_id: node.id, ip, alias, port }); // Debug log
            }
        }
        console.log('Total added:', addedCount); // Debug log
        
        req.flash('success', `Successfully added ${addedCount} allocation(s)`);
        res.redirect(`/admin/nodes/${node.id}`);
    } catch (err) {
        console.error('Error adding allocations:', err);
        req.flash('error', 'Failed to add allocations: ' + err.message);
        res.redirect(`/admin/nodes/${req.params.id}`);
    }
});

// Delete an allocation from a node
app.post('/admin/nodes/:nodeId/allocations/:allocationId/delete', requireAdmin, async (req, res) => {
    try {
        const allocation = await dbGet('SELECT * FROM allocations WHERE id = ? AND node_id = ?', [req.params.allocationId, req.params.nodeId]);
        if (!allocation) {
            req.flash('error', 'Allocation not found');
            return res.redirect(`/admin/nodes/${req.params.nodeId}`);
        }
        
        await dbRun('DELETE FROM allocations WHERE id = ?', [req.params.allocationId]);
        
        req.flash('success', 'Allocation deleted successfully');
        res.redirect(`/admin/nodes/${req.params.nodeId}`);
    } catch (err) {
        console.error('Error deleting allocation:', err);
        req.flash('error', 'Failed to delete allocation');
        res.redirect(`/admin/nodes/${req.params.nodeId}`);
    }
});

// Transfer server between nodes
app.post('/admin/servers/:id/transfer', requireAdmin, async (req, res) => {
    try {
        const serverId = req.params.id;
        const { new_node_id } = req.body;
        
        if (!new_node_id) {
            return res.status(400).json({ error: 'New node ID required' });
        }
        
        const result = await transferServer(serverId, new_node_id);
        if (result.success) {
            req.flash('success', result.message);
            res.json({ success: true, message: result.message });
        } else {
            res.status(400).json({ error: result.error });
        }
    } catch (err) {
        console.error('Transfer server route error:', err);
        res.status(500).json({ error: 'Failed to transfer server' });
    }
});
// ================================================
// ADMIN EXTRA ROUTES: SECURITY, ABOUT, ANNOUNCEMENTS, PAYMENT GATEWAYS
// ================================================

// Security
app.get('/admin/security', requireAdmin, async (req, res) => {
    try {
        // Initialize default security settings if not present
        if (!globalSettings.ddosProtection) globalSettings.ddosProtection = false;
        if (!globalSettings.rateLimit) globalSettings.rateLimit = 100;
        if (!globalSettings.connectionLimit) globalSettings.connectionLimit = 10;
        if (!globalSettings.firewallRules) globalSettings.firewallRules = [];
        if (!globalSettings.ipWhitelist) globalSettings.ipWhitelist = [];
        if (!globalSettings.ipBlacklist) globalSettings.ipBlacklist = [];
        if (!globalSettings.requireAdmin2fa) globalSettings.requireAdmin2fa = false;
        if (!globalSettings.requireAll2fa) globalSettings.requireAll2fa = false;
        if (!globalSettings.pluginScanning) globalSettings.pluginScanning = false;
        
        // Get security logs (try to get from db or use empty array)
        let securityLogs = [];
        try {
            securityLogs = await dbAll('SELECT * FROM security_logs ORDER BY created_at DESC').catch(() => []);
        } catch(e) { securityLogs = []; }
        
        res.render('admin/security', await getTemplateVars(req, null, { 
            title: 'Security', 
            activePage: 'security',
            settings: globalSettings,
            securityLogs 
        }));
    } catch(err) { 
        console.error('Security page error:', err);
        res.status(500).render('error', await getTemplateVars(req, null, { message: err.message, status: 500, title: 'Error' })); 
    }
});

// Security POST routes
app.post('/admin/security/ddos', requireAdmin, async (req, res) => {
    try {
        const { ddosProtection, rateLimit, connectionLimit } = req.body;
        globalSettings.ddosProtection = ddosProtection === 'true';
        globalSettings.rateLimit = parseInt(rateLimit) || 100;
        globalSettings.connectionLimit = parseInt(connectionLimit) || 10;
        saveGlobalSettings();
        res.json({ success: true });
    } catch(err) { res.status(500).json({ error: err.message }); }
});

app.post('/admin/security/firewall/add', requireAdmin, async (req, res) => {
    try {
        const { ip, action, description } = req.body;
        if (!globalSettings.firewallRules) globalSettings.firewallRules = [];
        globalSettings.firewallRules.push({
            ip,
            action,
            description: description || '',
            createdAt: new Date().toISOString()
        });
        saveGlobalSettings();
        res.json({ success: true });
    } catch(err) { res.status(500).json({ error: err.message }); }
});

app.post('/admin/security/firewall/remove', requireAdmin, async (req, res) => {
    try {
        const { index } = req.body;
        if (!globalSettings.firewallRules) globalSettings.firewallRules = [];
        globalSettings.firewallRules.splice(index, 1);
        saveGlobalSettings();
        res.json({ success: true });
    } catch(err) { res.status(500).json({ error: err.message }); }
});

app.post('/admin/security/whitelist', requireAdmin, async (req, res) => {
    try {
        const { ipWhitelist } = req.body;
        globalSettings.ipWhitelist = ipWhitelist || [];
        saveGlobalSettings();
        res.json({ success: true });
    } catch(err) { res.status(500).json({ error: err.message }); }
});

app.post('/admin/security/blacklist', requireAdmin, async (req, res) => {
    try {
        const { ipBlacklist } = req.body;
        globalSettings.ipBlacklist = ipBlacklist || [];
        saveGlobalSettings();
        res.json({ success: true });
    } catch(err) { res.status(500).json({ error: err.message }); }
});

app.post('/admin/security/2fa', requireAdmin, async (req, res) => {
    try {
        const { requireAdmin2fa, requireAll2fa } = req.body;
        globalSettings.requireAdmin2fa = !!requireAdmin2fa;
        globalSettings.requireAll2fa = !!requireAll2fa;
        saveGlobalSettings();
        res.json({ success: true });
    } catch(err) { res.status(500).json({ error: err.message }); }
});

app.post('/admin/security/plugins', requireAdmin, async (req, res) => {
    try {
        const { pluginScanning } = req.body;
        globalSettings.pluginScanning = !!pluginScanning;
        saveGlobalSettings();
        res.json({ success: true });
    } catch(err) { res.status(500).json({ error: err.message }); }
});

// About
app.get('/admin/about', requireAdmin, async (req, res) => {
    const panelInfo = {
        version: 'v1.1.0',
        author: 'ShadowGamerIND',
        updateStatus: 'Coming Soon',
        builtWith: 'Node.js, Express, SQLite, Socket.io, EJS',
        releaseDate: '2026',
        features: ['Multi-server management', 'Real-time console', 'Billing & subscriptions', 'Plugin/Mod marketplace', 'DDoS protection', 'Backup system']
    };
    res.render('admin/about', await getTemplateVars(req, null, { title: 'About Panel', panelInfo, activePage: 'about' }));
});

// Helper to get string from version for DISPLAY (handles objects, keeps original formatting)
function getVersionDisplayString(version) {
    if (typeof version === 'string') return version;
    if (typeof version === 'object' && version !== null) {
        return version.version || version.tag || version.name || version.v || String(version);
    }
    return String(version);
}

// Helper to NORMALIZE version string for comparison (strips leading 'v')
function normalizeVersion(version) {
    return getVersionDisplayString(version).replace(/^v/i, '');
}

// Update Checker API
app.get('/api/admin/check-updates', requireAdmin, async (req, res) => {
    try {
        const { default: axios } = await import('axios');
        const currentVersionDisplay = 'v1.1.0';
        const currentVersionNormalized = normalizeVersion(currentVersionDisplay);
        const filename = 'panel.zip';
        
        // 1. First, get all versions of our file
        const versionsResponse = await axios.get(`https://filesapi.lovable.app/api/public/files/versions/${filename}`, {
            timeout: 10000
        });
        
        const versionsData = versionsResponse.data;
        console.log('API Response:', versionsData); // For debugging
        
        // Extract latest version
        let latestVersionDisplay = currentVersionDisplay;
        let downloadUrl = `https://filesapi.lovable.app/api/public/files/by-name/${filename}`;
        let versions = [];
        
        // Handle different response structures
        if (Array.isArray(versionsData)) {
            versions = versionsData;
        } else if (versionsData.versions && Array.isArray(versionsData.versions)) {
            versions = versionsData.versions;
        } else if (versionsData.data && Array.isArray(versionsData.data)) {
            versions = versionsData.data;
        }
        
        // If we have versions, find the latest
        if (versions.length > 0) {
            // Try to sort them
            latestVersionDisplay = versions[0]; // Default to first one
            try {
                // Simple version compare (handles cases like "v1.0.0" vs "v1.1.0")
                const sorted = [...versions].sort((a, b) => {
                    // Convert to string if not already
                    const aStr = normalizeVersion(a);
                    const bStr = normalizeVersion(b);
                    return bStr.localeCompare(aStr); // Reverse to get latest first
                });
                latestVersionDisplay = sorted[0];
            } catch (e) {
                console.log('Version sort error:', e);
                latestVersionDisplay = versions[0];
            }
        }
        
        // Check if up to date (use normalized versions!)
        const isUpToDate = currentVersionNormalized === normalizeVersion(latestVersionDisplay);
        
        res.json({
            success: true,
            currentVersion: currentVersionDisplay,
            latestVersion: latestVersionDisplay,
            isUpToDate,
            versions,
            downloadUrl,
            filename
        });
    } catch (error) {
        console.error('Update check error:', error.message);
        console.error('Error details:', error.stack);
        res.json({
            success: false,
            error: error.message,
            currentVersion: 'v1.1.0',
            latestVersion: 'v1.1.0',
            isUpToDate: true,
            versions: [],
            downloadUrl: '',
            filename: 'panel.zip'
        });
    }
});

// Perform Update (Backup, Download, Extract)
app.post('/api/admin/update', requireAdmin, async (req, res) => {
    // Send initial response to keep connection alive
    res.json({ success: true, message: 'Update started' });
    
    const fs = require('fs');
    const path = require('path');
    const AdmZip = require('adm-zip');
    const { default: axios } = await import('axios');
    
    const tempDir = path.join(__panelRoot, 'temp_update');
    const backupDir = path.join(__panelRoot, 'backups', `update_backup_${Date.now()}`);
    const zipPath = path.join(tempDir, 'panel.zip');
    
    try {
        // Step 1: Create temp and backup directories
        console.log('[Update] Step 1: Preparing directories');
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
        if (!fs.existsSync(path.join(__panelRoot, 'backups'))) fs.mkdirSync(path.join(__panelRoot, 'backups'), { recursive: true });
        if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
        
        // Step 2: Backup important data (database, config, servers, etc.)
        console.log('[Update] Step 2: Creating backup');
        const importantPaths = [
            path.join(__panelRoot, 'database.sqlite'),
            path.join(__panelRoot, '.env'),
            path.join(__panelRoot, 'servers'),
            path.join(__panelRoot, 'uploads'),
            path.join(__panelRoot, 'logs')
        ];
        
        for (const itemPath of importantPaths) {
            if (fs.existsSync(itemPath)) {
                const destPath = path.join(backupDir, path.basename(itemPath));
                if (fs.statSync(itemPath).isDirectory()) {
                    // Copy directory recursively
                    copyDirectoryRecursive(itemPath, destPath);
                } else {
                    // Copy file
                    fs.copyFileSync(itemPath, destPath);
                }
            }
        }
        console.log('[Update] Backup completed at:', backupDir);
        
        // Step 3: Download update
        console.log('[Update] Step 3: Downloading update');
        const downloadUrl = 'https://filesapi.lovable.app/api/public/files/by-name/panel.zip';
        const response = await axios({
            method: 'GET',
            url: downloadUrl,
            responseType: 'stream',
            timeout: 60000
        });
        
        const writer = fs.createWriteStream(zipPath);
        response.data.pipe(writer);
        
        await new Promise((resolve, reject) => {
            writer.on('finish', resolve);
            writer.on('error', reject);
        });
        
        // Step 4: Extract update
        console.log('[Update] Step 4: Extracting update');
        const zip = new AdmZip(zipPath);
        zip.extractAllTo(__panelRoot, true);
        
        // Step 5: Clean up temp files
        console.log('[Update] Step 5: Cleaning up');
        fs.rmSync(tempDir, { recursive: true, force: true });
        
        // Step 6: Update version in package.json (optional)
        try {
            const pkgPath = path.join(__panelRoot, 'package.json');
            const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
            // You can update version here if you have it from the API
            fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2));
        } catch (e) {
            console.log('[Update] Package.json update skipped');
        }
        
        console.log('[Update] Update completed successfully! Please restart the server.');
        
    } catch (error) {
        console.error('[Update] Error during update:', error);
        // Cleanup temp
        try {
            if (fs.existsSync(tempDir)) fs.rmSync(tempDir, { recursive: true, force: true });
        } catch (e) {}
    }
});

// Helper function to copy directory recursively
function copyDirectoryRecursive(source, destination) {
    const fs = require('fs');
    const path = require('path');
    
    if (!fs.existsSync(destination)) {
        fs.mkdirSync(destination, { recursive: true });
    }
    
    const entries = fs.readdirSync(source, { withFileTypes: true });
    
    for (const entry of entries) {
        const srcPath = path.join(source, entry.name);
        const destPath = path.join(destination, entry.name);
        
        if (entry.isDirectory()) {
            copyDirectoryRecursive(srcPath, destPath);
        } else {
            fs.copyFileSync(srcPath, destPath);
        }
    }
}

// Announcements
app.get('/admin/announcements', requireAdmin, async (req, res) => {
    try {
        const announcements = await dbAll('SELECT * FROM announcements ORDER BY created_at DESC').catch(() => []);
        res.render('admin/announcements', await getTemplateVars(req, null, { title: 'Announcements', announcements, activePage: 'announcements' }));
    } catch(err) { res.status(500).render('error', await getTemplateVars(req, null, { message: err.message, status: 500, title: 'Error' })); }
});

app.post('/api/admin/announcements', requireAdmin, async (req, res) => {
    try {
        const { title, message, type, is_active } = req.body;
        await dbRun('CREATE TABLE IF NOT EXISTS announcements (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, message TEXT, type TEXT DEFAULT "info", is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)');
        await dbRun('INSERT INTO announcements (title, message, type, is_active) VALUES (?, ?, ?, ?)', [title, message, type || 'info', is_active ? 1 : 0]);
        res.json({ success: true });
    } catch(err) { res.status(500).json({ success: false, error: err.message }); }
});

app.delete('/api/admin/announcements/:id', requireAdmin, async (req, res) => {
    try {
        await dbRun('DELETE FROM announcements WHERE id = ?', [req.params.id]);
        res.json({ success: true });
    } catch(err) { res.status(500).json({ success: false, error: err.message }); }
});

// Payment Gateways
app.get('/admin/payment-gateways', requireAdmin, async (req, res) => {
    const gateways = globalSettings.paymentGateways || {
        wallet: { enabled: true },
        qrcode: { enabled: false, qrImage: '' },
        upi: { enabled: false, upiId: '' },
        bank: { enabled: false, bankName: '', accountNo: '', ifsc: '' }
    };
    res.render('admin/payment-gateways', await getTemplateVars(req, null, { title: 'Payment Gateways', gateways, activePage: 'payment-gateways' }));
});

app.post('/api/admin/payment-gateways', requireAdmin, async (req, res) => {
    try {
        const { gateways } = req.body;
        globalSettings.paymentGateways = gateways;
        globalSettings.billingEnabled = Object.values(gateways).some(g => g.enabled);
        saveGlobalSettings();
        res.json({ success: true });
    } catch(err) { res.status(500).json({ success: false, error: err.message }); }
});

app.post('/api/admin/payment-gateways/qr', requireAdmin, pgUpload.single('qr'), async (req, res) => {
    try {
        if (!req.file) return res.status(400).json({ error: 'No file' });
        const dest = path.join('public', 'uploads', 'qr-' + Date.now() + path.extname(req.file.originalname));
        fs.renameSync(req.file.path, dest);
        if (!globalSettings.paymentGateways) globalSettings.paymentGateways = {};
        if (!globalSettings.paymentGateways.qrcode) globalSettings.paymentGateways.qrcode = {};
        // Remove 'public/' from beginning of path since static middleware serves public/ as root
        globalSettings.paymentGateways.qrcode.qrImage = '/' + dest.replace(/^public[\\/]/, '').replace(/\\/g, '/');
        saveGlobalSettings();
        res.json({ success: true, url: globalSettings.paymentGateways.qrcode.qrImage });
    } catch(err) { res.status(500).json({ error: err.message }); }
});

// Payment verification (admin reviews screenshots)
app.get('/admin/payment-verification', requireAdmin, async (req, res) => {
    try {
        const pending = await dbAll(`SELECT invoices.*, users.username, users.email FROM invoices LEFT JOIN users ON invoices.user_id = users.id WHERE invoices.status = 'pending_verification' ORDER BY invoices.created_at DESC`).catch(() => []);
        res.render('admin/payment-verification', await getTemplateVars(req, null, { title: 'Payment Verification', pending, activePage: 'payment-verification' }));
    } catch(err) { res.status(500).render('error', await getTemplateVars(req, null, { message: err.message, status: 500, title: 'Error' })); }
});

app.post('/api/admin/payments/:id/verify', requireAdmin, async (req, res) => {
    try {
        const { action } = req.body; // 'accept' or 'reject'
        const invoice = await dbGet('SELECT * FROM invoices WHERE id = ?', [req.params.id]);
        if (!invoice) return res.status(404).json({ error: 'Invoice not found' });
        if (action === 'accept') {
            await dbRun('UPDATE invoices SET status = ? WHERE id = ?', ['paid', invoice.id]);
            // Trigger server creation if this was a plan purchase
            if (invoice.description && invoice.description.includes('Plan:')) {
                // Find the plan and create server (reuse existing billing flow)
                res.json({ success: true, message: 'Payment accepted. Server creation triggered.' });
            } else {
                // Wallet top-up
                await dbRun('UPDATE wallets SET balance = balance + ? WHERE user_id = ?', [invoice.amount, invoice.user_id]).catch(async () => {
                    await dbRun('INSERT INTO wallets (user_id, balance) VALUES (?, ?)', [invoice.user_id, invoice.amount]);
                });
                res.json({ success: true, message: 'Payment accepted. Wallet credited.' });
            }
        } else {
            await dbRun('UPDATE invoices SET status = ? WHERE id = ?', ['rejected', invoice.id]);
            res.json({ success: true, message: 'Payment rejected.' });
        }
    } catch(err) { res.status(500).json({ success: false, error: err.message }); }
});

// Products
app.get('/admin/products', requireAdmin, async (req, res) => {
    try {
        await dbRun('CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, description TEXT, category TEXT, type TEXT, is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)');
        const products = await dbAll('SELECT * FROM products ORDER BY created_at DESC');
        res.render('admin/products', await getTemplateVars(req, null, { title: 'Products', products, activePage: 'products' }));
    } catch(err) { res.status(500).render('error', await getTemplateVars(req, null, { message: err.message, status: 500, title: 'Error' })); }
});
app.post('/api/admin/products', requireAdmin, async (req, res) => {
    try {
        await dbRun('CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, description TEXT, category TEXT, type TEXT, is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)');
        const { name, description, category, type, is_active } = req.body;
        await dbRun('INSERT INTO products (name, description, category, type, is_active) VALUES (?, ?, ?, ?, ?)', [name, description, category, type, is_active]);
        res.json({ success: true });
    } catch(err) { res.status(500).json({ success: false, error: err.message }); }
});
app.post('/api/admin/products/:id', requireAdmin, async (req, res) => {
    try {
        const { name, description, category, type, is_active } = req.body;
        await dbRun('UPDATE products SET name = ?, description = ?, category = ?, type = ?, is_active = ? WHERE id = ?', [name, description, category, type, is_active, req.params.id]);
        res.json({ success: true });
    } catch(err) { res.status(500).json({ success: false, error: err.message }); }
});
app.delete('/api/admin/products/:id', requireAdmin, async (req, res) => {
    try {
        await dbRun('DELETE FROM products WHERE id = ?', [req.params.id]);
        res.json({ success: true });
    } catch(err) { res.status(500).json({ success: false, error: err.message }); }
});

// Plans
app.get('/admin/plans', requireAdmin, async (req, res) => {
    try {
        await dbRun('CREATE TABLE IF NOT EXISTS plans (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER, name TEXT, price REAL, ram INTEGER, storage INTEGER, cpu_cores INTEGER, slots INTEGER, is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)');
        const plans = await dbAll('SELECT * FROM plans ORDER BY created_at DESC');
        const products = await dbAll('SELECT * FROM products WHERE is_active = 1');
        res.render('admin/plans', await getTemplateVars(req, null, { title: 'Plans', plans, products, activePage: 'plans' }));
    } catch(err) { res.status(500).render('error', await getTemplateVars(req, null, { message: err.message, status: 500, title: 'Error' })); }
});
app.post('/api/admin/plans', requireAdmin, async (req, res) => {
    try {
        await dbRun('CREATE TABLE IF NOT EXISTS plans (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER, name TEXT, price REAL, ram INTEGER, storage INTEGER, cpu_cores INTEGER, slots INTEGER, is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)');
        const { product_id, name, price, ram, storage, cpu_cores, slots, is_active } = req.body;
        await dbRun('INSERT INTO plans (product_id, name, price, ram, storage, cpu_cores, slots, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', [product_id, name, price, ram, storage, cpu_cores, slots, is_active]);
        res.json({ success: true });
    } catch(err) { res.status(500).json({ success: false, error: err.message }); }
});
app.post('/api/admin/plans/:id', requireAdmin, async (req, res) => {
    try {
        const { product_id, name, price, ram, storage, cpu_cores, slots, is_active } = req.body;
        await dbRun('UPDATE plans SET product_id = ?, name = ?, price = ?, ram = ?, storage = ?, cpu_cores = ?, slots = ?, is_active = ? WHERE id = ?', [product_id, name, price, ram, storage, cpu_cores, slots, is_active, req.params.id]);
        res.json({ success: true });
    } catch(err) { res.status(500).json({ success: false, error: err.message }); }
});
app.delete('/api/admin/plans/:id', requireAdmin, async (req, res) => {
    try {
        await dbRun('DELETE FROM plans WHERE id = ?', [req.params.id]);
        res.json({ success: true });
    } catch(err) { res.status(500).json({ success: false, error: err.message }); }
});

// Coupons
app.get('/admin/coupons', requireAdmin, async (req, res) => {
    try {
        await dbRun('CREATE TABLE IF NOT EXISTS coupons (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT, discount_type TEXT, discount_value REAL, max_uses INTEGER DEFAULT 0, used_count INTEGER DEFAULT 0, expires_at DATETIME, is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)');
        const coupons = await dbAll('SELECT * FROM coupons ORDER BY created_at DESC');
        res.render('admin/coupons', await getTemplateVars(req, null, { title: 'Coupons', coupons, activePage: 'coupons' }));
    } catch(err) { res.status(500).render('error', await getTemplateVars(req, null, { message: err.message, status: 500, title: 'Error' })); }
});
app.post('/api/admin/coupons', requireAdmin, async (req, res) => {
    try {
        await dbRun('CREATE TABLE IF NOT EXISTS coupons (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT, discount_type TEXT, discount_value REAL, max_uses INTEGER DEFAULT 0, used_count INTEGER DEFAULT 0, expires_at DATETIME, is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)');
        const { code, discount_type, discount_value, max_uses, expires_at, is_active } = req.body;
        await dbRun('INSERT INTO coupons (code, discount_type, discount_value, max_uses, expires_at, is_active) VALUES (?, ?, ?, ?, ?, ?)', [code, discount_type, discount_value, max_uses, expires_at, is_active]);
        res.json({ success: true });
    } catch(err) { res.status(500).json({ success: false, error: err.message }); }
});
app.post('/api/admin/coupons/:id', requireAdmin, async (req, res) => {
    try {
        const { code, discount_type, discount_value, max_uses, expires_at, is_active } = req.body;
        await dbRun('UPDATE coupons SET code = ?, discount_type = ?, discount_value = ?, max_uses = ?, expires_at = ?, is_active = ? WHERE id = ?', [code, discount_type, discount_value, max_uses, expires_at, is_active, req.params.id]);
        res.json({ success: true });
    } catch(err) { res.status(500).json({ success: false, error: err.message }); }
});
app.delete('/api/admin/coupons/:id', requireAdmin, async (req, res) => {
    try {
        await dbRun('DELETE FROM coupons WHERE id = ?', [req.params.id]);
        res.json({ success: true });
    } catch(err) { res.status(500).json({ success: false, error: err.message }); }
});

// Invoices
app.get('/admin/invoices', requireAdmin, async (req, res) => {
    try {
        const invoices = await dbAll(`SELECT invoices.*, users.username, users.email FROM invoices LEFT JOIN users ON invoices.user_id = users.id ORDER BY invoices.created_at DESC`).catch(() => []);
        res.render('admin/invoices', await getTemplateVars(req, null, { title: 'Invoices', invoices, activePage: 'invoices' }));
    } catch(err) { res.status(500).render('error', await getTemplateVars(req, null, { message: err.message, status: 500, title: 'Error' })); }
});

// Affiliates
app.get('/admin/affiliates', requireAdmin, async (req, res) => {
    try {
        await dbRun('CREATE TABLE IF NOT EXISTS affiliates (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, referral_code TEXT, total_earnings REAL DEFAULT 0, total_referrals INTEGER DEFAULT 0, is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)');
        const affiliates = await dbAll('SELECT affiliates.*, users.username, users.email FROM affiliates LEFT JOIN users ON affiliates.user_id = users.id ORDER BY affiliates.created_at DESC');
        res.render('admin/affiliates', await getTemplateVars(req, null, { title: 'Affiliates', affiliates, activePage: 'affiliates' }));
    } catch(err) { res.status(500).render('error', await getTemplateVars(req, null, { message: err.message, status: 500, title: 'Error' })); }
});
app.post('/api/admin/affiliates/:id/status', requireAdmin, async (req, res) => {
    try {
        await dbRun('UPDATE affiliates SET is_active = ? WHERE id = ?', [req.body.is_active, req.params.id]);
        res.json({ success: true });
    } catch(err) { res.status(500).json({ success: false, error: err.message }); }
});

// User-facing Billing Routes
app.get('/billing', requireAuth, async (req, res) => {
    try {
        await dbRun('CREATE TABLE IF NOT EXISTS wallets (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, balance REAL DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)');
        await dbRun('CREATE TABLE IF NOT EXISTS invoices (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, number TEXT, description TEXT, amount REAL, currency TEXT, status TEXT DEFAULT "pending", payment_method TEXT, screenshot TEXT, server_data TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)');
        
        // Add missing columns if they don't exist (migrations)
        try { await dbRun('ALTER TABLE invoices ADD COLUMN payment_method TEXT'); } catch(e) {}
        try { await dbRun('ALTER TABLE invoices ADD COLUMN screenshot TEXT'); } catch(e) {}
        try { await dbRun('ALTER TABLE invoices ADD COLUMN server_data TEXT'); } catch(e) {}

        const wallet = await dbGet('SELECT * FROM wallets WHERE user_id = ?', [req.session.user.id]);
        const invoices = await dbAll('SELECT * FROM invoices WHERE user_id = ? ORDER BY created_at DESC', [req.session.user.id]);
        const subscription = null; // Placeholder for subscription
        res.render('billing/index', await getTemplateVars(req, null, { title: 'Billing', wallet, invoices, subscription, formatCurrency: res.locals.formatCurrency, currencySymbol: res.locals.currencySymbol, activePage: 'billing' }));
    } catch(err) { res.status(500).render('error', await getTemplateVars(req, null, { message: err.message, status: 500, title: 'Error' })); }
});

app.get('/billing/payment/:id', requireAuth, async (req, res) => {
    try {
        const invoice = await dbGet('SELECT * FROM invoices WHERE id = ? AND user_id = ?', [req.params.id, req.session.user.id]);
        if (!invoice) return res.status(404).render('error', await getTemplateVars(req, null, { message: 'Invoice not found', status: 404, title: 'Not Found' }));
        res.render('billing/payment', await getTemplateVars(req, null, { title: 'Complete Payment', invoice, formatCurrency: res.locals.formatCurrency, currencySymbol: res.locals.currencySymbol, activePage: 'billing' }));
    } catch(err) { res.status(500).render('error', await getTemplateVars(req, null, { message: err.message, status: 500, title: 'Error' })); }
});

app.get('/billing/payment/:id/screenshot', requireAuth, async (req, res) => {
    try {
        const invoice = await dbGet('SELECT * FROM invoices WHERE id = ? AND user_id = ?', [req.params.id, req.session.user.id]);
        if (!invoice) return res.status(404).render('error', await getTemplateVars(req, null, { message: 'Invoice not found', status: 404, title: 'Not Found' }));
        res.render('billing/payment-screenshot', await getTemplateVars(req, null, { title: 'Upload Payment Proof', invoice, formatCurrency: res.locals.formatCurrency, currencySymbol: res.locals.currencySymbol, activePage: 'billing' }));
    } catch(err) { res.status(500).render('error', await getTemplateVars(req, null, { message: err.message, status: 500, title: 'Error' })); }
});

app.post('/api/billing/payment/:id/screenshot', requireAuth, paymentScreenshotUpload.single('screenshot'), async (req, res) => {
    try {
        const invoice = await dbGet('SELECT * FROM invoices WHERE id = ? AND user_id = ?', [req.params.id, req.session.user.id]);
        if (!invoice) return res.status(404).json({ success: false, error: 'Invoice not found' });
        if (!req.file) return res.status(400).json({ success: false, error: 'Please upload a payment proof screenshot' });
        
        const dest = path.join('public', 'uploads', 'payment-' + Date.now() + path.extname(req.file.originalname));
        fs.renameSync(req.file.path, dest);
        // Remove 'public/' from beginning of path since static middleware serves public/ as root
        const screenshotUrl = '/' + dest.replace(/^public[\\/]/, '').replace(/\\/g, '/');
        
        await dbRun('UPDATE invoices SET screenshot = ?, status = ? WHERE id = ?', [screenshotUrl, 'pending_verification', req.params.id]);
        res.json({ success: true });
    } catch(err) { res.status(500).json({ success: false, error: err.message }); }
});

// API: Purchase a plan - update to return invoice and payment method needed
app.post('/api/billing/plans/:id/purchase', requireAuth, async (req, res) => {
    try {
        const plan = await dbGet('SELECT * FROM plans WHERE id = ? AND is_active = 1', [req.params.id]);
        if (!plan) return res.status(404).json({ success: false, error: 'Plan not found' });
        
        await dbRun('CREATE TABLE IF NOT EXISTS invoices (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, number TEXT, description TEXT, amount REAL, currency TEXT, status TEXT DEFAULT "pending", payment_method TEXT, screenshot TEXT, server_data TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)');
        const invoiceNumber = 'INV-' + Date.now() + '-' + Math.floor(Math.random() * 1000);
        const invoiceId = (await dbRun('INSERT INTO invoices (user_id, number, description, amount, currency, status, server_data) VALUES (?, ?, ?, ?, ?, ?, ?)', [
            req.session.user.id, invoiceNumber, 'Plan: ' + plan.name, plan.price, plan.currency || 'USD', 'pending', JSON.stringify(req.body)
        ])).lastID;
        
        res.json({ success: true, invoiceId, requiresWallet: true });
    } catch(err) { res.status(500).json({ success: false, error: err.message }); }
});

app.get('/billing/plans', requireAuth, async (req, res) => {
    try {
        const plans = await dbAll('SELECT * FROM plans WHERE is_active = 1 ORDER BY price ASC');
        const products = await dbAll('SELECT * FROM products WHERE is_active = 1');
        res.render('billing/plans', await getTemplateVars(req, null, { title: 'Plans', plans, products, formatCurrency: res.locals.formatCurrency, currencySymbol: res.locals.currencySymbol, activePage: 'billing' }));
    } catch(err) { res.status(500).render('error', await getTemplateVars(req, null, { message: err.message, status: 500, title: 'Error' })); }
});

app.get('/billing/invoices/:id', requireAuth, async (req, res) => {
    try {
        const invoice = await dbGet('SELECT * FROM invoices WHERE id = ? AND user_id = ?', [req.params.id, req.session.user.id]);
        if (!invoice) return res.status(404).render('error', await getTemplateVars(req, null, { message: 'Invoice not found', status: 404, title: 'Not Found' }));
        res.render('billing/invoice', await getTemplateVars(req, null, { title: 'Invoice #' + invoice.number, invoice, formatCurrency: res.locals.formatCurrency, currencySymbol: res.locals.currencySymbol, activePage: 'billing' }));
    } catch(err) { res.status(500).render('error', await getTemplateVars(req, null, { message: err.message, status: 500, title: 'Error' })); }
});

// API: Add funds to wallet
app.post('/api/billing/wallet/add', requireAuth, async (req, res) => {
    try {
        const { amount, currency, payment_method } = req.body;
        if (!amount || amount < 1) return res.status(400).json({ success: false, error: 'Amount must be at least 1' });
        
        // Create invoice for funds addition
        const invoiceNumber = 'INV-' + Date.now() + '-' + Math.floor(Math.random() * 1000);
        const invoiceId = (await dbRun('INSERT INTO invoices (user_id, number, description, amount, currency, status, payment_method) VALUES (?, ?, ?, ?, ?, ?, ?)', [
            req.session.user.id, invoiceNumber, 'Wallet Top-Up', parseFloat(amount), currency || 'USD', 'pending', payment_method
        ])).lastID;
        
        res.json({ success: true, invoiceId });
    } catch(err) { res.status(500).json({ success: false, error: err.message }); }
});

// API: Pay invoice with wallet
app.post('/api/billing/invoices/:id/pay', requireAuth, async (req, res) => {
    try {
        const invoice = await dbGet('SELECT * FROM invoices WHERE id = ? AND user_id = ?', [req.params.id, req.session.user.id]);
        if (!invoice) return res.status(404).json({ success: false, error: 'Invoice not found' });
        
        // If using wallet payment: check balance
        if (invoice.payment_method === 'wallet') {
            let wallet = await dbGet('SELECT * FROM wallets WHERE user_id = ?', [req.session.user.id]);
            if (!wallet) {
                await dbRun('INSERT INTO wallets (user_id, balance) VALUES (?, 0)', [req.session.user.id]);
                wallet = await dbGet('SELECT * FROM wallets WHERE user_id = ?', [req.session.user.id]);
            }
            
            if (wallet.balance < invoice.amount) return res.status(400).json({ success: false, error: 'Insufficient wallet balance' });
            
            await dbRun('UPDATE wallets SET balance = balance - ? WHERE user_id = ?', [invoice.amount, req.session.user.id]);
        }
        
        // Mark invoice as paid
        await dbRun('UPDATE invoices SET status = ? WHERE id = ?', ['paid', invoice.id]);
        
        // If this was a plan purchase, create a server (placeholder)
        if (invoice.description && invoice.description.includes('Plan:')) {
            // TODO: Create server
        }
        
        res.json({ success: true });
    } catch(err) { res.status(500).json({ success: false, error: err.message }); }
});

// Public announcements API (for dashboard)
app.get('/api/announcements', requireAuth, async (req, res) => {
    try {
        const ann = await dbAll('SELECT * FROM announcements WHERE is_active = 1 ORDER BY created_at DESC LIMIT 5').catch(() => []);
        res.json({ success: true, announcements: ann });
    } catch(err) { res.status(500).json({ success: false, error: err.message }); }
});

app.get('/activate-license', (req, res) => {
    if (globalSettings.licenseActivated) return res.redirect('/');
    res.render('activate-license', { settings: globalSettings, panelName: globalSettings.panelName, user: null, title: 'Activate License' });
});
app.post('/activate-license', async (req, res) => {
    const k = req.body.license_key;
    if (!(k && k.trim())) return res.json({ success: false, error: 'License key required' });

    const result = await deps.validateLicenseKey(k);
    if (!result.valid) {
        return res.json({ success: false, error: result.message });
    }

    globalSettings.licenseKey = k;
    globalSettings.licenseActivated = true;
    saveGlobalSettings();
    res.json({ success: true, message: 'License activated successfully!' });
});
app.get('/api/license/status', (req, res) => res.json({ activated: !!globalSettings.licenseActivated, manager: process.env.LICENSE_MANAGER_URL || 'http://localhost:3001' }));

// Maintenance
app.get('/maintenance', (req, res) => res.render('maintenance', { message: globalSettings.maintenanceMessage || 'Under maintenance.', panelName: globalSettings.panelName, settings: globalSettings, user: req.session.user || null, title: 'Maintenance' }));
app.post('/api/admin/maintenance', requireAdmin, (req, res) => {
    globalSettings.maintenanceMode = !!req.body.enabled;
    if (req.body.message !== undefined) globalSettings.maintenanceMessage = req.body.message;
    saveGlobalSettings();
    res.json({ success: true, maintenanceMode: globalSettings.maintenanceMode });
});

};
