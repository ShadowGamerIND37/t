const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const { v4: uuidv4 } = require('uuid');

const notificationService = require('../services/notification');

module.exports = function(app, deps) {
    const { 
        dbGet, dbAll, dbRun, db,
        globalSettings, requireAuth, getTemplateVars,
        createNotification, logServerActivity
    } = deps;

    const APP_ROOT = deps.APP_DIR || path.resolve(__dirname, '..', '..');

    // Configure multer for profile picture uploads
    const profileStorage = multer.diskStorage({
        destination: function (req, file, cb) {
            const uploadDir = path.join(APP_ROOT, 'public/uploads/profiles');
            if (!fs.existsSync(uploadDir)) {
                fs.mkdirSync(uploadDir, { recursive: true });
            }
            cb(null, uploadDir);
        },
        filename: function (req, file, cb) {
            const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
            cb(null, 'profile-' + req.session.user.id + '-' + uniqueSuffix + path.extname(file.originalname));
        }
    });

    const profileUpload = multer({
        storage: profileStorage,
        limits: {
            fileSize: 10 * 1024 * 1024 // 10MB limit for profile pictures
        },
        fileFilter: function (req, file, cb) {
            const allowedTypes = /jpeg|jpg|png|gif|webp/;
            const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
            const mimetype = allowedTypes.test(file.mimetype);

            if (mimetype && extname) {
                return cb(null, true);
            } else {
                cb(new Error('Only image files are allowed!'));
            }
        }
    });

    // Helper function for user stats
    async function getUserStats(userId) {
        try {
            const serverCount = await dbGet('SELECT COUNT(*) as count FROM servers WHERE owner_id = ?', [userId]);
            const notificationCount = await dbGet('SELECT COUNT(*) as count FROM notifications WHERE user_id = ?', [userId]);
            const unreadNotificationCount = await dbGet('SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0', [userId]);
            const recentActivityCount = await dbGet(`
                SELECT COUNT(*) as count FROM user_activity 
                WHERE user_id = ? AND created_at >= datetime('now', '-30 days')
            `, [userId]);
            const user = await dbGet('SELECT created_at FROM users WHERE id = ?', [userId]);
            const accountAge = user ? Math.floor((Date.now() - new Date(user.created_at).getTime()) / (1000 * 60 * 60 * 24)) : 0;

            return {
                servers: serverCount ? serverCount.count : 0,
                notifications: notificationCount ? notificationCount.count : 0,
                unreadNotifications: unreadNotificationCount ? unreadNotificationCount.count : 0,
                recentActivity: recentActivityCount ? recentActivityCount.count : 0,
                accountAge
            };
        } catch (error) {
            console.error('Error getting user stats:', error);
            return { servers: 0, notifications: 0, unreadNotifications: 0, recentActivity: 0, accountAge: 0 };
        }
    }

    // ================================================
    // PROFILE ROUTES
    // ================================================

    // Profile page
    app.get('/profile', requireAuth, async (req, res) => {
        try {
            const user = await dbGet(`
                SELECT u.*, up.* 
                FROM users u 
                LEFT JOIN user_profiles up ON u.id = up.user_id 
                WHERE u.id = ?
            `, [req.session.user.id]);

            if (!user) {
                return res.redirect('/auth/login');
            }

            const stats = await getUserStats(req.session.user.id);

            res.render('profile/index', await getTemplateVars(req, null, {
                user: {
                    ...user,
                    theme_preference: user.theme_preference || 'dark',
                    theme_primary_color: user.theme_primary_color || '#2d6a4f',
                    theme_accent_color: user.theme_accent_color || '#40916c',
                    language: user.language || 'en',
                    timezone: user.timezone || 'UTC',
                    email_notifications: user.email_notifications !== 0,
                    push_notifications: user.push_notifications !== 0,
                    security_notifications: user.security_notifications !== 0
                },
                stats,
                currentPage: 'profile',
                title: 'Profile Settings'
            }));
        } catch (error) {
            console.error('Profile page error:', error);
            res.status(500).render('error', await getTemplateVars(req, null, { 
                error: 'Failed to load profile',
                message: 'Failed to load profile',
                status: 500,
                title: 'Error'
            }));
        }
    });

    // Update profile
    app.post('/profile/update', requireAuth, async (req, res) => {
        try {
            const userId = req.session.user.id;

            const currentUser = await dbGet('SELECT * FROM users WHERE id = ?', [userId]);
            if (!currentUser) {
                return res.json({ success: false, error: 'User not found' });
            }

            const {
                display_name,
                email,
                bio,
                location,
                website,
                current_password,
                new_password,
                theme_preference,
                theme_primary_color,
                theme_accent_color,
                language,
                timezone,
                email_notifications,
                push_notifications,
                security_notifications,
                two_factor_enabled
            } = req.body;

            const newEmail = email || currentUser.email;

            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(newEmail)) {
                return res.json({ success: false, error: 'Invalid email format' });
            }

            if (newEmail !== currentUser.email) {
                const existingUser = await dbGet('SELECT id FROM users WHERE email = ? AND id != ?', [newEmail, userId]);
                if (existingUser) {
                    return res.json({ success: false, error: 'Email is already taken' });
                }
            }

            let passwordUpdate = '';
            let updateParams = [];

            if (new_password && current_password) {
                if (!bcrypt.compareSync(current_password, currentUser.password)) {
                    return res.json({ success: false, error: 'Current password is incorrect' });
                }

                if (new_password.length < 6) {
                    return res.json({ success: false, error: 'New password must be at least 6 characters long' });
                }

                const hashedPassword = bcrypt.hashSync(new_password, 12);
                passwordUpdate = ', password = ?';
                updateParams.push(hashedPassword);
            }

            if (newEmail !== currentUser.email || passwordUpdate) {
                const userUpdateQuery = `
                    UPDATE users 
                    SET email = ?${passwordUpdate}
                    WHERE id = ?
                `;
                updateParams.unshift(newEmail);
                updateParams.push(userId);

                await dbRun(userUpdateQuery, updateParams);
            }

            const profileData = {
                display_name: display_name || null,
                bio: bio || null,
                location: location || null,
                website: website || null,
                theme_preference: theme_preference || 'dark',
                theme_primary_color: theme_primary_color || '#2d6a4f',
                theme_accent_color: theme_accent_color || '#40916c',
                language: language || 'en',
                timezone: timezone || 'UTC',
                email_notifications: email_notifications ? 1 : 0,
                push_notifications: push_notifications ? 1 : 0,
                security_notifications: security_notifications ? 1 : 0,
                two_factor_enabled: two_factor_enabled ? 1 : 0
            };

            const existingProfile = await dbGet('SELECT user_id FROM user_profiles WHERE user_id = ?', [userId]);

            if (existingProfile) {
                await dbRun(`
                    UPDATE user_profiles 
                    SET display_name = ?, bio = ?, location = ?, website = ?,
                        theme_preference = ?, theme_primary_color = ?, theme_accent_color = ?,
                        language = ?, timezone = ?, email_notifications = ?, 
                        push_notifications = ?, security_notifications = ?, two_factor_enabled = ?,
                        updated_at = datetime('now')
                    WHERE user_id = ?
                `, [
                    profileData.display_name, profileData.bio, profileData.location, profileData.website,
                    profileData.theme_preference, profileData.theme_primary_color, profileData.theme_accent_color,
                    profileData.language, profileData.timezone, profileData.email_notifications,
                    profileData.push_notifications, profileData.security_notifications, profileData.two_factor_enabled,
                    userId
                ]);
            } else {
                await dbRun(`
                    INSERT INTO user_profiles (
                        user_id, display_name, bio, location, website,
                        theme_preference, theme_primary_color, theme_accent_color,
                        language, timezone, email_notifications, push_notifications, 
                        security_notifications, two_factor_enabled, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
                `, [
                    userId, profileData.display_name, profileData.bio, profileData.location, profileData.website,
                    profileData.theme_preference, profileData.theme_primary_color, profileData.theme_accent_color,
                    profileData.language, profileData.timezone, profileData.email_notifications,
                    profileData.push_notifications, profileData.security_notifications, profileData.two_factor_enabled
                ]);
            }

            req.session.user.email = email;
            req.session.user.display_name = display_name;

            await createNotification(
                userId,
                'Profile Updated',
                'Your profile settings have been successfully updated.',
                'success',
                { category: 'account' }
            );

            res.json({ success: true, message: 'Profile updated successfully' });

        } catch (error) {
            console.error('Profile update error:', error);
            res.json({ success: false, error: 'Failed to update profile' });
        }
    });

    // Upload profile picture
    app.post('/profile/upload-picture', requireAuth, profileUpload.single('profile_picture'), async (req, res) => {
        try {
            if (!req.file) {
                return res.json({ success: false, error: 'No file uploaded' });
            }

            const userId = req.session.user.id;
            const profilePicturePath = `/uploads/profiles/${req.file.filename}`;

            const oldProfile = await dbGet('SELECT profile_picture FROM user_profiles WHERE user_id = ?', [userId]);

            const existingProfile = await dbGet('SELECT user_id FROM user_profiles WHERE user_id = ?', [userId]);

            if (existingProfile) {
                await dbRun('UPDATE user_profiles SET profile_picture = ?, updated_at = datetime(\'now\') WHERE user_id = ?', 
                    [profilePicturePath, userId]);
            } else {
                await dbRun(`
                    INSERT INTO user_profiles (user_id, profile_picture, created_at, updated_at) 
                    VALUES (?, ?, datetime('now'), datetime('now'))
                `, [userId, profilePicturePath]);
            }

            if (oldProfile && oldProfile.profile_picture && oldProfile.profile_picture !== profilePicturePath) {
                const oldFilePath = path.join(APP_ROOT, 'public', oldProfile.profile_picture);
                if (fs.existsSync(oldFilePath)) {
                    fs.unlinkSync(oldFilePath);
                }
            }

            await createNotification(
                userId,
                'Profile Picture Updated',
                'Your profile picture has been successfully updated.',
                'success',
                { category: 'account' }
            );

            res.json({ 
                success: true, 
                message: 'Profile picture updated successfully',
                profile_picture: profilePicturePath
            });

        } catch (error) {
            console.error('Profile picture upload error:', error);
            res.json({ success: false, error: 'Failed to upload profile picture' });
        }
    });

    // Delete profile picture
    app.delete('/profile/delete-picture', requireAuth, async (req, res) => {
        try {
            const userId = req.session.user.id;

            const profile = await dbGet('SELECT profile_picture FROM user_profiles WHERE user_id = ?', [userId]);

            if (profile && profile.profile_picture) {
                const filePath = path.join(APP_ROOT, 'public', profile.profile_picture);
                if (fs.existsSync(filePath)) {
                    fs.unlinkSync(filePath);
                }

                await dbRun('UPDATE user_profiles SET profile_picture = NULL, updated_at = datetime(\'now\') WHERE user_id = ?', [userId]);

                await createNotification(
                    userId,
                    'Profile Picture Removed',
                    'Your profile picture has been removed.',
                    'info',
                    { category: 'account' }
                );
            }

            res.json({ success: true, message: 'Profile picture deleted successfully' });

        } catch (error) {
            console.error('Profile picture delete error:', error);
            res.json({ success: false, error: 'Failed to delete profile picture' });
        }
    });

    // Get user activity log
    app.get('/profile/activity', requireAuth, async (req, res) => {
        try {
            const userId = req.session.user.id;
            const page = parseInt(req.query.page) || 1;
            const limit = 20;
            const offset = (page - 1) * limit;

            const activities = await dbAll(`
                SELECT * FROM user_activity 
                WHERE user_id = ? 
                ORDER BY created_at DESC 
                LIMIT ? OFFSET ?
            `, [userId, limit, offset]);

            const totalCount = await dbGet('SELECT COUNT(*) as count FROM user_activity WHERE user_id = ?', [userId]);

            res.json({
                success: true,
                activities,
                pagination: {
                    page,
                    limit,
                    total: totalCount.count,
                    pages: Math.ceil(totalCount.count / limit)
                }
            });

        } catch (error) {
            console.error('Activity log error:', error);
            res.json({ success: false, error: 'Failed to load activity log' });
        }
    });

    // ================================================
    // NOTIFICATION ROUTES
    // ================================================

    // Notifications page
    app.get('/notifications', requireAuth, async (req, res) => {
        try {
            const userId = req.session.user.id;
            const page = parseInt(req.query.page) || 1;
            const limit = 20;
            const filter = req.query.filter || 'all';
            const category = req.query.category || 'all';

            const notifications = await notificationService.getNotificationsPaginated(userId, page, limit, filter, category);
            const unreadCount = await notificationService.getUnreadNotificationCount(userId);
            const stats = await notificationService.getNotificationStats(userId);

            res.render('notifications/index', await getTemplateVars(req, null, {
                notifications: notifications.data,
                pagination: notifications.pagination,
                unreadCount,
                stats,
                currentFilter: filter,
                currentCategory: category,
                currentPage: 'notifications',
                title: 'Notifications'
            }));

        } catch (error) {
            console.error('Notifications page error:', error);
            res.status(500).render('error', await getTemplateVars(req, null, { 
                error: 'Failed to load notifications',
                message: 'Failed to load notifications',
                status: 500,
                title: 'Error'
            }));
        }
    });

    // Get notifications API (for AJAX)
    app.get('/notifications/api', requireAuth, async (req, res) => {
        try {
            const userId = req.session.user.id;
            const page = parseInt(req.query.page) || 1;
            const limit = parseInt(req.query.limit) || 20;
            const filter = req.query.filter || 'all';
            const category = req.query.category || 'all';

            const notifications = await notificationService.getNotificationsPaginated(userId, page, limit, filter, category);
            const unreadCount = await notificationService.getUnreadNotificationCount(userId);

            res.json({
                success: true,
                notifications: notifications.data,
                pagination: notifications.pagination,
                unreadCount
            });

        } catch (error) {
            console.error('Notifications API error:', error);
            res.json({ success: false, error: 'Failed to load notifications' });
        }
    });

    // Mark notification as read
    app.post('/notifications/:id/read', requireAuth, async (req, res) => {
        try {
            const notificationId = req.params.id;
            const userId = req.session.user.id;

            const result = await notificationService.markNotificationAsRead(notificationId, userId);

            if (result) {
                res.json({ success: true, message: 'Notification marked as read' });
            } else {
                res.json({ success: false, error: 'Notification not found or access denied' });
            }

        } catch (error) {
            console.error('Mark notification read error:', error);
            res.json({ success: false, error: 'Failed to mark notification as read' });
        }
    });

    // Mark all notifications as read
    app.post('/notifications/mark-all-read', requireAuth, async (req, res) => {
        try {
            const userId = req.session.user.id;
            const category = req.body.category || null;

            await notificationService.markAllNotificationsAsRead(userId, category);

            res.json({ success: true, message: 'All notifications marked as read' });

        } catch (error) {
            console.error('Mark all notifications read error:', error);
            res.json({ success: false, error: 'Failed to mark all notifications as read' });
        }
    });

    // Clear all notifications
    app.delete('/notifications/clear-all', requireAuth, async (req, res) => {
        try {
            const userId = req.session.user.id;
            const category = req.body.category || null;

            await notificationService.clearAllNotifications(userId, category);

            res.json({ success: true, message: 'All notifications cleared' });

        } catch (error) {
            console.error('Clear all notifications error:', error);
            res.json({ success: false, error: 'Failed to clear all notifications' });
        }
    });

    // Delete specific notification
    app.delete('/notifications/:id', requireAuth, async (req, res) => {
        try {
            const notificationId = req.params.id;
            const userId = req.session.user.id;

            const notification = await dbGet('SELECT id FROM notifications WHERE id = ? AND user_id = ?', [notificationId, userId]);

            if (!notification) {
                return res.json({ success: false, error: 'Notification not found or access denied' });
            }

            await dbRun('DELETE FROM notifications WHERE id = ? AND user_id = ?', [notificationId, userId]);

            res.json({ success: true, message: 'Notification deleted' });

        } catch (error) {
            console.error('Delete notification error:', error);
            res.json({ success: false, error: 'Failed to delete notification' });
        }
    });

    // Get notification settings
    app.get('/notifications/settings', requireAuth, async (req, res) => {
        try {
            const userId = req.session.user.id;

            const settings = await dbGet(`
                SELECT email_notifications, push_notifications, security_notifications,
                       notification_frequency, quiet_hours_start, quiet_hours_end
                FROM user_profiles 
                WHERE user_id = ?
            `, [userId]);

            res.render('notifications/settings', await getTemplateVars(req, null, {
                settings: settings || {
                    email_notifications: 1,
                    push_notifications: 1,
                    security_notifications: 1,
                    notification_frequency: 'immediate',
                    quiet_hours_start: null,
                    quiet_hours_end: null
                },
                currentPage: 'notification-settings',
                title: 'Notification Settings'
            }));

        } catch (error) {
            console.error('Notification settings error:', error);
            res.status(500).render('error', await getTemplateVars(req, null, { 
                error: 'Failed to load notification settings',
                message: 'Failed to load notification settings',
                status: 500,
                title: 'Error'
            }));
        }
    });

    // Update notification settings
    app.post('/notifications/settings', requireAuth, async (req, res) => {
        try {
            const userId = req.session.user.id;
            const {
                email_notifications,
                push_notifications,
                security_notifications,
                notification_frequency,
                quiet_hours_start,
                quiet_hours_end,
                categories
            } = req.body;

            const existingProfile = await dbGet('SELECT user_id FROM user_profiles WHERE user_id = ?', [userId]);

            const settingsData = {
                email_notifications: email_notifications ? 1 : 0,
                push_notifications: push_notifications ? 1 : 0,
                security_notifications: security_notifications ? 1 : 0,
                notification_frequency: notification_frequency || 'immediate',
                quiet_hours_start: quiet_hours_start || null,
                quiet_hours_end: quiet_hours_end || null
            };

            if (existingProfile) {
                await dbRun(`
                    UPDATE user_profiles 
                    SET email_notifications = ?, push_notifications = ?, security_notifications = ?,
                        notification_frequency = ?, quiet_hours_start = ?, quiet_hours_end = ?,
                        updated_at = datetime('now')
                    WHERE user_id = ?
                `, [
                    settingsData.email_notifications, settingsData.push_notifications, settingsData.security_notifications,
                    settingsData.notification_frequency, settingsData.quiet_hours_start, settingsData.quiet_hours_end,
                    userId
                ]);
            } else {
                await dbRun(`
                    INSERT INTO user_profiles (
                        user_id, email_notifications, push_notifications, security_notifications,
                        notification_frequency, quiet_hours_start, quiet_hours_end, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
                `, [
                    userId, settingsData.email_notifications, settingsData.push_notifications, settingsData.security_notifications,
                    settingsData.notification_frequency, settingsData.quiet_hours_start, settingsData.quiet_hours_end
                ]);
            }

            if (categories && typeof categories === 'object') {
                for (const [category, enabled] of Object.entries(categories)) {
                    await dbRun(`
                        INSERT OR REPLACE INTO notification_preferences (user_id, category, enabled, updated_at)
                        VALUES (?, ?, ?, datetime('now'))
                    `, [userId, category, enabled ? 1 : 0]);
                }
            }

            await createNotification(
                userId,
                'Notification Settings Updated',
                'Your notification preferences have been successfully updated.',
                'success',
                { category: 'account' }
            );

            res.json({ success: true, message: 'Notification settings updated successfully' });

        } catch (error) {
            console.error('Update notification settings error:', error);
            res.json({ success: false, error: 'Failed to update notification settings' });
        }
    });

    // Test notification (for testing purposes)
    app.post('/notifications/test', requireAuth, async (req, res) => {
        try {
            const userId = req.session.user.id;
            const { type, title, message } = req.body;

            await createNotification(
                userId,
                title || 'Test Notification',
                message || 'This is a test notification to verify your notification system is working correctly.',
                type || 'info',
                { category: 'system', test: true }
            );

            res.json({ success: true, message: 'Test notification sent' });

        } catch (error) {
            console.error('Test notification error:', error);
            res.json({ success: false, error: 'Failed to send test notification' });
        }
    });
};
