const path = require('path');
const fs = require('fs');
const { spawn, exec } = require('child_process');
const util = require('util');
const execAsync = util.promisify(exec);
const multer = require('multer');
const archiver = require('archiver');
const unzipper = require('unzipper');
const axios = require('axios');
const pidusage = require('pidusage');
const sanitize = require('sanitize-filename');
const zlib = require('zlib');
const prismarineNbt = require('prismarine-nbt');
const { promisify } = require('util');
const os = require('os');
const net = require('net');
const { Rcon } = require('rcon-client');
const { v4: uuidv4 } = require('uuid');
const yaml = require('js-yaml');
const crypto = require('crypto');
const { promisify: pPromisify } = require('util');
const nbtParse = promisify(prismarineNbt.parse);

module.exports = function(app, deps) {
    const { 
        dbGet, dbAll, dbRun, db,
        globalSettings, liveStats, serverProcesses, onlinePlayers,
        serverStartTimes, serverLogWatchers, networkStats, totalBandwidthUsed,
        requireAuth, requireAdmin, isAuthorized,
        getTemplateVars,
        isServerRunning, startServer, stopServer, restartServer, sendCommand, isProcessRunning, isJavaProcess,
        fetchMinecraftVersions, getAvailableServerSoftware, isValidMinecraftVersion,
        resolveServerPath, formatFileSize, parseProperties, writeProperties, getDirSize,
        loadServerStartTime, saveServerStartTime, deleteServerStartTime,
        logServerActivity, createNotification,
        downloadServerJar, downloadPluginJar, getInstalledPlugins,
        findAvailablePortForServerType, ensureServerPortForType, updateServerConfigurationPort, updateServerPropertiesPort,
        startLogTail, processLogLine,
        updateLiveStats, startMonitoring,
        searchPlugins, getModrinthVersions, getSpigetVersions, getHangarVersions, getBukkitVersions,
        getModrinthDownloadUrl, getSpigetDownloadUrl, getHangarDownloadUrl, getBukkitDownloadUrl,
        getCompleteMinecraftVersions,
        DATA_DIR, SERVERS_DIR, APP_DIR
    } = deps;

    const __panelRoot = APP_DIR || path.resolve(__dirname, '..', '..');

    // ================================================
    // PROGRESS TRACKING (shared via deps)
    // ================================================
    const { installProgress, deleteProgress, reinstallProgress,
            setInstallProgress, setDeleteProgress, setReinstallProgress } = deps;
    function delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // ================================================
    // HELPER FUNCTIONS
    // ================================================

async function isNodeInMaintenance(nodeId) {
    if (!nodeId) return false;
    const node = await dbGet('SELECT maintenance_mode FROM nodes WHERE id = ?', [nodeId]);
    return node && node.maintenance_mode === 1;
}

function sanitizeServerProperties(content, serverPort) {
    try {
        const properties = parseProperties(content);
        
        // ONLY force the correct port (users CAN change everything else)
        properties['server-port'] = serverPort;
        
        // Allow all other properties to be edited freely
        // No validation or restrictions on other settings
        
        return writePropertiesString(properties);
    } catch (err) {
        console.error('Error sanitizing server.properties:', err);
        throw err;
    }
}

function writePropertiesString(properties) {
    return Object.entries(properties)
        .map(([key, value]) => `${key}=${value}`)
        .join('\n') + '\n';
}

function sanitizeVelocityToml(content, serverPort) {
    try {
        // Replace any bind port with the correct one
        const bindRegex = /bind\s*=\s*"[^"]*"/g;
        const correctBind = `bind = "0.0.0.0:${serverPort}"`;
        
        // If there's already a bind setting, replace it
        if (bindRegex.test(content)) {
            content = content.replace(bindRegex, correctBind);
        } else {
            // If no bind setting exists, add it at the beginning
            const lines = content.split('\n');
            const insertIndex = lines.findIndex(line => 
                line.trim() && !line.trim().startsWith('#')
            );
            
            if (insertIndex >= 0) {
                lines.splice(insertIndex, 0, correctBind);
            } else {
                lines.unshift(correctBind);
            }
            
            content = lines.join('\n');
        }
        
        return content;
    } catch (err) {
        console.error('Error sanitizing velocity.toml:', err);
        throw err;
    }
}

function sanitizeBungeeCordConfig(content, serverPort) {
    try {
        // Replace any host port with the correct one
        const hostRegex = /host:\s*([^:]+):(\d+)/g;
        const correctHost = `host: 0.0.0.0:${serverPort}`;
        
        // Replace all host entries with the correct port
        content = content.replace(hostRegex, (match, ip, port) => {
            return `host: 0.0.0.0:${serverPort}`;
        });
        
        // Also handle listen entries if they exist
        const listenRegex = /listen:\s*([^:]+):(\d+)/g;
        content = content.replace(listenRegex, (match, ip, port) => {
            return `listen: 0.0.0.0:${serverPort}`;
        });
        
        // Handle bind_local_address entries
        const bindLocalRegex = /bind_local_address:\s*([^:]+):(\d+)/g;
        content = content.replace(bindLocalRegex, (match, ip, port) => {
            return `bind_local_address: 0.0.0.0:${serverPort}`;
        });
        
        return content;
    } catch (err) {
        console.error('Error sanitizing BungeeCord config.yml:', err);
        throw err;
    }
}

function checkAndAcceptEula(serverId, accept = false) {
  try {
    const serverDir = resolveServerPath(serverId);
    const eulaPath = path.join(serverDir, 'eula.txt');
    
    if (!fs.existsSync(eulaPath)) {
      // Create default eula.txt if it doesn't exist
      fs.writeFileSync(eulaPath, '#By changing the setting below to TRUE you are indicating your agreement to our EULA (https://aka.ms/MinecraftEULA)\n#Fri Jun 13 2025 00:00:00 GMT\n#Server Properties (default)\n#Fri Jun 13 2025 00:00:00 GMT\neula=false\n', 'utf8');
      return { accepted: false, exists: true };
    }

    const content = fs.readFileSync(eulaPath, 'utf8');
    const isAccepted = /eula\s*=\s*true/i.test(content);

    if (accept && !isAccepted) {
      const newContent = content.replace(/eula\s*=\s*false/i, 'eula=true');
      fs.writeFileSync(eulaPath, newContent, 'utf8');
      return { accepted: true, exists: true };
    }

    return { accepted: isAccepted, exists: true };
  } catch (err) {
    console.error('Error checking EULA:', err);
    return { accepted: false, exists: false, error: err.message };
  }
}

async function autoEnableRcon(serverId) {
  try {
    const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
    if (!server) return false;
    
    const propertiesPath = resolveServerPath(serverId, 'server.properties');
    
    // Check if server.properties exists
    if (!fs.existsSync(propertiesPath)) {
      console.log(`server.properties not found for server ${serverId}`);
      return false;
    }
    
    // Read current properties
    let content = fs.readFileSync(propertiesPath, 'utf8');
    
    // Check if RCON is already enabled
    if (content.includes('enable-rcon=true')) {
      console.log(`RCON already enabled for server ${serverId}`);
      return true;
    }
    
    // Generate RCON port (server port + 1000)
    const rconPort = server.port + 1000;
    const rconPassword = 'admin123';
    
    // Add or update RCON settings
    const rconSettings = `
# RCON Settings (Auto-enabled by panel)
enable-rcon=true
rcon.port=${rconPort}
rcon.password=${rconPassword}
`;
    
    // Remove existing RCON lines if any
    content = content.replace(/enable-rcon=.*/g, '');
    content = content.replace(/rcon\.port=.*/g, '');
    content = content.replace(/rcon\.password=.*/g, '');
    
    // Add RCON settings at the end
    content = content.trim() + '\n' + rconSettings;
    
    // Write back to file
    fs.writeFileSync(propertiesPath, content, 'utf8');
    
    // Update server settings in database
    const settings = JSON.parse(server.settings || '{}');
    settings.rcon = true;
    settings['rcon.port'] = rconPort;
    settings['rcon.password'] = rconPassword;
    
    await dbRun('UPDATE servers SET settings = ? WHERE id = ?', [
      JSON.stringify(settings),
      serverId
    ]);
    
    console.log(`RCON auto-enabled for server ${serverId} on port ${rconPort}`);
    return true;
  } catch (err) {
    console.error(`Failed to auto-enable RCON for server ${serverId}:`, err);
    return false;
  }
}

async function queryOnlinePlayersRcon(serverId) {
  try {
    const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
    if (!server) return false;

    const rcon = new Rcon({
      host: 'localhost',
      port: 25575, // Default RCON port
      password: 'admin123'
    });

    await rcon.connect();
    const response = await rcon.send('list');
    await rcon.end();

    console.log(`RCON response for server ${serverId}:`, response);

    // Parse the response: "There are X of a max of Y players online: player1, player2"
    const listMatch = response.match(/There are \d+(?:\/| of a max of )\d+ players online:\s*(.*)/i);
    if (listMatch) {
      const playerList = listMatch[1].trim();
      let players = [];
      
      if (playerList && playerList !== '') {
        players = playerList.split(',').map(p => p.trim()).filter(p => p && p !== '');
      }
      
      // Update the global player list
      onlinePlayers[serverId] = players;
      console.log(`Updated online players for server ${serverId} via RCON:`, players);
      
      // Emit update via Socket.IO
      if (typeof io !== 'undefined') {
        io.to(`server:${serverId}`).emit('playersUpdated', {
          onlinePlayers: players,
          count: players.length
        });
      }
      
      return true;
    }
    
    return false;
  } catch (err) {
    // RCON errors are expected when RCON is not configured or server is stopped
    console.log(`RCON not available for server ${serverId} (this is normal if RCON is not configured)`);
    return false;
  }
}

async function queryOnlinePlayers(serverId) {
  try {
    // First try RCON (more reliable)
    const rconSuccess = await queryOnlinePlayersRcon(serverId);
    if (rconSuccess) return true;

    // Fallback to stdin if we have process reference
    const serverProcess = serverProcesses && serverProcesses[serverId];
    if (serverProcess && !serverProcess.killed && serverProcess.stdin && serverProcess.stdin.writable) {
      // Send /list command to get current players
      serverProcess.stdin.write('list\n');
      console.log(`Queried online players for server ${serverId} via stdin`);
      return true;
    } else {
      // If we don't have process reference, this is expected for stopped servers or servers without RCON
      console.log(`Server ${serverId} player query skipped - server may be stopped or RCON not configured`);
      // Initialize as empty - will be populated as players join/leave
      if (!onlinePlayers[serverId]) {
        onlinePlayers[serverId] = [];
      }
      return false;
    }
  } catch (err) {
    console.error(`Failed to query online players for server ${serverId}:`, err);
    return false;
  }
}

async function getPidByPort(port) {
  try {
    if (os.platform() === 'win32') {
      // Windows: Use netstat to find PID by port
      const { stdout } = await execAsync(`netstat -ano | findstr :${port}`);
      const lines = stdout.trim().split('\n');
      
      for (const line of lines) {
        // Look for LISTENING state
        if (line.includes('LISTENING')) {
          const parts = line.trim().split(/\s+/);
          const pid = parseInt(parts[parts.length - 1]);
          if (!isNaN(pid) && pid > 0) {
            // Verify this is a Java process
            try {
              const { stdout: taskList } = await execAsync(`tasklist /FI "PID eq ${pid}" /FO CSV /NH`);
              if (taskList.toLowerCase().includes('java')) {
                return pid;
              }
            } catch (err) {
              // Continue checking other PIDs
            }
          }
        }
      }
      return null;
    } else {
      // Linux: Use lsof
      const { stdout } = await execAsync(`lsof -iTCP:${port} -sTCP:LISTEN -t`);
      const pid = parseInt(stdout.trim());
      return isNaN(pid) ? null : pid;
    }
  } catch (err) {
    return null;
  }
}

function readPlayerFile(serverId, fileName) {
    const filePath = resolveServerPath(serverId, fileName);
    if (fs.existsSync(filePath)) {
        try {
            return JSON.parse(fs.readFileSync(filePath, 'utf8')) || [];
        } catch (err) {
            console.error(`Error reading ${fileName} for server ${serverId}`, err);
            return [];
        }
    }
    return [];
}

function writePlayerFile(serverId, fileName, data) {
    const filePath = resolveServerPath(serverId, fileName);
    try {
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
    } catch (err) {
        console.error(`Error writing ${fileName} for server ${serverId}`, err);
    }
}

async function getUUID(name) {
    try {
        const { data } = await axios.get(`https://api.mojang.com/users/profiles/minecraft/${name}`);
        const id = data.id;
        return `${id.substr(0,8)}-${id.substr(8,4)}-${id.substr(12,4)}-${id.substr(16,4)}-${id.substr(20)}`;
    } catch {
        return null;
    }
}

function executeCommand(serverId, cmd) {
  sendCommand(serverId, cmd).catch(err => console.error('Execute command failed:', err));
  return true; // backward compatible
}

function getOnlinePlayers(serverId) {
    return onlinePlayers[serverId] || [];
}

async function setWorldSeed(worldDir, newSeed) {
    try {
        const levelPath = path.join(worldDir, 'level.dat');
        const buf = fs.readFileSync(levelPath);
        const uncompressed = zlib.gunzipSync(buf);
        const parsed = await nbtParse(uncompressed);
        if (!parsed.value.Data) parsed.value.Data = { type: 'compound', value: {} };
        parsed.value.Data.value.Seed = { type: 'long', value: BigInt(newSeed) };
        const written = prismarineNbt.writeUncompressed(parsed);
        const compressed = zlib.gzipSync(written);
        fs.writeFileSync(levelPath, compressed);
    } catch (err) {
        throw err;
    }
}

async function extractPluginInfo(jarPath, filename) {
    try {
        const AdmZip = require('adm-zip');
        const zip = new AdmZip(jarPath);
        
        // Try to find plugin.yml (Bukkit/Spigot) or paper-plugin.yml (Paper)
        let pluginYml = zip.getEntry('plugin.yml');
        if (!pluginYml) {
            pluginYml = zip.getEntry('paper-plugin.yml');
        }
        if (!pluginYml) {
            pluginYml = zip.getEntry('bungee.yml'); // BungeeCord plugins
        }
        
        if (pluginYml) {
            const content = zip.readAsText(pluginYml);
            const yaml = require('js-yaml');
            const data = yaml.load(content);
            
            return {
                name: data.name || filename.replace('.jar', ''),
                version: data.version || 'Unknown',
                description: data.description || null,
                author: data.author || (data.authors && data.authors[0]) || null,
                website: data.website || null,
                main: data.main || null
            };
        }
        
        // If no plugin.yml, try to extract from manifest
        const manifest = zip.getEntry('META-INF/MANIFEST.MF');
        if (manifest) {
            const content = zip.readAsText(manifest);
            const versionMatch = content.match(/Implementation-Version:\s*(.+)/i);
            if (versionMatch) {
                return {
                    name: filename.replace('.jar', ''),
                    version: versionMatch[1].trim(),
                    description: null,
                    author: null,
                    website: null
                };
            }
        }
        
        return {
            name: filename.replace('.jar', ''),
            version: 'Unknown',
            description: null,
            author: null,
            website: null
        };
    } catch (err) {
        console.error(`Error extracting plugin info from ${filename}:`, err.message);
        return {
            name: filename.replace('.jar', ''),
            version: 'Unknown',
            description: null,
            author: null,
            website: null
        };
    }
}

function parseVelocityToml(content) {
    const config = {};
    const lines = content.split('\n');
    let currentSection = null;
    
    for (const line of lines) {
        const trimmed = line.trim();
        
        // Skip comments and empty lines
        if (!trimmed || trimmed.startsWith('#')) continue;
        
        // Handle sections
        if (trimmed.startsWith('[') && trimmed.endsWith(']')) {
            currentSection = trimmed.slice(1, -1);
            if (!config[currentSection]) config[currentSection] = {};
            continue;
        }
        
        // Handle key-value pairs
        const equalIndex = trimmed.indexOf('=');
        if (equalIndex === -1) continue;
        
        const key = trimmed.substring(0, equalIndex).trim();
        let value = trimmed.substring(equalIndex + 1).trim();
        
        // Parse value types
        if (value.startsWith('"') && value.endsWith('"')) {
            value = value.slice(1, -1); // String
        } else if (value === 'true' || value === 'false') {
            value = value === 'true'; // Boolean
        } else if (!isNaN(value)) {
            value = parseInt(value); // Number
        } else if (value.startsWith('[') && value.endsWith(']')) {
            // Array
            value = value.slice(1, -1).split(',').map(v => v.trim().replace(/"/g, ''));
        }
        
        if (currentSection) {
            config[currentSection][key] = value;
        } else {
            config[key] = value;
        }
    }
    
    return config;
}

function getDefaultVelocityConfig(server) {
    return {
        // Main configuration
        'config-version': '2.6',
        'bind': `0.0.0.0:${server.port}`,
        'motd': server.name || 'A Velocity Server',
        'show-max-players': 500,
        'online-mode': true,
        'prevent-client-proxy-connections': false,
        'player-info-forwarding-mode': 'MODERN',
        'forwarding-secret-file': 'forwarding.secret',
        'announce-forge': false,
        'kick-existing-players': false,
        'ping-passthrough': 'DISABLED',
        'enable-player-address-logging': true,
        'bungee-plugin-message-channel': true,
        'show-ping-requests': false,
        'failover-on-unexpected-server-disconnect': true,
        'announce-proxy-commands': true,
        'log-command-executions': false,
        'log-player-connections': true,
        
        // Servers section
        'servers': {
            'lobby': 'localhost:25565',
            'survival': 'localhost:25566'
        },
        
        // Try section
        'try': ['lobby'],
        
        // Forced hosts
        'forced-hosts': {},
        
        // Advanced section
        'advanced': {
            'compression-threshold': 256,
            'compression-level': -1,
            'login-ratelimit': 3000,
            'connection-timeout': 5000,
            'read-timeout': 30000,
            'haproxy-protocol': false,
            'tcp-fast-open': false,
            'bungee-plugin-message-channel': true,
            'show-ping-requests': false,
            'failover-on-unexpected-server-disconnect': true,
            'announce-proxy-commands': true,
            'log-command-executions': false,
            'log-player-connections': true
        },
        
        // Query section
        'query': {
            'enabled': false,
            'port': server.port + 1,
            'map': 'Velocity',
            'show-plugins': false
        }
    };
}

function writeVelocityToml(config, filePath) {
    let content = '# Velocity Configuration\n';
    content += '# Generated by Minecraft Server Panel\n\n';
    
    // Write main configuration values
    const mainKeys = ['config-version', 'bind', 'motd', 'show-max-players', 'online-mode', 
                     'prevent-client-proxy-connections', 'player-info-forwarding-mode', 
                     'forwarding-secret-file', 'announce-forge', 'kick-existing-players',
                     'ping-passthrough', 'enable-player-address-logging', 'bungee-plugin-message-channel',
                     'show-ping-requests', 'failover-on-unexpected-server-disconnect',
                     'announce-proxy-commands', 'log-command-executions', 'log-player-connections'];
    
    for (const key of mainKeys) {
        if (config[key] !== undefined) {
            content += `${key} = ${formatTomlValue(config[key])}\n`;
        }
    }
    
    content += '\n';
    
    // Write servers section
    if (config.servers) {
        content += '[servers]\n';
        for (const [name, address] of Object.entries(config.servers)) {
            content += `${name} = "${address}"\n`;
        }
        content += '\n';
    }
    
    // Write try section
    if (config.try && Array.isArray(config.try)) {
        content += `try = [${config.try.map(s => `"${s}"`).join(', ')}]\n\n`;
    }
    
    // Write forced-hosts section
    if (config['forced-hosts']) {
        content += '[forced-hosts]\n';
        for (const [host, server] of Object.entries(config['forced-hosts'])) {
            content += `"${host}" = "${server}"\n`;
        }
        content += '\n';
    }
    
    // Write advanced section
    if (config.advanced) {
        content += '[advanced]\n';
        for (const [key, value] of Object.entries(config.advanced)) {
            content += `${key} = ${formatTomlValue(value)}\n`;
        }
        content += '\n';
    }
    
    // Write query section
    if (config.query) {
        content += '[query]\n';
        for (const [key, value] of Object.entries(config.query)) {
            content += `${key} = ${formatTomlValue(value)}\n`;
        }
        content += '\n';
    }
    
    fs.writeFileSync(filePath, content, 'utf8');
}

function formatTomlValue(value) {
    if (typeof value === 'string') {
        return `"${value}"`;
    } else if (typeof value === 'boolean') {
        return value.toString();
    } else if (typeof value === 'number') {
        return value.toString();
    } else if (Array.isArray(value)) {
        return `[${value.map(v => `"${v}"`).join(', ')}]`;
    }
    return `"${value}"`;
}

async function updateVelocityConfig(serverId, config) {
    const configPath = resolveServerPath(serverId, 'velocity.toml');
    writeVelocityToml(config, configPath);
}

function getDefaultProperties(server) {
    return {
        'server-ip': '',
        'server-port': server.port,
        'motd': server.name || 'Minecraft Server',
        'max-players': 20,
        'gamemode': 'survival',
        'difficulty': 'normal',
        'hardcore': false,
        'pvp': true,
        'allow-flight': false,
        'level-name': 'world',
        'level-seed': '',
        'level-type': 'minecraft:normal',
        'generate-structures': true,
        'spawn-animals': true,
        'spawn-monsters': true,
        'view-distance': 10,
        'simulation-distance': 10,
        'max-tick-time': 60000,
        'online-mode': true,
        'white-list': false,
        'enforce-whitelist': false,
        'spawn-protection': 16,
        'enable-command-block': false,
        'function-permission-level': 2,
        'op-permission-level': 4,
        'resource-pack': '',
        'resource-pack-sha1': ''
    };
}

    // Multer instances
    const upload = multer({
        dest: path.join(__panelRoot, 'uploads/'),
        limits: { fileSize: 10 * 1024 * 1024 * 1024 }
    });

    const modUpload = multer({ dest: 'uploads/', limits: { fileSize: 200 * 1024 * 1024 } });

    const iconUpload = multer({ dest: 'uploads/', limits: { fileSize: 5 * 1024 * 1024 }, fileFilter: (req, f, cb) => cb(null, /image\/(png|jpeg|jpg)/.test(f.mimetype)) });

app.get('/servers/:id/dashboard', requireAuth, async (req, res) => {
  try {
      const serverId = req.params.id;
      // Check authorization
      if (!await isAuthorized(req, serverId)) {
          return res.status(403).send('Access denied'); // simple fallback
      }
      // Fetch server
      const server = await dbGet(`
        SELECT s.*, 
               a.ip AS allocation_ip, a.alias AS allocation_alias, a.port AS allocation_port,
               n.name AS node_name, n.maintenance_mode AS node_maintenance_mode
        FROM servers s
        LEFT JOIN allocations a ON s.id = a.server_id
        LEFT JOIN nodes n ON s.node_id = n.id
        WHERE s.id = ?
      `, [serverId]);
      if (!server) {
          return res.status(404).send('Server not found'); // simple fallback
      }
      
      // Check if node is in maintenance mode
      if (server.node_maintenance_mode === 1) {
          return res.status(403).render('error', await getTemplateVars(req, null, { 
              message: 'This node is currently in maintenance mode. Please try again later.', 
              status: 403, 
              title: 'Maintenance Mode' 
          }));
      }
      // Calculate uptime, CPU, memory
      let uptime = 'Offline';
      let uptimeSeconds = 0;
      let cpu = 'N/A';
      let memory = 'N/A';
      let onlineCount = 0;
      const running = await isServerRunning(serverId);
      
      if (running) {
          // Load start time from memory or file
          let startTime = serverStartTimes[serverId];
          if (!startTime) {
              startTime = loadServerStartTime(serverId);
              if (startTime) {
                  serverStartTimes[serverId] = startTime;
                  console.log(`Loaded start time from file for server ${serverId} in dashboard route`);
              }
          }
          
          if (startTime) {
              const diff = Date.now() - startTime;
              uptimeSeconds = Math.floor(diff / 1000);
              const days = Math.floor(diff / 86400000);
              const hrs = Math.floor((diff % 86400000) / 3600000);
              const mins = Math.floor((diff % 3600000) / 60000);
              const secs = Math.floor((diff % 60000) / 1000);
              
              if (days > 0) {
                  uptime = `${days}d ${hrs}h ${mins}m`;
              } else if (hrs > 0) {
                  uptime = `${hrs}h ${mins}m ${secs}s`;
              } else if (mins > 0) {
                  uptime = `${mins}m ${secs}s`;
              } else {
                  uptime = `${secs}s`;
              }
          } else {
              uptime = 'Unknown';
          }
          
          const pid = await getPidByPort(server.port);
          if (pid) {
            try {
              const stats = await pidusage(pid);
              cpu = stats.cpu.toFixed(1);
              memory = (stats.memory / 1024 / 1024).toFixed(1);
            } catch (e) {
              console.error('Pidusage error:', e);
            }
          }
      }
      onlineCount = (onlinePlayers[serverId] && onlinePlayers[serverId].length) || 0;
      // Get recent logs
      let logContent = '';
      const logPath = path.join(SERVERS_DIR, serverId.toString(), 'logs', 'latest.log');
      if (fs.existsSync(logPath)) {
          try {
              const stats = fs.statSync(logPath);
              const maxRead = 100 * 1024; // 100KB
              const readLength = Math.min(stats.size, maxRead);
              const buffer = Buffer.alloc(readLength);
              const fd = fs.openSync(logPath, 'r');
              fs.readSync(fd, buffer, 0, readLength, stats.size - readLength);
              logContent = buffer.toString('utf8');
              fs.closeSync(fd);
          } catch {}
      }
      // Get total servers for footer
      const allServers = await dbAll('SELECT * FROM servers'); // or filter by owner if needed
      const totalServers = allServers.length;
      // Render dashboard
      res.render('servers/dashboard', await getTemplateVars(req, server, {
          uptime,
          cpu,
          memory,
          logContent,
          onlineCount,
          totalServers,
          onlinePlayers: onlinePlayers[serverId] || [],
          currentPage: 'dashboard',
          activePage: 'dashboard',
          query: req.query,
          liveStats: liveStats[serverId] || {},
          title: `${server.name} - Dashboard`
      }));
  } catch (err) {
      console.error('Server dashboard error:', err);
      res.status(500).send('Failed to load dashboard'); // fallback to avoid missing error view
  }
});
app.get('/servers/:id/stats', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        
        // Check authorization
        if (!await isAuthorized(req, serverId)) {
            return res.status(403).json({ success: false, error: 'Access denied' });
        }
        
        // Fetch server info
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ success: false, error: 'Server not found' });
        }
        
        // Get live stats from cache (updated every 3 seconds by updateLiveStats)
        const stats = liveStats[serverId] || {};
        
        // Format response for dashboard
        const response = {
            cpu: parseFloat(stats.cpuPercent) || 0,
            memory: stats.memory || 0, // Keep in bytes - dashboard will convert to MB
            memoryPercent: stats.memoryPercent || 0,
            disk: stats.disk || 0, // Keep in bytes for now
            diskMB: stats.disk ? (stats.disk / (1024 * 1024)) : 0, // Convert bytes to MB
            uptime: stats.uptimeSeconds || 0,
            players: (onlinePlayers[serverId] || []).length,
            maxPlayers: stats.maxPlayers || 20,
            status: server.status || 'stopped',
            networkInKBs: stats.networkInKBs || 0,
            networkOutKBs: stats.networkOutKBs || 0,
            bandwidthUsedMB: stats.bandwidthUsed || 0,
            bandwidthLimitTB: 0, // Unlimited for now
            ddosBlocked: stats.ddosBlocked || 0
        };
        
        // Calculate uptime in seconds if server is running
        if (server.status === 'running') {
            const startTimeFile = path.join(resolveServerPath(serverId), '.server.starttime');
            if (fs.existsSync(startTimeFile)) {
                try {
                    const startTime = parseInt(fs.readFileSync(startTimeFile, 'utf8'));
                    response.uptime = Math.floor((Date.now() - startTime) / 1000);
                } catch (err) {
                    console.error(`Error reading start time for server ${serverId}:`, err);
                }
            }
        }
        
        res.json({ success: true, stats: response });
        
    } catch (err) {
        console.error('Server stats error:', err);
        res.status(500).json({ success: false, error: 'Failed to fetch stats' });
    }
});
app.get('/servers/:id/console', requireAuth, async (req, res) => {
  try {
      const serverId = req.params.id;
      // Check authorization
      if (!await isAuthorized(req, serverId)) {
          return res.status(403).render('error', await getTemplateVars(req, null, { message: 'Access denied', status: 403, title: 'Error' }));
      }
      // Fetch server info
      const server = await dbGet(`
        SELECT s.*, n.maintenance_mode AS node_maintenance_mode
        FROM servers s
        LEFT JOIN nodes n ON s.node_id = n.id
        WHERE s.id = ?
      `, [serverId]);
      if (!server) {
          return res.status(404).render('error', await getTemplateVars(req, null, { message: 'Server not found', status: 404, title: 'Error' }));
      }
      
      // Check if node is in maintenance mode
      if (server.node_maintenance_mode === 1) {
          return res.status(403).render('error', await getTemplateVars(req, null, { 
              message: 'This node is currently in maintenance mode. Please try again later.', 
              status: 403, 
              title: 'Maintenance Mode' 
          }));
      }
      // Get recent logs for initial load
      let logContent = '';
      const logPath = path.join(SERVERS_DIR, serverId.toString(), 'logs', 'latest.log');
      if (fs.existsSync(logPath)) {
          try {
              const stats = fs.statSync(logPath);
              const maxRead = 100 * 1024; // 100KB
              const readLength = Math.min(stats.size, maxRead);
              const buffer = Buffer.alloc(readLength);
              const fd = fs.openSync(logPath, 'r');
              fs.readSync(fd, buffer, 0, readLength, stats.size - readLength);
              logContent = buffer.toString('utf8');
              fs.closeSync(fd);
          } catch {}
      }
      // Fetch total servers for footer
      const totalServersRow = await dbGet('SELECT COUNT(*) AS count FROM servers');
      const totalServers = totalServersRow ? totalServersRow.count : 0;
      // Render console page with totalServers
      res.render('servers/console', await getTemplateVars(req, server, {
          logContent,
          activePage: 'console',
          currentPage: 'console',
          totalServers,
          liveStats: liveStats[serverId] || {},
          title: `${server.name} - Console`
      }));
  } catch (err) {
      console.error('Console page error:', err);
      res.status(500).render('error', await getTemplateVars(req, null, { message: 'Failed to load console', status: 500, title: 'Error' }));
  }
});
app.get('/servers/:id/activity', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) {
            return res.status(403).json({ error: 'Access denied' });
        }
        
        const activities = await dbAll(`
            SELECT sa.*, u.username 
            FROM server_activity sa
            LEFT JOIN users u ON sa.user_id = u.id
            WHERE sa.server_id = ?
            ORDER BY sa.created_at DESC
            LIMIT 50
        `, [serverId]);
        
        res.json({ success: true, activities });
    } catch (err) {
        console.error('Get activity error:', err);
        res.status(500).json({ error: 'Failed to load activity' });
    }
});

// Check server EULA status
app.get('/servers/:id/eula', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) {
            return res.status(403).json({ error: 'Access denied' });
        }
        
        const result = checkAndAcceptEula(serverId);
        res.json({ success: true, ...result });
    } catch (err) {
        console.error('Check EULA error:', err);
        res.status(500).json({ error: 'Failed to check EULA' });
    }
});

// Accept server EULA
app.post('/servers/:id/eula', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) {
            return res.status(403).json({ error: 'Access denied' });
        }
        
        const result = checkAndAcceptEula(serverId, true);
        res.json({ success: true, ...result });
    } catch (err) {
        console.error('Accept EULA error:', err);
        res.status(500).json({ error: 'Failed to accept EULA' });
    }
});
app.post('/servers/:id/start', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        const { acceptEula } = req.body;
        
        if (!await isAuthorized(req, serverId)) {
            return res.status(403).json({ error: 'Access denied' });
        }
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }
        
        // Check if node is in maintenance mode
        if (await isNodeInMaintenance(server.node_id)) {
            return res.status(403).json({ error: 'This node is currently in maintenance mode. Please try again later.' });
        }
        
        if (await isServerRunning(serverId)) {
            return res.status(400).json({ error: 'Server already running' });
        }
        
        // Check EULA
        const eulaResult = checkAndAcceptEula(serverId, acceptEula);
        if (!eulaResult.accepted) {
            return res.status(400).json({ error: 'EULA not accepted', requiresEula: true });
        }
        
        await startServer(serverId);
        await logServerActivity(serverId, 'start', null, req.session.user.id, req.ip);
        res.json({ success: true, message: 'Server started' });
    } catch (err) {
        console.error('Start server error:', err);
        res.status(500).json({ error: 'Failed to start server' });
    }
});
app.post('/servers/:id/stop', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
     
        if (!await isAuthorized(req, serverId)) {
            return res.status(403).json({ error: 'Access denied' });
        }
     
        await stopServer(serverId, false);
        await logServerActivity(serverId, 'stop', null, req.session.user.id, req.ip);
     
        res.json({ success: true, message: 'Server stopped' });
    } catch (err) {
        console.error('Stop server error:', err);
        res.status(500).json({ error: 'Failed to stop server' });
    }
});
app.post('/servers/:id/kill', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
     
        if (!await isAuthorized(req, serverId)) {
            return res.status(403).json({ error: 'Access denied' });
        }
     
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }
     
        const success = await stopServer(serverId, true);
        if (success) {
            await logServerActivity(serverId, 'kill', null, req.session.user.id, req.ip);
            res.json({ success: true, message: 'Server killed' });
        } else {
            res.status(500).json({ error: 'Failed to kill server' });
        }
    } catch (err) {
        console.error('Kill server error:', err);
        res.status(500).json({ error: 'Failed to kill server' });
    }
});
app.post('/servers/:id/restart', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
     
        if (!await isAuthorized(req, serverId)) {
            return res.status(403).json({ error: 'Access denied' });
        }
     
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }
     
        if (!await isServerRunning(serverId)) {
            return res.status(400).json({ error: 'Server not running' });
        }
     
        // Stop the server first
        const stopped = await stopServer(serverId);
        if (!stopped) {
            return res.status(500).json({ error: 'Failed to stop server' });
        }
        
        // Wait a bit before starting
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Start the server again
        const started = await startServer(serverId);
        if (started) {
            await logServerActivity(serverId, 'restart', null, req.session.user.id, req.ip);
            res.json({ success: true, message: 'Server restarted successfully' });
        } else {
            res.status(500).json({ error: 'Failed to start server after stopping' });
        }
    } catch (err) {
        console.error('Restart server error:', err);
        res.status(500).json({ error: 'Failed to restart server' });
    }
});
app.post('/servers/:id/command', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        const { command } = req.body;
     
        if (!await isAuthorized(req, serverId)) {
            return res.status(403).json({ error: 'Access denied' });
        }
     
        if (!command) {
            return res.status(400).json({ error: 'Command required' });
        }
     
        if (!await isServerRunning(serverId)) {
            return res.status(400).json({ error: 'Server not running' });
        }
        
        // Use sendCommand which has RCON fallback for reconnected servers
        let success = await sendCommand(serverId, command);
        await logServerActivity(serverId, 'command', command, req.session.user.id, req.ip);
        
        // If command failed and we don't have stdin, try to auto-enable RCON
        if (!success) {
            const serverProcess = serverProcesses && serverProcesses[serverId];
            const hasStdin = serverProcess && !serverProcess.killed && serverProcess.stdin && serverProcess.stdin.writable;
            
            if (!hasStdin) {
                console.log(`Attempting to auto-enable RCON for server ${serverId}...`);
                const rconEnabled = await autoEnableRcon(serverId);
                
                if (rconEnabled) {
                    return res.status(400).json({ 
                        error: 'RCON has been automatically enabled. Please restart the server for changes to take effect.',
                        autoFixed: true,
                        action: 'restart'
                    });
                } else {
                    return res.status(400).json({ 
                        error: 'Could not enable RCON automatically. Please enable RCON manually in server.properties.',
                        hint: 'Add: enable-rcon=true, rcon.port=25575, rcon.password=admin123'
                    });
                }
            } else {
                return res.status(500).json({ error: 'Failed to send command. Please try again.' });
            }
        }
        
        res.json({ success: true, message: 'Command sent successfully' });
    } catch (err) {
        console.error('Send command error:', err);
        res.status(500).json({ error: 'Failed to send command' });
    }
});
app.get('/servers/:id/files', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).send('Access denied');
        const currentPath = req.query.path || '/';
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).send('Server not found');
        const dirPath = resolveServerPath(serverId, currentPath);
        if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, { recursive: true });
        const files = fs.readdirSync(dirPath, { withFileTypes: true }).map(dirent => {
            const full = path.join(dirPath, dirent.name);
            const relativePath = currentPath === '/' ? `/${dirent.name}` : `${currentPath}/${dirent.name}`;
            let stats;
            try {
                stats = fs.statSync(full);
            } catch {
                stats = {};
            }
            return {
                name: dirent.name,
                path: relativePath,
                isDirectory: dirent.isDirectory(),
                size: dirent.isDirectory() ? '-' : formatFileSize(stats.size || 0),
                modified: stats.mtime ? stats.mtime.toLocaleString() : null
            };
        });
        res.render('servers/filemanager', await getTemplateVars(req, server, {
            files, 
            currentPath, 
            path, 
            serverId: server.id, 
            currentPage: 'files', 
            activePage: 'files',
            title: `${server.name} - File Manager`
        }));
    } catch (err) {
        console.error('files list error', err);
        res.status(500).send('Error listing files');
    }
});
app.get('/servers/:id/files/view', requireAuth, async (req, res) => {
    try {
        const { id: serverId } = req.params;
        if (!await isAuthorized(req, serverId)) return res.status(403).send('Access denied');
        const filePath = req.query.path;
        
        if (!filePath) {
            const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
            return res.status(400).render('error', await getTemplateVars(req, server, {
                message: 'File path is required',
                error: 'Please specify a file to view',
                status: 400,
                title: 'Error'
            }));
        }

        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).send('Server not found');
        
        const fullPath = resolveServerPath(serverId, filePath);
        if (!fs.existsSync(fullPath)) {
            return res.status(404).render('error', await getTemplateVars(req, server, {
                message: 'File not found',
                error: 'The requested file does not exist',
                status: 404,
                title: 'Error'
            }));
        }
        
        const stats = fs.statSync(fullPath);
        if (stats.isDirectory()) {
            return res.status(400).render('error', await getTemplateVars(req, server, {
                message: 'Cannot view directory',
                error: 'Please use the file manager to browse directories',
                status: 400,
                title: 'Error'
            }));
        }
        
        const content = fs.readFileSync(fullPath, 'utf8');
        const pathModule = require('path');
        
        console.log('Rendering fileview with:', {
            serverId: server.id,
            filePath,
            contentLength: content.length,
            hasPath: !!pathModule
        });
        
        res.render('servers/fileview', await getTemplateVars(req, server, {
            content, 
            filePath, 
            path: pathModule,
            serverId: server.id, 
            activePage: 'files',
            title: `${server.name} - ${pathModule.basename(filePath)}`
        }));
    } catch (err) {
        console.error('file view error', err);
        res.status(500).send('Error viewing file: ' + err.message);
    }
});
app.get('/servers/:id/files/download', requireAuth, async (req, res) => {
    try {
        const { id: serverId } = req.params;
        if (!await isAuthorized(req, serverId)) return res.status(403).send('Access denied');
        const { path: filePath } = req.query;
        if (!filePath) return res.status(400).send('File path is required');
        const fullPath = resolveServerPath(serverId, filePath);
        if (!fs.existsSync(fullPath)) return res.status(404).send('File not found');
        res.download(fullPath);
    } catch (err) {
        console.error('download error', err);
        res.status(500).send('Error downloading file');
    }
});
app.post('/servers/:id/files/rename', requireAuth, async (req, res) => {
    try {
        const { id: serverId } = req.params;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { oldPath, newName } = req.body;
        if (!oldPath || !newName) return res.status(400).json({ error: 'Old path and new name are required' });
        const sanitizedNewName = sanitize(newName);
        if (!sanitizedNewName) return res.status(400).json({ error: 'Invalid new name' });
        const fullOld = resolveServerPath(serverId, oldPath);
        const fullNew = path.join(path.dirname(fullOld), sanitizedNewName);
        if (fs.existsSync(fullNew)) return res.status(409).json({ error: 'Name already exists' });
        fs.renameSync(fullOld, fullNew);
        res.json({ success: true });
    } catch (err) {
        console.error('rename error', err);
        res.status(500).json({ error: 'Failed to rename' });
    }
});
app.post('/servers/:id/files/delete', requireAuth, async (req, res) => {
    try {
        const { id: serverId } = req.params;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { path: targetPath } = req.body;
        if (!targetPath) return res.status(400).json({ error: 'Path is required' });
        
        // Check if server is running
        const running = await isServerRunning(serverId);
        if (running) {
            // Check if trying to delete plugin files
            if (targetPath.includes('plugins')) {
                return res.status(400).json({ 
                    error: 'Cannot delete plugin files while server is running. Please stop the server first.' 
                });
            }
        }
        
        const fullPath = resolveServerPath(serverId, targetPath);
        
        // Check if file exists
        if (!fs.existsSync(fullPath)) {
            return res.status(404).json({ error: 'File or folder not found' });
        }
        
        // Try to delete with retry logic for Windows file locking
        let attempts = 0;
        const maxAttempts = 3;
        let lastError = null;
        
        while (attempts < maxAttempts) {
            try {
                fs.rmSync(fullPath, { recursive: true, force: true });
                return res.json({ success: true });
            } catch (err) {
                lastError = err;
                
                // If EBUSY error (file locked), wait and retry
                if (err.code === 'EBUSY' || err.code === 'EPERM') {
                    attempts++;
                    if (attempts < maxAttempts) {
                        await new Promise(resolve => setTimeout(resolve, 500)); // Wait 500ms
                        continue;
                    }
                } else {
                    // Other errors, don't retry
                    throw err;
                }
            }
        }
        
        // If we get here, all retries failed
        if (lastError && (lastError.code === 'EBUSY' || lastError.code === 'EPERM')) {
            return res.status(400).json({ 
                error: 'File is locked by another process. Please stop the server and try again.' 
            });
        }
        
        throw lastError;
        
    } catch (err) {
        console.error('delete error', err);
        return res.status(500).json({ 
            error: err.code === 'EBUSY' || err.code === 'EPERM' 
                ? 'File is locked. Stop the server and try again.' 
                : 'Failed to delete' 
        });
    }
});
app.post('/servers/:id/files/zip', requireAuth, async (req, res) => {
    try {
        const { id: serverId } = req.params;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { path: targetPath } = req.body;
        if (!targetPath) return res.status(400).json({ error: 'Path is required' });
        const fullPath = resolveServerPath(serverId, targetPath);
        if (!fs.existsSync(fullPath)) return res.status(404).json({ error: 'Not found' });
        if (path.extname(fullPath) === '.zip') {
            return res.status(400).json({ error: 'Target is already a zip file' });
        }
        const zipName = path.basename(fullPath) + '.zip';
        const zipFullPath = path.join(path.dirname(fullPath), zipName);
        if (fs.existsSync(zipFullPath)) return res.status(409).json({ error: 'Zip file already exists' });
        const output = fs.createWriteStream(zipFullPath);
        const archive = archiver('zip', { zlib: { level: 9 } });
        let responseSent = false;
        
        archive.on('error', (err) => {
            if (responseSent) return;
            responseSent = true;
            console.error('zip archive error', err);
            res.status(500).json({ error: 'Failed to create zip' });
        });
        
        output.on('close', () => {
            if (responseSent) return;
            responseSent = true;
            const relativeZipPath = path.relative(resolveServerPath(serverId, '/'), zipFullPath);
            res.json({ success: true, zipPath: relativeZipPath });
        });
        
        archive.pipe(output);
        const stats = fs.statSync(fullPath);
        if (stats.isDirectory()) {
            archive.directory(fullPath, false);
        } else {
            archive.file(fullPath, { name: path.basename(fullPath) });
        }
        archive.finalize();
    } catch (err) {
        console.error('zip error', err);
        res.status(500).json({ error: 'Failed to create zip' });
    }
});
app.post('/servers/:id/files/unzip', requireAuth, async (req, res) => {
    try {
        const { id: serverId } = req.params;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { path: targetPath } = req.body;
        if (!targetPath) return res.status(400).json({ error: 'Path is required' });
        const fullPath = resolveServerPath(serverId, targetPath);
        if (!fs.existsSync(fullPath)) return res.status(404).json({ error: 'Not found' });
        if (path.extname(fullPath) !== '.zip') return res.status(400).json({ error: 'Not a zip file' });
        const extractDir = path.dirname(fullPath);
        await new Promise((resolve, reject) => {
            fs.createReadStream(fullPath)
                .pipe(unzipper.Extract({ path: extractDir }))
                .on('close', resolve)
                .on('error', reject);
        });
        res.json({ success: true });
    } catch (err) {
        console.error('unzip error', err);
        res.status(500).json({ error: 'Failed to unzip' });
    }
});
app.post('/servers/:id/files/upload', requireAuth, upload.single('file'), async (req, res) => {
    try {
        const { id: serverId } = req.params;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
        const targetDir = req.body.path || '/';
        const destDir = resolveServerPath(serverId, targetDir);
        if (!fs.existsSync(destDir)) fs.mkdirSync(destDir, { recursive: true });
        const destPath = path.join(destDir, sanitize(req.file.originalname));
        if (fs.existsSync(destPath)) return res.status(409).json({ error: 'File already exists' });
        fs.renameSync(req.file.path, destPath);
        res.json({ success: true });
    } catch (err) {
        console.error('upload error', err);
        res.status(500).json({ error: 'Failed to upload' });
    } finally {
        if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
    }
});
app.post('/servers/:id/files/create', requireAuth, async (req, res) => {
    try {
        const { id: serverId } = req.params;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { path: targetPath, filename } = req.body;
        if (!filename) return res.status(400).json({ error: 'Filename is required' });
        const sanitizedFilename = sanitize(filename);
        if (!sanitizedFilename) return res.status(400).json({ error: 'Invalid filename' });
        
        // Construct the full path correctly
        const targetDir = resolveServerPath(serverId, targetPath || '/');
        const fullPath = path.join(targetDir, sanitizedFilename);
        
        // Ensure the directory exists
        if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });
        
        // Check if file already exists
        if (fs.existsSync(fullPath)) return res.status(409).json({ error: 'File already exists' });
        
        // Create the file
        fs.writeFileSync(fullPath, '', 'utf8');
        res.json({ success: true });
    } catch (err) {
        console.error('create file error', err);
        res.status(500).json({ error: 'Failed to create file' });
    }
});

app.post('/servers/:id/files/create-folder', requireAuth, async (req, res) => {
    try {
        const { id: serverId } = req.params;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { path: targetPath, foldername } = req.body;
        if (!foldername) return res.status(400).json({ error: 'Folder name is required' });
        const sanitizedFoldername = sanitize(foldername);
        if (!sanitizedFoldername) return res.status(400).json({ error: 'Invalid folder name' });
        
        // Construct the full path correctly
        const targetDir = resolveServerPath(serverId, targetPath || '/');
        const fullPath = path.join(targetDir, sanitizedFoldername);
        
        // Check if folder already exists
        if (fs.existsSync(fullPath)) return res.status(409).json({ error: 'Folder already exists' });
        
        // Create the folder
        fs.mkdirSync(fullPath, { recursive: true });
        res.json({ success: true });
    } catch (err) {
        console.error('create folder error', err);
        res.status(500).json({ error: 'Failed to create folder' });
    }
});

app.post('/servers/:id/files/bulk-zip', requireAuth, async (req, res) => {
    try {
        const { id: serverId } = req.params;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { paths, zipName } = req.body;
        if (!paths || !Array.isArray(paths) || paths.length === 0) {
            return res.status(400).json({ error: 'Paths array is required' });
        }
        if (!zipName) return res.status(400).json({ error: 'Zip name is required' });
        
        const sanitizedZipName = sanitize(zipName);
        if (!sanitizedZipName) return res.status(400).json({ error: 'Invalid zip name' });
        
        const serverDir = resolveServerPath(serverId);
        const zipFullPath = path.join(serverDir, sanitizedZipName);
        
        if (fs.existsSync(zipFullPath)) return res.status(409).json({ error: 'Zip file already exists' });
        
        const output = fs.createWriteStream(zipFullPath);
        const archive = archiver('zip', { zlib: { level: 9 } });
        let responseSent = false;
        
        archive.on('error', (err) => {
            if (responseSent) return;
            responseSent = true;
            console.error('bulk zip archive error', err);
            res.status(500).json({ error: 'Failed to create zip' });
        });
        
        output.on('close', () => {
            if (responseSent) return;
            responseSent = true;
            res.json({ success: true, zipPath: sanitizedZipName });
        });
        
        archive.pipe(output);
        
        // Add each path to the archive
        for (const targetPath of paths) {
            const fullPath = resolveServerPath(serverId, targetPath);
            if (fs.existsSync(fullPath)) {
                const stats = fs.statSync(fullPath);
                const baseName = path.basename(fullPath);
                
                if (stats.isDirectory()) {
                    archive.directory(fullPath, baseName);
                } else {
                    archive.file(fullPath, { name: baseName });
                }
            }
        }
        
        archive.finalize();
    } catch (err) {
        console.error('bulk zip error', err);
        res.status(500).json({ error: 'Failed to create bulk zip' });
    }
});

// Alias for /files/edit - used by file viewer
app.post('/servers/:id/files/save', requireAuth, async (req, res) => {
    try {
        const { id: serverId } = req.params;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { path: filePath, content } = req.body;
        if (!filePath || content === undefined) return res.status(400).json({ error: 'File path and content are required' });
        
        const fullPath = resolveServerPath(serverId, filePath);
        const fileName = path.basename(fullPath);
        
        // Protect server.properties from port changes
        if (fileName === 'server.properties') {
            const server = await dbGet('SELECT port FROM servers WHERE id = ?', [serverId]);
            if (server) {
                const sanitizedContent = sanitizeServerProperties(content, server.port);
                fs.writeFileSync(fullPath, sanitizedContent, 'utf8');
                
                // Check if user tried to change the port
                const userProperties = parseProperties(content);
                const userPort = parseInt(userProperties['server-port']);
                
                if (userPort && userPort !== server.port) {
                    res.json({ 
                        success: true, 
                        message: 'File saved successfully',
                        warning: `Note: Server port cannot be changed (kept at ${server.port}). All other settings were saved.`
                    });
                } else {
                    res.json({ 
                        success: true, 
                        message: 'File saved successfully'
                    });
                }
                return;
            }
        }
        
        // Protect velocity.toml from bind port changes
        if (fileName === 'velocity.toml') {
            const server = await dbGet('SELECT port FROM servers WHERE id = ?', [serverId]);
            if (server) {
                const sanitizedContent = sanitizeVelocityToml(content, server.port);
                fs.writeFileSync(fullPath, sanitizedContent, 'utf8');
                
                // Check if user tried to change the bind port
                const bindRegex = /bind\s*=\s*"[^"]*"/g;
                const userBindMatch = content.match(bindRegex);
                const expectedBind = `bind = "0.0.0.0:${server.port}"`;
                
                if (userBindMatch && !content.includes(expectedBind)) {
                    res.json({ 
                        success: true, 
                        message: 'velocity.toml saved successfully',
                        warning: `Note: Bind port cannot be changed (kept at 0.0.0.0:${server.port}). All other settings were saved.`
                    });
                } else {
                    res.json({ 
                        success: true, 
                        message: 'velocity.toml saved successfully'
                    });
                }
                return;
            }
        }
        
        // Protect BungeeCord config.yml from port changes
        if (fileName === 'config.yml') {
            const server = await dbGet('SELECT port, server_type FROM servers WHERE id = ?', [serverId]);
            if (server && ['bungeecord', 'waterfall'].includes(server.server_type)) {
                const sanitizedContent = sanitizeBungeeCordConfig(content, server.port);
                fs.writeFileSync(fullPath, sanitizedContent, 'utf8');
                
                // Check if user tried to change the host port
                const hostRegex = /host:\s*[^:]+:(\d+)/g;
                const userPortMatch = content.match(hostRegex);
                let userTriedToChangePort = false;
                
                if (userPortMatch) {
                    userPortMatch.forEach(match => {
                        const portMatch = match.match(/:(\d+)$/);
                        if (portMatch && parseInt(portMatch[1]) !== server.port) {
                            userTriedToChangePort = true;
                        }
                    });
                }
                
                if (userTriedToChangePort) {
                    res.json({ 
                        success: true, 
                        message: 'config.yml saved successfully',
                        warning: `Note: Proxy port cannot be changed (kept at ${server.port}). All other settings were saved.`
                    });
                } else {
                    res.json({ 
                        success: true, 
                        message: 'config.yml saved successfully'
                    });
                }
                return;
            }
        }
        
        const dir = path.dirname(fullPath);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        if (fs.existsSync(fullPath) && fs.statSync(fullPath).isDirectory()) {
            return res.status(400).json({ error: 'Path is a directory' });
        }
        fs.writeFileSync(fullPath, content, 'utf8');
        res.json({ success: true, message: 'File saved successfully' });
    } catch (err) {
        console.error('file save error', err);
        res.status(500).json({ error: 'Failed to save file' });
    }
});
app.post('/servers/:id/files/mkdir', requireAuth, async (req, res) => {
    try {
        const { id: serverId } = req.params;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { path: parentPath, name } = req.body;
        if (!name) return res.status(400).json({ error: 'Name is required' });
        const sanitizedName = sanitize(name);
        if (!sanitizedName) return res.status(400).json({ error: 'Invalid folder name' });
        const fullPath = resolveServerPath(serverId, path.join(parentPath || '/', sanitizedName));
        if (fs.existsSync(fullPath)) return res.status(409).json({ error: 'Folder already exists' });
        fs.mkdirSync(fullPath, { recursive: true });
        res.json({ success: true });
    } catch (err) {
        console.error('create folder error', err);
        res.status(500).json({ error: 'Failed to create folder' });
    }
});
app.get('/servers/:id/subusers', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).send('Server not found');
        // Only owner or admin can manage subusers
        if (server.owner_id !== req.session.user.id && req.session.user.role !== 'admin')
            return res.status(403).send('Access denied');
        const subusers = await dbAll(
            `SELECT subusers.id, users.username, users.id as user_id
             FROM subusers
             JOIN users ON subusers.user_id = users.id
             WHERE subusers.server_id = ?`,
            [serverId]
        );
        res.render('servers/subusers', await getTemplateVars(req, server, {
            subusers,
            serverId: server.id,
            activePage: 'subusers',
            title: `${server.name} - Sub Users`
        }));
    } catch (err) {
        console.error('Subusers page error:', err);
        res.status(500).send('Internal server error');
    }
});
app.post('/servers/:id/subusers/add', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        const { username } = req.body;
        if (!(username && username.trim()))
            return res.status(400).json({ error: 'Username is required' });
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ error: 'Server not found' });
        if (server.owner_id !== req.session.user.id && req.session.user.role !== 'admin')
            return res.status(403).json({ error: 'Access denied' });
        const user = await dbGet('SELECT * FROM users WHERE username = ?', [username.trim()]);
        if (!user) return res.status(404).json({ error: 'User not found' });
        if (user.id === server.owner_id) return res.status(400).json({ error: 'Owner cannot be added as subuser' });
        const existingSub = await dbGet(
            'SELECT * FROM subusers WHERE server_id = ? AND user_id = ?',
            [serverId, user.id]
        );
        if (existingSub) return res.status(400).json({ error: 'User is already a subuser' });
        await dbRun('INSERT INTO subusers (server_id, user_id) VALUES (?, ?)', [serverId, user.id]);
        res.redirect(`/servers/${serverId}/subusers`);
    } catch (err) {
        console.error('Add subuser error:', err);
        res.status(500).json({ error: 'Failed to add subuser' });
    }
});
app.post('/servers/:id/subusers/remove', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        const { subuserId } = req.body;
        if (!subuserId) return res.status(400).json({ error: 'Subuser ID is required' });
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ error: 'Server not found' });
        if (server.owner_id !== req.session.user.id && req.session.user.role !== 'admin')
            return res.status(403).json({ error: 'Access denied' });
        const deleted = await dbRun(
            'DELETE FROM subusers WHERE id = ? AND server_id = ?',
            [subuserId, serverId]
        );
        if (deleted.changes === 0) return res.status(404).json({ error: 'Subuser not found' });
        res.redirect(`/servers/${serverId}/subusers`);
    } catch (err) {
        console.error('Remove subuser error:', err);
        res.status(500).json({ error: 'Failed to remove subuser' });
    }
});
app.get('/servers/:id/settings', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).render('error', await getTemplateVars(req, null, { message: 'Access denied', status: 403, title: 'Error' }));
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).render('error', await getTemplateVars(req, null, { message: 'Server not found', status: 404, title: 'Error' }));
        
        const serverSettings = JSON.parse(server.settings || '{}');
        const versions = await fetchMinecraftVersions(server.server_type);
        const serverSoftware = getAvailableServerSoftware();
        
        // Proper disk usage calculation
        const serverDir = resolveServerPath(serverId);
        let diskUsage = 0;
        try {
            diskUsage = getDirSize(serverDir);
        } catch {}
        
        // Get template vars with server context
        const templateVars = await getTemplateVars(req, server, {
            serverSettings,
            versions,
            serverSoftware,
            diskUsage: formatFileSize(diskUsage),
            serverId,
            query: req.query,
            currentPage: 'settings',
            activePage: 'settings',
            title: `${server.name} - Settings`
        });
        
        // Ensure server is explicitly available at top level for sidebar
        templateVars.server = server;
        
        res.render('servers/settings', templateVars);
    } catch (err) {
        console.error('Settings error:', err);
        res.status(500).render('error', await getTemplateVars(req, null, { message: 'Failed to load settings', status: 500, title: 'Error' }));
    }
});
// Get versions for specific server software
app.get('/servers/:id/settings/versions/:serverType', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        const serverType = req.params.serverType;
        
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const versions = await fetchMinecraftVersions(serverType);
        res.json({ success: true, versions });
    } catch (err) {
        console.error('Fetch versions error:', err);
        res.status(500).json({ error: 'Failed to fetch versions' });
    }
});

// Validate custom version
app.post('/servers/:id/settings/validate-version', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        const { version, serverType } = req.body;
        
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        if (!version) {
            return res.status(400).json({ error: 'Version is required' });
        }
        
        const isValid = isValidMinecraftVersion(version);
        
        if (isValid) {
            res.json({ 
                success: true, 
                valid: true, 
                message: `Version "${version}" is valid for ${serverType}`,
                version: version.trim()
            });
        } else {
            res.json({ 
                success: true, 
                valid: false, 
                message: 'Invalid version format. Use formats like: 1.20.1, 1.19.4, 20w14a, latest, etc.'
            });
        }
    } catch (err) {
        console.error('Validate version error:', err);
        res.status(500).json({ error: 'Failed to validate version' });
    }
});

app.post('/servers/:id/settings/update', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const { name, description, version, serverType } = req.body;
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }
        
        if (server.owner_id !== req.session.user.id && req.session.user.role !== 'admin') {
            return res.status(403).json({ error: 'Access denied' });
        }
        
        if (!name) {
            return res.status(400).json({ error: 'Server name is required' });
        }
        
        // Update server information
        const updateFields = [name, description || null];
        let updateQuery = 'UPDATE servers SET name = ?, description = ?';
        
        let message = 'Settings updated successfully';
        
        // If version and serverType are provided, update them too
        if (version && serverType) {
            updateQuery += ', version = ?, server_type = ?';
            updateFields.push(version, serverType);
            
            // DO NOT change port when server type changes - keep existing port
            // Only update configuration files to match the new server type
            if (serverType !== server.server_type) {
                console.log(`Server ${serverId} type changed from ${server.server_type} to ${serverType}, keeping existing port ${server.port}`);
                message += ` Server type updated. Port ${server.port} preserved.`;
            }
            
            message += '. Server software and version updated - restart server to apply changes.';
        }
        
        updateQuery += ' WHERE id = ?';
        updateFields.push(serverId);
        
        await dbRun(updateQuery, updateFields);
        
        // If server type changed, update configuration files with existing port
        if (version && serverType && serverType !== server.server_type) {
            try {
                // Use the existing port (don't change it)
                await updateServerConfigurationPort(serverId, serverType, server.port);
                console.log(`Updated configuration files for server ${serverId} (${serverType}) with existing port ${server.port}`);
            } catch (configErr) {
                console.error(`Failed to update configuration files for server ${serverId}:`, configErr);
                // Don't fail the entire request for config file issues
            }
        }
        
        res.json({ success: true, message });
    } catch (err) {
        console.error('Update settings error:', err);
        res.status(500).json({ error: 'Failed to update settings' });
    }
});
app.get('/servers/:id/velocity', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!(await isAuthorized(req, serverId))) {
            return res.status(403).send('Access denied');
        }

        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).send('Server not found');
        }

        // Only allow for Velocity servers
        if (server.server_type !== 'velocity') {
            return res.status(400).send('This server is not a Velocity proxy server');
        }

        res.render('servers/velocity', await getTemplateVars(req, server, {
            activePage: 'velocity',
            currentPage: 'velocity-config'
        }));
    } catch (err) {
        console.error('Velocity config page error:', err);
        res.status(500).send('Internal server error');
    }
});

// Get current Velocity configuration as JSON
app.get('/servers/:id/velocity/get', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!(await isAuthorized(req, serverId))) {
            return res.status(403).json({ error: 'Access denied' });
        }

        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }

        if (server.server_type !== 'velocity') {
            return res.status(400).json({ error: 'This server is not a Velocity proxy server' });
        }

        const configPath = resolveServerPath(serverId, 'velocity.toml');
        let config = {};

        if (fs.existsSync(configPath)) {
            try {
                const content = fs.readFileSync(configPath, 'utf8');
                config = parseVelocityToml(content);
            } catch (err) {
                console.error('Error reading velocity.toml:', err);
                config = getDefaultVelocityConfig(server);
            }
        } else {
            config = getDefaultVelocityConfig(server);
            await updateVelocityConfig(serverId, config);
        }

        res.json({ success: true, config });
    } catch (err) {
        console.error('Get Velocity config error:', err);
        res.status(500).json({ error: 'Failed to load Velocity configuration' });
    }
});

// Save Velocity configuration
app.post('/servers/:id/velocity/save', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!(await isAuthorized(req, serverId))) {
            return res.status(403).json({ error: 'Access denied' });
        }

        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }

        if (server.server_type !== 'velocity') {
            return res.status(400).json({ error: 'This server is not a Velocity proxy server' });
        }

        const { config } = req.body;
        if (!config || typeof config !== 'object') {
            return res.status(400).json({ error: 'Invalid configuration data' });
        }

        // Ensure bind port is protected
        config.bind = `0.0.0.0:${server.port}`;

        const configPath = resolveServerPath(serverId, 'velocity.toml');
        
        // Write configuration to file
        writeVelocityToml(config, configPath);

        console.log(`Velocity configuration saved for server ${serverId}`);
        
        res.json({ 
            success: true, 
            message: 'Velocity configuration saved successfully!',
            warning: 'Bind port is protected and managed automatically'
        });
    } catch (err) {
        console.error('Save Velocity config error:', err);
        res.status(500).json({ error: 'Failed to save Velocity configuration' });
    }
});

// Reset Velocity configuration to defaults
app.post('/servers/:id/velocity/reset', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!(await isAuthorized(req, serverId))) {
            return res.status(403).json({ error: 'Access denied' });
        }

        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }

        if (server.server_type !== 'velocity') {
            return res.status(400).json({ error: 'This server is not a Velocity proxy server' });
        }

        const defaultConfig = getDefaultVelocityConfig(server);
        await updateVelocityConfig(serverId, defaultConfig);

        console.log(`Velocity configuration reset to defaults for server ${serverId}`);
        
        res.json({ 
            success: true, 
            message: 'Velocity configuration reset to defaults!',
            config: defaultConfig
        });
    } catch (err) {
        console.error('Reset Velocity config error:', err);
        res.status(500).json({ error: 'Failed to reset Velocity configuration' });
    }
});
app.post('/servers/:id/delete', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }
        
        if (server.owner_id !== req.session.user.id && req.session.user.role !== 'admin') {
            return res.status(403).json({ error: 'Access denied' });
        }

        // Initialize delete progress
        setDeleteProgress(serverId, 'Initializing...', 0, false, null);
        res.json({ success: true, redirectTo: `/servers/${serverId}/deleting` });

        // Run delete in background
        (async () => {
            try {
                await delay(300);
                // Step 1: Stop server
                setDeleteProgress(serverId, 'Stopping server...', 10, false, null);
                await stopServer(serverId, true);
                await delay(500);

                // Step 2: Delete server files
                setDeleteProgress(serverId, 'Deleting server files...', 30, false, null);
                const serverDir = resolveServerPath(serverId);
                if (fs.existsSync(serverDir)) {
                    fs.rmSync(serverDir, { recursive: true, force: true });
                }
                await delay(500);

                // Step 3: Delete backups
                setDeleteProgress(serverId, 'Deleting backups...', 55, false, null);
                const backupDir = path.join(__panelRoot, 'backups', serverId);
                if (fs.existsSync(backupDir)) {
                    fs.rmSync(backupDir, { recursive: true, force: true });
                }
                await delay(500);

                // Step 4: Remove from database
                setDeleteProgress(serverId, 'Removing from database...', 80, false, null);
                await dbRun('DELETE FROM servers WHERE id = ?', [serverId]);
                await delay(500);

                // Step 5: Clean up
                setDeleteProgress(serverId, 'Cleaning up...', 95, false, null);
                delete serverProcesses[serverId];
                delete serverStartTimes[serverId];
                delete onlinePlayers[serverId];
                delete liveStats[serverId];
                delete installProgress[serverId];
                // Don't delete deleteProgress yet!
                await delay(500);

                setDeleteProgress(serverId, 'Server deleted successfully!', 100, true, null);
            } catch (err) {
                console.error('Delete server error:', err);
                setDeleteProgress(serverId, `Error: ${err.message}`, 0, true, err.message);
            }
        })();
    } catch (err) {
        console.error('Delete server error:', err);
        res.status(500).json({ error: 'Failed to delete server' });
    }
});
app.post('/servers/:id/settings/reinstall', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }
        
        if (server.owner_id !== req.session.user.id && req.session.user.role !== 'admin') {
            return res.status(403).json({ error: 'Access denied' });
        }

        // Initialize reinstall progress
        setReinstallProgress(serverId, 'Initializing...', 0, false, null);
        res.json({ success: true, redirectTo: `/servers/${serverId}/reinstalling` });

        // Run reinstall in background
        (async () => {
            try {
                await delay(300);
                const serverDir = resolveServerPath(serverId);

                // Step 1: Stop server if running
                setReinstallProgress(serverId, 'Stopping server...', 10, false, null);
                if (await isServerRunning(serverId)) {
                    await stopServer(serverId, true);
                }
                await delay(500);

                // Step 2: Backup important files
                setReinstallProgress(serverId, 'Backing up important files...', 25, false, null);
                const backupFiles = ['server.properties', 'ops.json', 'whitelist.json', 'banned-players.json', 'banned-ips.json'];
                const backupData = {};
                backupFiles.forEach(file => {
                    const filePath = path.join(serverDir, file);
                    if (fs.existsSync(filePath)) {
                        backupData[file] = fs.readFileSync(filePath, 'utf8');
                    }
                });
                await delay(500);

                // Ensure server directory exists
                if (!fs.existsSync(serverDir)) {
                    fs.mkdirSync(serverDir, { recursive: true });
                }

                // Step 3: Download server jar
                setReinstallProgress(serverId, 'Downloading server jar...', 45, false, null);
                console.log(`🔄 Reinstalling server ${serverId} with ${server.server_type} ${server.version}...`);
                await downloadServerJar(server.server_type, server.version, serverDir);
                await delay(500);

                // Step 4: Write EULA
                setReinstallProgress(serverId, 'Writing EULA...', 70, false, null);
                const eulaPath = path.join(serverDir, 'eula.txt');
                if (!fs.existsSync(eulaPath)) {
                    fs.writeFileSync(eulaPath, 'eula=true\n', 'utf8');
                }
                await delay(500);

                // Step 5: Configure server properties
                setReinstallProgress(serverId, 'Configuring server properties...', 85, false, null);
                const propertiesPath = path.join(serverDir, 'server.properties');
                const properties = {
                    'server-port': server.port, // Keep existing port
                    'server-ip': server.server_ip || '',
                    'max-players': 20,
                    'online-mode': true,
                    'view-distance': 10,
                    'simulation-distance': 10,
                    'motd': server.name
                };
                writeProperties(properties, propertiesPath);

                // Update configuration files for the server type
                try {
                    await updateServerConfigurationPort(serverId, server.server_type, server.port);
                    console.log(`Updated configuration files for server ${serverId} (${server.server_type}) with existing port ${server.port}`);
                } catch (configErr) {
                    console.error(`Failed to update configuration files for server ${serverId}:`, configErr);
                }

                // Create start script (optional)
                const settings = JSON.parse(server.settings || '{}');
                const xms = Math.max(64, Math.floor(server.ram / 2));
                const startScript = `#!/bin/bash
cd "$(dirname "$0")"
exec ${settings.startup || `java -Xms${xms}M -Xmx${server.ram}M -jar server.jar nogui`}
`;
                fs.writeFileSync(path.join(serverDir, 'start.sh'), startScript, { mode: 0o755 });
                await delay(500);

                // Step 6: Finalize
                setReinstallProgress(serverId, 'Finalizing...', 95, false, null);
                await delay(500);
                setReinstallProgress(serverId, 'Server reinstalled successfully!', 100, true, null);
            } catch (err) {
                console.error('Server reinstall error:', err);
                setReinstallProgress(serverId, `Error: ${err.message}`, 0, true, err.message);
            }
        })();
    } catch (err) {
        console.error('Server reinstall error:', err);
        res.status(500).json({ error: 'Failed to reinstall server: ' + err.message });
    }
});
app.get('/servers/:id/startup', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).send('Access denied');
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        const settings = JSON.parse(server.settings || '{}');
        const startup = settings.startup || `java -Xms${Math.max(64, Math.floor(server.ram / 2))}M -Xmx${server.ram}M -jar server.jar nogui`;
        // Load server.properties
        const serverDir = resolveServerPath(serverId);
        const propertiesPath = path.join(serverDir, 'server.properties');
        let properties = {};
        try {
            if (fs.existsSync(propertiesPath)) {
                const content = fs.readFileSync(propertiesPath, 'utf8');
                properties = parseProperties(content);
            } else {
                properties = {
                    'server-port': server.port,
                    'server-ip': server.server_ip,
                    'max-players': 20,
                    'online-mode': true,
                    'view-distance': 10,
                    'simulation-distance': 10,
                    'motd': server.name
                };
            }
        } catch (err) {
            console.error(`Error reading server.properties for server ${serverId}`, err);
        }
        res.render('servers/startup', await getTemplateVars(req, server, {
            startup, 
            properties, 
            success: req.query.success, 
            error: req.query.error, 
            serverId: server.id, 
            activePage: 'startup',
            title: `${server.name} - Startup`
        }));
    } catch (err) {
        console.error('Startup page error', err);
        res.status(500).send('Internal error');
    }
});
app.post('/servers/:id/startup/update', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { startup, properties } = req.body;
        if (!startup) return res.status(400).json({ error: 'Startup command required' });
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (server.owner_id !== req.session.user.id && req.session.user.role !== 'admin') return res.status(403).json({ error: 'Access denied' });
        let settings = JSON.parse(server.settings || '{}');
        settings.startup = startup;
        // Validate and update server.properties
        if (properties && typeof properties === 'object') {
            const validProperties = {};
            // Common server.properties keys with validation
            const propertyRules = {
                'server-port': { type: 'number', min: 1024, max: 65535, default: server.port },
                'server-ip': { type: 'string', default: server.server_ip },
                'max-players': { type: 'number', min: 1, max: 1000, default: 20 },
                'online-mode': { type: 'boolean', default: true },
                'view-distance': { type: 'number', min: 2, max: 32, default: 10 },
                'simulation-distance': { type: 'number', min: 2, max: 32, default: 10 },
                'motd': { type: 'string', maxLength: 256, default: server.name },
                'difficulty': { type: 'string', options: ['peaceful', 'easy', 'normal', 'hard'], default: 'normal' },
                'gamemode': { type: 'string', options: ['survival', 'creative', 'adventure', 'spectator'], default: 'survival' },
                'pvp': { type: 'boolean', default: true },
                'level-type': { type: 'string', default: 'minecraft:normal' },
                'spawn-protection': { type: 'number', min: 0, default: 0 }
            };
            Object.keys(propertyRules).forEach(key => {
                if (properties[key] !== undefined) {
                    const rule = propertyRules[key];
                    let value = properties[key];
                    if (rule.type === 'number') {
                        value = parseInt(value, 10);
                        if (isNaN(value) || (rule.min && value < rule.min) || (rule.max && value > rule.max)) {
                            value = rule.default;
                        }
                    } else if (rule.type === 'boolean') {
                        value = value === 'true' || value === true;
                    } else if (rule.type === 'string') {
                        value = String(value).trim();
                        if (rule.maxLength && value.length > rule.maxLength) {
                            value = value.substring(0, rule.maxLength);
                        }
                        if (rule.options && !rule.options.includes(value)) {
                            value = rule.default;
                        }
                    }
                    validProperties[key] = value;
                } else {
                    validProperties[key] = propertyRules[key].default;
                }
            });
            // Convert properties object to string
            const propertiesContent = Object.entries(validProperties)
                .map(([key, value]) => `${key}=${value}`)
                .join('\n');
            // Save to server.properties
            const serverDir = resolveServerPath(serverId);
            fs.writeFileSync(path.join(serverDir, 'server.properties'), propertiesContent, 'utf8');
            // Store in settings for reinstall
            settings.properties = propertiesContent;
        }
        await dbRun('UPDATE servers SET settings = ? WHERE id = ?', [JSON.stringify(settings), serverId]);
        // Update start.sh
        const serverDir = resolveServerPath(serverId);
        fs.writeFileSync(path.join(serverDir, 'start.sh'), `#!/bin/bash\ncd "$(dirname "$0")"\nexec ${startup}\n`, { mode: 0o755 });
        res.redirect(`/servers/${serverId}/startup?success=Startup and server properties updated`);
    } catch (err) {
        console.error('Update startup error', err);
        res.redirect(`/servers/${serverId}/startup?error=Failed to update startup or server properties`);
    }
});
app.post('/servers/:id/backups/create', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const { name, description } = req.body;
        const backupName = name || `Backup ${new Date().toLocaleString()}`;
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ error: 'Server not found' });
        
        const serverDir = resolveServerPath(serverId);
        // NEW: Use backups/:id/ directory in panel root
        const backupDir = path.join(__panelRoot, 'backups', serverId.toString());
        fs.mkdirSync(backupDir, { recursive: true });
        const fileName = `backup-${Date.now()}.zip`;
        const filePath = path.join(backupDir, fileName);
        
        let wasRunning = false;
        let responseSent = false;
        
        // Check if server is running
        if (server.status === 'running') {
            wasRunning = true;
            console.log(`Stopping server ${serverId} for backup...`);
            
            // Stop the server
            await stopServer(serverId);
            
            // Wait for server to fully stop
            await new Promise(resolve => setTimeout(resolve, 3000));
        }
        
        // Create backup
        const output = fs.createWriteStream(filePath);
        const archive = archiver('zip', { zlib: { level: 9 } });
        
        output.on('close', async () => {
            if (responseSent) return;
            responseSent = true;
            
            try {
                // Get file size
                const stats = fs.statSync(filePath);
                const sizeInBytes = stats.size;
                const sizeInMB = (sizeInBytes / (1024 * 1024)).toFixed(2);
                const sizeInGB = (sizeInBytes / (1024 * 1024 * 1024)).toFixed(2);
                const sizeStr = sizeInGB >= 1 ? `${sizeInGB} GB` : `${sizeInMB} MB`;
                
                await dbRun('INSERT INTO backups (server_id, file, name, description, size, created_at) VALUES (?, ?, ?, ?, ?, ?)', [
                    serverId, fileName, backupName, description || null, sizeStr, new Date().toISOString()
                ]);
                
                // Restart server if it was running
                if (wasRunning) {
                    console.log(`Restarting server ${serverId} after backup...`);
                    setTimeout(async () => {
                        try {
                            await startServer(serverId);
                        } catch (err) {
                            console.error(`Failed to restart server ${serverId}:`, err);
                        }
                    }, 1000);
                }
                
                res.json({ 
                    success: true, 
                    message: wasRunning ? 'Backup created (server restarted)' : 'Backup created', 
                    file: fileName,
                    size: sizeStr
                });
            } catch (err) {
                console.error('Backup DB insert error:', err);
                res.status(500).json({ error: 'Failed to save backup record' });
            }
        });
        
        archive.on('error', async (err) => {
            if (responseSent) return;
            responseSent = true;
            console.error('Archive error:', err);
            
            // Restart server if it was running
            if (wasRunning) {
                console.log(`Restarting server ${serverId} after backup error...`);
                try {
                    await startServer(serverId);
                } catch (restartErr) {
                    console.error(`Failed to restart server ${serverId}:`, restartErr);
                }
            }
            
            res.status(500).json({ error: 'Failed to create backup: ' + err.message });
        });
        
        archive.pipe(output);
        // Exclude the backups directory from being backed up
        archive.glob('**/*', { cwd: serverDir, ignore: ['*.pid', '*.lock', 'logs/latest.log'] });
        archive.finalize();
        
    } catch (err) {
        console.error('Backup create error', err);
        if (!res.headersSent) {
            res.status(500).json({ error: 'Failed to create backup' });
        }
    }
});
app.get('/servers/:id/backups', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).send('Access denied');
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        const backups = await dbAll('SELECT * FROM backups WHERE server_id = ? ORDER BY created_at DESC', [serverId]);
        res.render('servers/backups', await getTemplateVars(req, server, {
            backups, 
            serverId: server.id, 
            activePage: 'backups',
            title: `${server.name} - Backups`
        }));
    } catch (err) {
        console.error('Backups page error', err);
        res.status(500).send('Internal error');
    }
});
app.get('/servers/:id/backups/download/:filename', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).send('Access denied');
        
        const filename = req.params.filename;
        // NEW: Use backups/:id/ directory
        const filePath = path.join(__panelRoot, 'backups', serverId.toString(), filename);
        
        if (!fs.existsSync(filePath)) {
            return res.status(404).send('Backup file not found');
        }
        
        res.download(filePath, filename);
    } catch (err) {
        console.error('Download backup error:', err);
        res.status(500).send('Download failed');
    }
});
app.post('/servers/:id/backups/delete', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const { backupId } = req.body;
        if (!backupId) return res.status(400).json({ error: 'Backup ID required' });
        
        const backup = await dbGet('SELECT * FROM backups WHERE id = ? AND server_id = ?', [backupId, serverId]);
        if (!backup) return res.status(404).json({ error: 'Backup not found' });
        
        // NEW: Use backups/:id/ directory
        const filePath = path.join(__panelRoot, 'backups', serverId.toString(), backup.file);
        
        // Delete file with retry logic to handle EBUSY errors
        if (fs.existsSync(filePath)) {
            let retries = 5;
            let deleted = false;
            
            while (retries > 0 && !deleted) {
                try {
                    // Force garbage collection to release any file handles
                    if (global.gc) {
                        global.gc();
                    }
                    
                    // Try to delete the file
                    await fs.promises.unlink(filePath);
                    deleted = true;
                    console.log(`Successfully deleted backup file: ${backup.file}`);
                    
                } catch (unlinkErr) {
                    retries--;
                    
                    if (unlinkErr.code === 'EBUSY' || unlinkErr.code === 'EPERM') {
                        if (retries > 0) {
                            console.log(`File is busy, retrying... (${retries} attempts left)`);
                            // Wait before retrying (exponential backoff)
                            await new Promise(resolve => setTimeout(resolve, 1000 * (6 - retries)));
                        } else {
                            // If all retries failed, try using rmSync with force option
                            console.log('All retries failed, trying rmSync with force...');
                            try {
                                fs.rmSync(filePath, { force: true, maxRetries: 3, retryDelay: 1000 });
                                deleted = true;
                                console.log(`Successfully deleted backup file using rmSync: ${backup.file}`);
                            } catch (rmErr) {
                                console.error('rmSync also failed:', rmErr);
                                throw new Error(`File is locked and cannot be deleted. Please close any programs that might be using this file and try again. (${unlinkErr.code})`);
                            }
                        }
                    } else {
                        // Different error, throw immediately
                        throw unlinkErr;
                    }
                }
            }
        }
        
        // Delete from database
        await dbRun('DELETE FROM backups WHERE id = ?', [backupId]);
        res.json({ success: true, message: 'Backup deleted successfully' });
        
    } catch (err) {
        console.error('Delete backup error', err);
        res.status(500).json({ error: 'Failed to delete backup: ' + err.message });
    }
});

app.post('/servers/:id/backups/validate', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const { backupId } = req.body;
        if (!backupId) return res.status(400).json({ error: 'Backup ID required' });
        
        const backup = await dbGet('SELECT * FROM backups WHERE id = ? AND server_id = ?', [backupId, serverId]);
        if (!backup) return res.status(404).json({ error: 'Backup not found' });
        
        const backupFile = path.join(__panelRoot, 'backups', serverId.toString(), backup.file);
        
        // Check if file exists
        if (!fs.existsSync(backupFile)) {
            return res.json({ 
                valid: false, 
                error: 'Backup file not found on disk',
                canRestore: false
            });
        }
        
        // Check file size
        const stats = fs.statSync(backupFile);
        if (stats.size === 0) {
            return res.json({ 
                valid: false, 
                error: 'Backup file is empty',
                canRestore: false
            });
        }
        
        // Try to open and validate the zip file
        try {
            const directory = await unzipper.Open.file(backupFile);
            if (!directory || !directory.files || directory.files.length === 0) {
                return res.json({ 
                    valid: false, 
                    error: 'Backup file contains no files',
                    canRestore: false
                });
            }
            
            const fileCount = directory.files.length;
            
            // Force close the directory handle by setting to null and triggering GC
            directory.close && directory.close();
            
            // Small delay to ensure file handle is released
            await new Promise(resolve => setTimeout(resolve, 100));
            
            return res.json({ 
                valid: true, 
                fileCount: fileCount,
                size: backup.size,
                canRestore: true,
                message: `Backup is valid and contains ${fileCount} files`
            });
            
        } catch (zipErr) {
            console.error('Zip validation error:', zipErr);
            return res.json({ 
                valid: false, 
                error: `Backup file is corrupted: ${zipErr.message}`,
                canRestore: false
            });
        }
        
    } catch (err) {
        console.error('Validate backup error:', err);
        res.status(500).json({ error: 'Failed to validate backup: ' + err.message });
    }
});
app.post('/servers/:id/backups/restore', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const { backupId } = req.body;
        if (!backupId) return res.status(400).json({ error: 'Backup ID required' });
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        const backup = await dbGet('SELECT * FROM backups WHERE id = ? AND server_id = ?', [backupId, serverId]);
        if (!backup) return res.status(404).json({ error: 'Backup not found' });
        
        const serverDir = resolveServerPath(serverId);
        const backupFile = path.join(__panelRoot, 'backups', serverId.toString(), backup.file);
        
        // Check if backup file exists
        if (!fs.existsSync(backupFile)) {
            return res.status(404).json({ error: 'Backup file not found on disk' });
        }
        
        // Check if backup file is valid
        const stats = fs.statSync(backupFile);
        if (stats.size === 0) {
            return res.status(400).json({ error: 'Backup file is empty or corrupted' });
        }
        
        console.log(`Restoring backup ${backup.file} (${backup.size}) for server ${serverId}...`);
        
        // Stop server if running
        let wasRunning = false;
        if (server.status === 'running') {
            wasRunning = true;
            console.log(`Stopping server ${serverId} for restore...`);
            await stopServer(serverId);
            await new Promise(resolve => setTimeout(resolve, 3000));
        }
        
        // Create a temporary directory for extraction
        const tempDir = path.join(__panelRoot, 'temp', `restore-${serverId}-${Date.now()}`);
        fs.mkdirSync(tempDir, { recursive: true });
        
        try {
            // Extract using unzipper.Open.file() which works better for large files
            console.log(`Opening backup file...`);
            const directory = await unzipper.Open.file(backupFile);
            
            if (!directory || !directory.files || directory.files.length === 0) {
                throw new Error('Backup file is empty or invalid');
            }
            
            console.log(`Backup contains ${directory.files.length} files`);
            console.log(`Extracting backup to temp directory...`);
            
            // Extract to temp directory
            await directory.extract({ path: tempDir });
            
            // Close the directory handle explicitly
            directory.close && directory.close();
            
            // Give it a moment to finish writing and release file handles
            await new Promise(resolve => setTimeout(resolve, 1500));
            
            console.log('Extraction completed successfully');
            
            // Verify extraction
            console.log(`Verifying extraction...`);
            if (!fs.existsSync(tempDir)) {
                throw new Error('Extraction failed - temp directory does not exist');
            }
            
            const extractedFiles = fs.readdirSync(tempDir);
            if (extractedFiles.length === 0) {
                throw new Error('Extraction failed - no files were extracted');
            }
            
            console.log(`Successfully extracted ${extractedFiles.length} items`);
            
            console.log(`Removing old server files...`);
            // Remove all files in server directory (with retry logic)
            let retries = 3;
            while (retries > 0) {
                try {
                    if (fs.existsSync(serverDir)) {
                        const files = fs.readdirSync(serverDir);
                        for (const file of files) {
                            const filePath = path.join(serverDir, file);
                            try {
                                fs.rmSync(filePath, { recursive: true, force: true, maxRetries: 3, retryDelay: 100 });
                            } catch (err) {
                                console.warn(`Failed to delete ${file}:`, err.message);
                            }
                        }
                    }
                    break;
                } catch (err) {
                    retries--;
                    if (retries === 0) throw err;
                    await new Promise(resolve => setTimeout(resolve, 1000));
                }
            }
            
            console.log(`Moving extracted files to server directory...`);
            // Ensure server directory exists
            fs.mkdirSync(serverDir, { recursive: true });
            
            // Move files from temp to server directory
            for (const file of extractedFiles) {
                const srcPath = path.join(tempDir, file);
                const destPath = path.join(serverDir, file);
                
                try {
                    // Copy instead of rename to avoid cross-device issues
                    if (fs.statSync(srcPath).isDirectory()) {
                        fs.cpSync(srcPath, destPath, { recursive: true });
                    } else {
                        fs.copyFileSync(srcPath, destPath);
                    }
                    console.log(`Copied: ${file}`);
                } catch (copyErr) {
                    console.error(`Failed to copy ${file}:`, copyErr);
                    throw copyErr;
                }
            }
            
            // Clean up temp directory
            console.log(`Cleaning up temp directory...`);
            try {
                fs.rmSync(tempDir, { recursive: true, force: true });
            } catch (cleanErr) {
                console.warn('Failed to clean temp directory:', cleanErr.message);
            }
            
            // Update server status
            await dbRun('UPDATE servers SET status = ? WHERE id = ?', ['stopped', serverId]);
            
            console.log(`Backup restored successfully for server ${serverId}`);
            
            res.json({ 
                success: true, 
                message: wasRunning ? 'Backup restored successfully. Please start the server manually.' : 'Backup restored successfully',
                wasRunning
            });
            
        } catch (extractErr) {
            // Clean up temp directory on error
            if (fs.existsSync(tempDir)) {
                try {
                    fs.rmSync(tempDir, { recursive: true, force: true });
                } catch (cleanErr) {
                    console.warn('Failed to clean temp directory after error:', cleanErr.message);
                }
            }
            throw extractErr;
        }
        
    } catch (err) {
        console.error('Restore backup error:', err);
        res.status(500).json({ 
            error: 'Failed to restore backup: ' + err.message,
            details: err.code || 'Unknown error'
        });
    }
});
app.get('/servers/:id/plugins/marketplace', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).send('Access denied');
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        const query = req.query.q || '';
        const page = parseInt(req.query.page) || 1;
        const provider = req.query.provider || 'all';
        const limit = 16;
        const { plugins, totalHits } = await searchPlugins(query, page, limit, provider);
        res.render('servers/plugins_marketplace', await getTemplateVars(req, server, {
            serverId,
            plugins,
            query,
            page,
            provider,
            hasMore: page * limit < totalHits,
            success: req.query.success,
            currentPage: 'plugins',
            activePage: 'plugins',
            error: req.query.error,
            title: `${server.name} - Plugin Marketplace`
        }));
    } catch (err) {
        console.error('Marketplace error', err);
        res.status(500).send('Error loading marketplace');
    }
});

// API endpoint to get plugin versions
app.get('/servers/:id/plugins/marketplace/versions', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const { source, projectId, resourceId } = req.query;
        let versions = [];
        
        if (source === 'modrinth' && projectId) {
            versions = await getModrinthVersions(projectId);
        } else if (source === 'spiget' && resourceId) {
            versions = await getSpigetVersions(resourceId);
        } else if (source === 'hangar' && projectId) {
            versions = await getHangarVersions(projectId);
        } else if (source === 'bukkit' && projectId) {
            versions = await getBukkitVersions(projectId);
        }
        
        res.json({ versions });
    } catch (err) {
        console.error('Versions fetch error:', err);
        res.status(500).json({ error: 'Failed to fetch versions' });
    }
});
app.post('/servers/:id/plugins/marketplace/install', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const { pluginName, source, projectId, resourceId, versionId, fileId } = req.body;
        
        if (!pluginName || !source) {
            return res.status(400).json({ error: 'Missing plugin information' });
        }
        
        console.log(`Installing plugin: ${pluginName} from ${source}${versionId ? ` (version: ${versionId})` : ''}`);
        console.log(`Project ID: ${projectId}, Resource ID: ${resourceId}`);
        
        // Get download URL based on source
        let downloadInfo = null;
        
        try {
            if (source === 'modrinth' && projectId) {
                downloadInfo = await getModrinthDownloadUrl(projectId, versionId);
            } else if (source === 'spiget' && resourceId) {
                downloadInfo = await getSpigetDownloadUrl(resourceId, versionId);
            } else if (source === 'hangar' && projectId) {
                downloadInfo = await getHangarDownloadUrl(projectId, versionId);
            } else if (source === 'bukkit' && projectId) {
                downloadInfo = await getBukkitDownloadUrl(projectId, fileId);
            } else {
                return res.status(400).json({ error: 'Invalid source or missing identifiers' });
            }
        } catch (err) {
            console.error('Error fetching download URL:', err);
            return res.status(500).json({ error: `Failed to get download URL: ${err.message}` });
        }
        
        if (!downloadInfo) {
            return res.status(400).json({ error: 'Could not retrieve download information from provider' });
        }
        
        if (!downloadInfo.url) {
            return res.status(400).json({ error: 'Download URL not available for this plugin' });
        }
        
        console.log(`Download URL: ${downloadInfo.url}`);
        console.log(`Filename: ${downloadInfo.filename}`);
        
        // Prepare destination path
        const pluginsDir = resolveServerPath(serverId, 'plugins');
        if (!fs.existsSync(pluginsDir)) {
            fs.mkdirSync(pluginsDir, { recursive: true });
        }
        
        const sanitizedName = downloadInfo.filename || (sanitize(pluginName) + '.jar');
        const destPath = path.join(pluginsDir, sanitizedName);
        
        // Check if plugin already exists
        if (fs.existsSync(destPath)) {
            return res.status(400).json({ error: 'Plugin already installed. Delete the old version first.' });
        }
        
        // Download the plugin
        try {
            await downloadPluginJar(downloadInfo.url, destPath);
        } catch (downloadErr) {
            console.error('Download failed:', downloadErr);
            return res.status(500).json({ error: `Download failed: ${downloadErr.message}` });
        }
        
        console.log(`Plugin installed successfully: ${sanitizedName}`);
        return res.json({ 
            success: true, 
            message: `${pluginName} installed successfully!`,
            filename: sanitizedName,
            version: downloadInfo.version
        });
        
    } catch (err) {
        console.error('Plugin install error:', err);
        return res.status(500).json({ error: err.message || 'Failed to install plugin' });
    }
});
app.post('/servers/:id/plugins/delete', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const { filename } = req.body;
        if (!filename) {
            return res.status(400).json({ error: 'Invalid plugin filename' });
        }
        
        // Check if server is running
        const running = await isServerRunning(serverId);
        if (running) {
            return res.status(400).json({ 
                error: 'Cannot delete plugins while server is running. Please stop the server first.' 
            });
        }
        
        const sanitizedName = sanitize(filename);
        const pluginsDir = resolveServerPath(serverId, 'plugins');
        const pluginPath = path.join(pluginsDir, sanitizedName);
        
        if (!fs.existsSync(pluginPath)) {
            return res.status(404).json({ error: 'Plugin not found' });
        }
        
        // Try to delete with retry logic for Windows file locking
        let attempts = 0;
        const maxAttempts = 3;
        let lastError = null;
        
        while (attempts < maxAttempts) {
            try {
                // Check if it's a directory or file
                const stats = fs.statSync(pluginPath);
                if (stats.isDirectory()) {
                    fs.rmSync(pluginPath, { recursive: true, force: true });
                } else {
                    fs.unlinkSync(pluginPath);
                }
                
                return res.json({ success: true, message: 'Plugin deleted successfully' });
            } catch (err) {
                lastError = err;
                
                // If EBUSY error (file locked), wait and retry
                if (err.code === 'EBUSY' || err.code === 'EPERM') {
                    attempts++;
                    if (attempts < maxAttempts) {
                        await new Promise(resolve => setTimeout(resolve, 500)); // Wait 500ms
                        continue;
                    }
                } else {
                    // Other errors, don't retry
                    throw err;
                }
            }
        }
        
        // If we get here, all retries failed
        if (lastError && (lastError.code === 'EBUSY' || lastError.code === 'EPERM')) {
            return res.status(400).json({ 
                error: 'Plugin files are locked. The server may still be running or shutting down. Please wait a moment and try again.' 
            });
        }
        
        throw lastError;
        
    } catch (err) {
        console.error('Plugin delete error:', err.message);
        return res.status(500).json({ 
            error: err.code === 'EBUSY' || err.code === 'EPERM' 
                ? 'Plugin is locked. Stop the server and try again.' 
                : 'Failed to delete plugin' 
        });
    }
});

app.post('/servers/:id/plugins/upload', requireAuth, upload.single('plugin'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) {
            return res.status(403).json({ error: 'Access denied' });
        }
        
        if (!req.file) {
            return res.status(400).json({ error: 'No file uploaded' });
        }
        
        // Validate file is a JAR
        if (!req.file.originalname.endsWith('.jar')) {
            // Delete uploaded file
            fs.unlinkSync(req.file.path);
            return res.status(400).json({ error: 'Only .jar files are allowed' });
        }
        
        const pluginsDir = resolveServerPath(serverId, 'plugins');
        if (!fs.existsSync(pluginsDir)) {
            fs.mkdirSync(pluginsDir, { recursive: true });
        }
        
        const sanitizedName = sanitize(req.file.originalname);
        const destPath = path.join(pluginsDir, sanitizedName);
        
        // Check if plugin already exists
        if (fs.existsSync(destPath)) {
            fs.unlinkSync(req.file.path);
            return res.status(400).json({ error: 'Plugin already exists. Delete the old version first.' });
        }
        
        // Move file to plugins directory
        fs.renameSync(req.file.path, destPath);
        
        console.log(`Plugin uploaded: ${sanitizedName}`);
        return res.json({ 
            success: true, 
            message: 'Plugin uploaded successfully',
            filename: sanitizedName
        });
        
    } catch (err) {
        console.error('Plugin upload error:', err);
        
        // Clean up uploaded file on error
        if (req.file && fs.existsSync(req.file.path)) {
            try {
                fs.unlinkSync(req.file.path);
            } catch (cleanupErr) {
                console.error('Cleanup error:', cleanupErr);
            }
        }
        
        return res.status(500).json({ error: err.message || 'Failed to upload plugin' });
    }
});

app.get('/servers/:id/plugins', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) {
            return res.status(403).send('Access denied');
        }
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).send('Server not found');
        
        const pluginsDir = resolveServerPath(serverId, 'plugins');
        let plugins = [];
        
        if (fs.existsSync(pluginsDir)) {
            const files = fs.readdirSync(pluginsDir);
            
            for (const file of files) {
                const fullPath = path.join(pluginsDir, file);
                const stat = fs.statSync(fullPath);
                
                // Only include .jar files, skip directories
                if (!stat.isDirectory() && file.endsWith('.jar')) {
                    const pluginInfo = await extractPluginInfo(fullPath, file);
                    plugins.push({
                        name: pluginInfo.name || file.replace('.jar', ''),
                        filename: file,
                        version: pluginInfo.version || 'Unknown',
                        description: pluginInfo.description || null,
                        author: pluginInfo.author || null,
                        website: pluginInfo.website || null,
                        size: stat.size,
                        formattedSize: formatFileSize(stat.size),
                        enabled: !file.endsWith('.disabled.jar'),
                        isDirectory: false
                    });
                }
            }
            
            // Sort plugins alphabetically
            plugins.sort((a, b) => a.name.localeCompare(b.name));
        }
        
        res.render('servers/plugins', await getTemplateVars(req, server, {
            plugins,
            success: req.query.success,
            error: req.query.error,
            activePage: 'plugins',
            currentPage: 'server',
            title: `${server.name} - Plugins`
        }));
    } catch (err) {
        console.error('Plugins page error:', err);
        res.status(500).send('Error loading plugins');
    }
});
app.get('/servers/:id/players', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).send('Access denied');
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).send('Server not found');
        const ops = readPlayerFile(serverId, 'ops.json');
        const whitelist = readPlayerFile(serverId, 'whitelist.json');
        const bannedPlayers = readPlayerFile(serverId, 'banned-players.json');
        const bannedIps = readPlayerFile(serverId, 'banned-ips.json');
        const propertiesPath = resolveServerPath(serverId, 'server.properties');
        let whitelistEnabled = false;
        if (fs.existsSync(propertiesPath)) {
            const content = fs.readFileSync(propertiesPath, 'utf8');
            const match = content.match(/^white-list=(true|false)$/m);
            if (match) whitelistEnabled = match[1] === 'true';
        }
        const online = getOnlinePlayers(serverId);
        res.render('servers/players', await getTemplateVars(req, server, {
            ops: ops || [],
            whitelist: whitelist || [],
            banned: bannedPlayers || [],
            bannedPlayers: bannedPlayers || [],
            bannedIps: bannedIps || [],
            whitelistEnabled,
            online: online || [],
            currentPage: 'players',
            success: req.query.success,
            serverId: server.id,
            activePage: 'players',
            error: req.query.error,
            query: req.query,
            title: `${server.name} - Players`
        }));
    } catch (err) {
        console.error(`Players page error for server ${req.params.id}:`, err);
        res.status(500).send('Server error');
    }
});
app.get('/servers/:id/players/online', requireAuth, async (req, res) => {
    const serverId = req.params.id;
    if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
    res.json(getOnlinePlayers(serverId));
});
app.post('/servers/:id/players/online/refresh', requireAuth, async (req, res) => {
    const serverId = req.params.id;
    if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
    
    // Query online players by sending /list command
    const success = await queryOnlinePlayers(serverId);
    
    if (success) {
        res.sendStatus(200);
    } else {
        res.status(400).json({ error: 'Server is offline' });
    }
});
app.post('/servers/:id/players/whitelist/toggle', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { enabled } = req.body;
        const isEnabled = enabled === 'true' || enabled === true;
        const propertiesPath = resolveServerPath(serverId, 'server.properties');
        let properties = {};
        if (fs.existsSync(propertiesPath)) {
            properties = parseProperties(fs.readFileSync(propertiesPath, 'utf8'));
        }
        properties['white-list'] = isEnabled;
        writeProperties(properties, propertiesPath);
        executeCommand(serverId, `/whitelist ${isEnabled ? 'on' : 'off'}`);
        res.redirect(`/servers/${serverId}/players?success=Whitelist ${isEnabled ? 'enabled' : 'disabled'}`);
    } catch (err) {
        console.error(`Toggle whitelist error for server ${serverId}`, err);
        res.redirect(`/servers/${serverId}/players?error=Failed to toggle whitelist`);
    }
});
app.post('/servers/:id/players/op/add', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { name, level = 4 } = req.body;
        if (!name) return res.status(400).json({ error: 'Name required' });
        
        console.log(`Adding OP: ${name} to server ${serverId}`);
        
        // Try to send command to running server
        const commandSent = await sendCommand(serverId, `op ${name}`);
        
        if (!commandSent) {
            // Server not running or command failed, update file directly
            let ops = readPlayerFile(serverId, 'ops.json');
            if (ops.find(o => o.name.toLowerCase() === name.toLowerCase())) {
                return res.status(400).json({ error: 'Player already OP' });
            }
            
            // Try to get UUID (optional, will work without it)
            let uuid = null;
            try {
                uuid = await getUUID(name);
            } catch (err) {
                console.log('Could not fetch UUID, using placeholder');
                uuid = '00000000-0000-0000-0000-000000000000';
            }
            
            ops.push({ 
                uuid: uuid, 
                name: name, 
                level: parseInt(level) || 4, 
                bypassesPlayerLimit: false 
            });
            writePlayerFile(serverId, 'ops.json', ops);
        }
        
        return res.json({ success: true, message: 'Operator added successfully' });
    } catch (err) {
        console.error(`Add OP error for server ${serverId}:`, err);
        return res.status(500).json({ error: 'Failed to add OP' });
    }
});

app.post('/servers/:id/players/op/remove', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { name } = req.body;
        if (!name) return res.status(400).json({ error: 'Name required' });
        
        console.log(`Removing OP: ${name} from server ${serverId}`);
        
        // Try to send command to running server
        const commandSent = await sendCommand(serverId, `deop ${name}`);
        
        if (!commandSent) {
            // Server not running or command failed, update file directly
            let ops = readPlayerFile(serverId, 'ops.json');
            ops = ops.filter(o => o.name.toLowerCase() !== name.toLowerCase());
            writePlayerFile(serverId, 'ops.json', ops);
        }
        
        return res.json({ success: true, message: 'Operator removed successfully' });
    } catch (err) {
        console.error(`Remove OP error for server ${serverId}:`, err);
        return res.status(500).json({ error: 'Failed to remove OP' });
    }
});

app.post('/servers/:id/players/whitelist/add', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { name } = req.body;
        if (!name) return res.status(400).json({ error: 'Name required' });
        
        console.log(`Adding to whitelist: ${name} on server ${serverId}`);
        
        // Try to send command to running server
        const commandSent = await sendCommand(serverId, `whitelist add ${name}`);
        
        if (!commandSent) {
            // Server not running or command failed, update file directly
            let whitelist = readPlayerFile(serverId, 'whitelist.json');
            if (whitelist.find(w => w.name.toLowerCase() === name.toLowerCase())) {
                return res.status(400).json({ error: 'Player already whitelisted' });
            }
            
            // Try to get UUID (optional)
            let uuid = null;
            try {
                uuid = await getUUID(name);
            } catch (err) {
                console.log('Could not fetch UUID, using placeholder');
                uuid = '00000000-0000-0000-0000-000000000000';
            }
            
            whitelist.push({ uuid: uuid, name: name });
            writePlayerFile(serverId, 'whitelist.json', whitelist);
        }
        
        return res.json({ success: true, message: 'Player added to whitelist' });
    } catch (err) {
        console.error(`Add whitelist error for server ${serverId}:`, err);
        return res.status(500).json({ error: 'Failed to add to whitelist' });
    }
});

app.post('/servers/:id/players/whitelist/remove', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { name } = req.body;
        if (!name) return res.status(400).json({ error: 'Name required' });
        
        console.log(`Removing from whitelist: ${name} on server ${serverId}`);
        
        // Try to send command to running server
        const commandSent = await sendCommand(serverId, `whitelist remove ${name}`);
        
        if (!commandSent) {
            // Server not running or command failed, update file directly
            let whitelist = readPlayerFile(serverId, 'whitelist.json');
            whitelist = whitelist.filter(w => w.name.toLowerCase() !== name.toLowerCase());
            writePlayerFile(serverId, 'whitelist.json', whitelist);
        }
        
        return res.json({ success: true, message: 'Player removed from whitelist' });
    } catch (err) {
        console.error(`Remove whitelist error for server ${serverId}:`, err);
        return res.status(500).json({ error: 'Failed to remove from whitelist' });
    }
});

app.post('/servers/:id/players/ban/add', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { name, reason = 'Banned by an operator' } = req.body;
        if (!name) return res.status(400).json({ error: 'Name required' });
        
        console.log(`Banning player: ${name} on server ${serverId}`);
        
        // Try to send command to running server
        const commandSent = await sendCommand(serverId, `ban ${name} ${reason}`);
        
        if (!commandSent) {
            // Server not running or command failed, update file directly
            let banned = readPlayerFile(serverId, 'banned-players.json');
            if (banned.find(b => b.name.toLowerCase() === name.toLowerCase())) {
                return res.status(400).json({ error: 'Player already banned' });
            }
            
            // Try to get UUID (optional)
            let uuid = null;
            try {
                uuid = await getUUID(name);
            } catch (err) {
                console.log('Could not fetch UUID, using placeholder');
                uuid = '00000000-0000-0000-0000-000000000000';
            }
            
            banned.push({
                uuid: uuid,
                name: name,
                created: new Date().toISOString(),
                source: 'Panel',
                expires: 'forever',
                reason: reason
            });
            writePlayerFile(serverId, 'banned-players.json', banned);
        }
        
        return res.json({ success: true, message: 'Player banned successfully' });
    } catch (err) {
        console.error(`Ban player error for server ${serverId}:`, err);
        return res.status(500).json({ error: 'Failed to ban player' });
    }
});

app.post('/servers/:id/players/ban/remove', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { name } = req.body;
        if (!name) return res.status(400).json({ error: 'Name required' });
        
        console.log(`Unbanning player: ${name} on server ${serverId}`);
        
        // Try to send command to running server
        const commandSent = await sendCommand(serverId, `pardon ${name}`);
        
        if (!commandSent) {
            // Server not running or command failed, update file directly
            let banned = readPlayerFile(serverId, 'banned-players.json');
            banned = banned.filter(b => b.name.toLowerCase() !== name.toLowerCase());
            writePlayerFile(serverId, 'banned-players.json', banned);
        }
        
        return res.json({ success: true, message: 'Player unbanned successfully' });
    } catch (err) {
        console.error(`Unban player error for server ${serverId}:`, err);
        return res.status(500).json({ error: 'Failed to unban player' });
    }
});

app.post('/servers/:id/players/ban-ip/add', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { ip, reason = 'Banned by an operator' } = req.body;
        if (!ip) return res.status(400).json({ error: 'IP required' });
        if (!/^((\d{1,3}\.){3}\d{1,3})$/.test(ip)) {
            return res.status(400).json({ error: 'Invalid IP address' });
        }
        
        console.log(`Banning IP: ${ip} on server ${serverId}`);
        
        // Try to send command to running server
        const commandSent = await sendCommand(serverId, `ban-ip ${ip} ${reason}`);
        
        if (!commandSent) {
            // Server not running or command failed, update file directly
            let bannedIps = readPlayerFile(serverId, 'banned-ips.json');
            if (bannedIps.find(b => b.ip === ip)) {
                return res.status(400).json({ error: 'IP already banned' });
            }
            
            bannedIps.push({
                ip: ip,
                created: new Date().toISOString(),
                source: 'Panel',
                expires: 'forever',
                reason: reason
            });
            writePlayerFile(serverId, 'banned-ips.json', bannedIps);
        }
        
        return res.json({ success: true, message: 'IP banned successfully' });
    } catch (err) {
        console.error(`Ban IP error for server ${serverId}:`, err);
        return res.status(500).json({ error: 'Failed to ban IP' });
    }
});

app.post('/servers/:id/players/ban-ip/remove', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { ip } = req.body;
        if (!ip) return res.status(400).json({ error: 'IP required' });
        
        console.log(`Unbanning IP: ${ip} on server ${serverId}`);
        
        // Try to send command to running server
        const commandSent = await sendCommand(serverId, `pardon-ip ${ip}`);
        
        if (!commandSent) {
            // Server not running or command failed, update file directly
            let bannedIps = readPlayerFile(serverId, 'banned-ips.json');
            bannedIps = bannedIps.filter(b => b.ip !== ip);
            writePlayerFile(serverId, 'banned-ips.json', bannedIps);
        }
        
        return res.json({ success: true, message: 'IP unbanned successfully' });
    } catch (err) {
        console.error(`Unban IP error for server ${serverId}:`, err);
        return res.status(500).json({ error: 'Failed to unban IP' });
    }
});

// Kick player
app.post('/servers/:id/players/kick', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { name, reason = 'Kicked by an operator' } = req.body;
        if (!name) return res.status(400).json({ error: 'Name required' });
        
        console.log(`Kicking player: ${name} from server ${serverId}`);
        
        // Send kick command to running server
        const commandSent = await sendCommand(serverId, `kick ${name} ${reason}`);
        
        if (!commandSent) {
            return res.status(400).json({ error: 'Server is not running or player is not online' });
        }
        
        return res.json({ success: true, message: 'Player kicked successfully' });
    } catch (err) {
        console.error(`Kick player error for server ${serverId}:`, err);
        return res.status(500).json({ error: 'Failed to kick player' });
    }
});

// Get all players (combined list)
app.get('/servers/:id/players/all', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const ops = readPlayerFile(serverId, 'ops.json') || [];
        const whitelist = readPlayerFile(serverId, 'whitelist.json') || [];
        const banned = readPlayerFile(serverId, 'banned-players.json') || [];
        const online = getOnlinePlayers(serverId) || [];
        
        return res.json({
            success: true,
            online,
            ops,
            whitelist,
            banned
        });
    } catch (err) {
        console.error('Get all players error:', err);
        return res.status(500).json({ error: 'Failed to get players' });
    }
});
app.get('/servers/:id/worlds', requireAuth, async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).send('Access denied');
    try {
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      const serverDir = resolveServerPath(serverId);
      const files = fs.readdirSync(serverDir, { withFileTypes: true });
      const worlds = [];
      for (const file of files) {
        if (file.isDirectory()) {
          const worldDir = path.join(serverDir, file.name);
          // Check for level.dat OR other Minecraft world indicators
          const hasLevelDat = fs.existsSync(path.join(worldDir, 'level.dat'));
          const hasUidDat = fs.existsSync(path.join(worldDir, 'uid.dat'));
          const hasSessionLock = fs.existsSync(path.join(worldDir, 'session.lock'));
          const hasDataFolder = fs.existsSync(path.join(worldDir, 'data'));
          const hasPlayerData = fs.existsSync(path.join(worldDir, 'playerdata'));
          const hasDimensions = fs.existsSync(path.join(worldDir, 'DIM-1')) || fs.existsSync(path.join(worldDir, 'DIM1'));
          
          // Consider it a world if it has level.dat OR multiple world indicators
          const isWorld = hasLevelDat || (hasUidDat && (hasSessionLock || hasDataFolder || hasPlayerData || hasDimensions));
          
          if (isWorld) {
            const sizeBytes = getDirSize(worldDir);
            const sizeGB = sizeBytes / 1024 / 1024 / 1024;
            const sizeMB = sizeBytes / 1024 / 1024;
            const sizeKB = sizeBytes / 1024;
            
            let sizeStr;
            if (sizeGB >= 1) {
              sizeStr = sizeGB.toFixed(2) + ' GB';
            } else if (sizeMB >= 1) {
              sizeStr = sizeMB.toFixed(2) + ' MB';
            } else if (sizeKB >= 1) {
              sizeStr = sizeKB.toFixed(2) + ' KB';
            } else {
              sizeStr = sizeBytes + ' B';
            }
            
            worlds.push({ 
              name: file.name, 
              size: sizeStr,
              sizeBytes: sizeBytes
            });
          }
        }
      }
      
      let currentWorld = 'world';
      const propertiesPath = path.join(serverDir, 'server.properties');
      if (fs.existsSync(propertiesPath)) {
        const content = fs.readFileSync(propertiesPath, 'utf8');
        const match = content.match(/^level-name=(.*)$/m);
        if (match) currentWorld = match[1].trim();
      }
      
      const backupsDir = path.join(serverDir, 'backups');
      if (!fs.existsSync(backupsDir)) fs.mkdirSync(backupsDir, { recursive: true });
      const backups = fs.readdirSync(backupsDir)
        .filter(f => f.endsWith('.zip'))
        .map(f => ({
          name: f,
          size: (fs.statSync(path.join(backupsDir, f)).size / 1024 / 1024).toFixed(2) + ' MB'
        }));
        
      res.render('servers/worlds', await getTemplateVars(req, server, {
        worlds,
        currentWorld,
        backups,
        success: req.query.success,
        serverId: server.id,
        activePage: 'worlds',
        error: req.query.error,
        currentPage: 'worlds',
        title: `${server.name} - Worlds`
      }));
    } catch (err) {
      console.error(`Worlds page error for server ${serverId}`, err);
      res.status(500).send('Server error');
    }
  });
 
  // Set Active World
  app.post('/servers/:id/worlds/set', requireAuth, async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    const { worldName } = req.body;
    if (!worldName) return res.status(400).json({ error: 'World name required' });
    try {
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      const worldDir = resolveServerPath(serverId, worldName);
      if (!fs.existsSync(path.join(worldDir, 'level.dat'))) return res.redirect(`/servers/${serverId}/worlds?error=Invalid world`);
      const propertiesPath = resolveServerPath(serverId, 'server.properties');
      let properties = {};
      if (fs.existsSync(propertiesPath)) {
        properties = parseProperties(fs.readFileSync(propertiesPath, 'utf8'));
      }
      properties['level-name'] = worldName;
      writeProperties(properties, propertiesPath);
      res.redirect(`/servers/${serverId}/worlds?success=Active world set to ${worldName}`);
    } catch (err) {
      console.error(`Set world error for server ${serverId}`, err);
      res.redirect(`/servers/${serverId}/worlds?error=Failed to set active world`);
    }
  });
 
  // Download World
  app.get('/servers/:id/worlds/download/:worldName', requireAuth, async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).send('Access denied');
    const worldName = req.params.worldName;
    try {
      const worldDir = resolveServerPath(serverId, worldName);
      if (!fs.existsSync(worldDir)) {
        return res.status(404).send('World not found');
      }
      
      // Check if world has level.dat (is generated)
      if (!fs.existsSync(path.join(worldDir, 'level.dat'))) {
        return res.status(404).send('World not found or not yet generated');
      }
      
      const zipName = `${worldName}-${Date.now()}.zip`;
      res.setHeader('Content-Disposition', `attachment; filename="${zipName}"`);
      res.setHeader('Content-Type', 'application/zip');
      
      const archive = archiver('zip', { zlib: { level: 9 } });
      
      archive.on('error', (err) => {
        console.error('Archive error:', err);
        if (!res.headersSent) {
          res.status(500).send('Failed to create archive');
        }
      });
      
      archive.pipe(res);
      
      // Add all files from world directory into a folder named "world"
      // This makes it ready to use directly in Minecraft servers
      const files = fs.readdirSync(worldDir);
      for (const file of files) {
        const filePath = path.join(worldDir, file);
        const stat = fs.statSync(filePath);
        
        if (stat.isDirectory()) {
          // Archive directory with "world" as the parent folder
          archive.directory(filePath, `world/${file}`);
        } else {
          // Archive file with "world" as the parent folder
          archive.file(filePath, { name: `world/${file}` });
        }
      }
      
      await archive.finalize();
      console.log(`World downloaded: ${worldName} (packaged as "world" folder)`);
    } catch (err) {
      console.error(`Download world error for server ${serverId}`, err);
      if (!res.headersSent) {
        res.status(500).send('Download failed: ' + err.message);
      }
    }
  });
 
  // Delete World
  app.post('/servers/:id/worlds/delete', requireAuth, async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    
    const { worldName } = req.body;
    if (!worldName) return res.status(400).json({ error: 'World name required' });
    
    try {
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      const propertiesPath = resolveServerPath(serverId, 'server.properties');
      let currentWorld = 'world';
      
      if (fs.existsSync(propertiesPath)) {
        const content = fs.readFileSync(propertiesPath, 'utf8');
        const match = content.match(/^level-name=(.*)$/m);
        if (match) currentWorld = match[1].trim();
      }
      
      if (worldName === currentWorld) {
        return res.status(400).json({ error: 'Cannot delete active world' });
      }
      
      const worldDir = resolveServerPath(serverId, worldName);
      if (fs.existsSync(worldDir)) {
        fs.rmSync(worldDir, { recursive: true, force: true });
        res.json({ success: true, message: 'World deleted successfully' });
      } else {
        res.status(404).json({ error: 'World not found' });
      }
    } catch (err) {
      console.error('Delete world error:', err);
      res.status(500).json({ error: 'Failed to delete world' });
    }
  });
  
  // Upload World
  app.post('/servers/:id/worlds/upload', requireAuth, upload.single('worldFile'), async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    
    const { worldName } = req.body;
    if (!worldName) return res.status(400).json({ error: 'World name required' });
    if (!req.file) return res.status(400).json({ error: 'World file required' });
    
    try {
      const worldDir = resolveServerPath(serverId, worldName);
      
      // Check if world already exists
      if (fs.existsSync(worldDir)) {
        fs.unlinkSync(req.file.path);
        return res.status(400).json({ error: 'World already exists' });
      }
      
      // Create world directory
      fs.mkdirSync(worldDir, { recursive: true });
      
      // Extract uploaded ZIP
      await new Promise((resolve, reject) => {
        fs.createReadStream(req.file.path)
          .pipe(unzipper.Extract({ path: worldDir }))
          .on('close', resolve)
          .on('error', reject);
      });
      
      // Clean up uploaded file
      fs.unlinkSync(req.file.path);
      
      res.json({ success: true, message: 'World uploaded successfully' });
    } catch (err) {
      console.error('Upload world error:', err);
      if (req.file && fs.existsSync(req.file.path)) {
        fs.unlinkSync(req.file.path);
      }
      res.status(500).json({ error: 'Failed to upload world' });
    }
  });
  
  // Switch World
  app.post('/servers/:id/worlds/switch', requireAuth, async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    
    const { worldName } = req.body;
    if (!worldName) return res.status(400).json({ error: 'World name required' });
    
    try {
      const worldDir = resolveServerPath(serverId, worldName);
      if (!fs.existsSync(worldDir)) {
        return res.status(404).json({ error: 'World not found' });
      }
      
      // Rename the selected world to "world" for easy deployment
      const targetWorldDir = resolveServerPath(serverId, 'world');
      
      // If "world" already exists and it's not the same as the selected world, back it up
      if (fs.existsSync(targetWorldDir) && worldName !== 'world') {
        const backupName = `world_backup_${Date.now()}`;
        const backupDir = resolveServerPath(serverId, backupName);
        console.log(`Backing up current world to: ${backupName}`);
        fs.renameSync(targetWorldDir, backupDir);
      }
      
      // Rename the selected world to "world"
      if (worldName !== 'world') {
        console.log(`Renaming ${worldName} to world`);
        fs.renameSync(worldDir, targetWorldDir);
      }
      
      // Update server.properties to use "world"
      const propertiesPath = resolveServerPath(serverId, 'server.properties');
      if (fs.existsSync(propertiesPath)) {
        let content = fs.readFileSync(propertiesPath, 'utf8');
        content = content.replace(/^level-name=.*$/m, `level-name=world`);
        fs.writeFileSync(propertiesPath, content);
      }
      
      res.json({ 
        success: true, 
        message: 'World switched successfully! The selected world has been renamed to "world" and set as active.' 
      });
    } catch (err) {
      console.error('Switch world error:', err);
      res.status(500).json({ error: 'Failed to switch world: ' + err.message });
    }
  });
 
  // Upload World
  app.post('/servers/:id/worlds/upload', requireAuth, upload.single('worldFile'), async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    const worldName = sanitize(req.body.name || path.basename(req.file.originalname, '.zip'));
    if (!worldName) return res.status(400).json({ error: 'Invalid world name' });
    let tempPath = req.file.path;
    let targetDir = resolveServerPath(serverId, worldName);
    try {
      if (fs.existsSync(targetDir)) return res.redirect(`/servers/${serverId}/worlds?error=World already exists`);
      await new Promise((resolve, reject) => {
        fs.createReadStream(tempPath)
          .pipe(unzipper.Extract({ path: targetDir }))
          .on('close', resolve)
          .on('error', reject);
      });
      // Normalize directory structure if needed
      if (!fs.existsSync(path.join(targetDir, 'level.dat'))) {
        const subdirs = fs.readdirSync(targetDir, { withFileTypes: true }).filter(d => d.isDirectory());
        if (subdirs.length === 1) {
          const subDirPath = path.join(targetDir, subdirs[0].name);
          if (fs.existsSync(path.join(subDirPath, 'level.dat'))) {
            fs.readdirSync(subDirPath).forEach(f => {
              fs.renameSync(path.join(subDirPath, f), path.join(targetDir, f));
            });
            fs.rmdirSync(subDirPath);
          }
        }
      }
      // Validate it's a Minecraft world (check for level.dat OR world indicators)
      const hasLevelDat = fs.existsSync(path.join(targetDir, 'level.dat'));
      const hasRegionFolder = fs.existsSync(path.join(targetDir, 'region'));
      const hasDataFolder = fs.existsSync(path.join(targetDir, 'data'));
      const hasDimensions = fs.existsSync(path.join(targetDir, 'DIM-1')) || fs.existsSync(path.join(targetDir, 'DIM1'));
      
      if (!hasLevelDat && !hasRegionFolder && !hasDataFolder && !hasDimensions) {
        fs.rmSync(targetDir, { recursive: true, force: true });
        return res.redirect(`/servers/${serverId}/worlds?error=Not a valid Minecraft world`);
      }
      res.redirect(`/servers/${serverId}/worlds?success=World uploaded`);
    } catch (err) {
      console.error(`Upload world error for server ${serverId}`, err);
      if (fs.existsSync(targetDir)) fs.rmSync(targetDir, { recursive: true, force: true });
      res.redirect(`/servers/${serverId}/worlds?error=Failed to upload world`);
    } finally {
      if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
    }
  });
 
  // Upload World from URL (FIXED: use axios instead of fetch for compatibility)
  app.post('/servers/:id/worlds/upload_url', requireAuth, async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    const { url, name } = req.body;
    if (!url || !name) return res.status(400).json({ error: 'URL and name required' });
    const worldName = sanitize(name);
    if (!worldName) return res.status(400).json({ error: 'Invalid world name' });
    let tempPath = path.join(os.tmpdir(), `world-${Date.now()}.zip`);
    let targetDir = resolveServerPath(serverId, worldName);
    try {
      const response = await axios({
        url,
        method: 'GET',
        responseType: 'stream'
      });
      const fileStream = fs.createWriteStream(tempPath);
      await new Promise((resolve, reject) => {
        response.data.pipe(fileStream);
        response.data.on('error', reject);
        fileStream.on('finish', resolve);
      });
      if (fs.existsSync(targetDir)) throw new Error('World already exists');
      await new Promise((resolve, reject) => {
        fs.createReadStream(tempPath)
          .pipe(unzipper.Extract({ path: targetDir }))
          .on('close', resolve)
          .on('error', reject);
      });
      // Normalize directory structure if needed
      if (!fs.existsSync(path.join(targetDir, 'level.dat'))) {
        const subdirs = fs.readdirSync(targetDir, { withFileTypes: true }).filter(d => d.isDirectory());
        if (subdirs.length === 1) {
          const subDirPath = path.join(targetDir, subdirs[0].name);
          if (fs.existsSync(path.join(subDirPath, 'level.dat'))) {
            fs.readdirSync(subDirPath).forEach(f => {
              fs.renameSync(path.join(subDirPath, f), path.join(targetDir, f));
            });
            fs.rmdirSync(subDirPath);
          }
        }
      }
      if (!fs.existsSync(path.join(targetDir, 'level.dat'))) {
        fs.rmSync(targetDir, { recursive: true, force: true });
        throw new Error('Not a valid Minecraft world');
      }
      res.redirect(`/servers/${serverId}/worlds?success=World uploaded from URL`);
    } catch (err) {
      console.error(`Upload URL error for server ${serverId}`, err);
      if (fs.existsSync(targetDir)) fs.rmSync(targetDir, { recursive: true, force: true });
      res.redirect(`/servers/${serverId}/worlds?error=Failed to upload from URL: ${err.message}`);
    } finally {
      if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
    }
  });
 
  // Create Backup
  app.post('/servers/:id/worlds/backup', requireAuth, async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    const { worldName } = req.body;
    if (!worldName) return res.status(400).json({ error: 'World name required' });
    try {
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      const worldDir = resolveServerPath(serverId, worldName);
      if (!fs.existsSync(path.join(worldDir, 'level.dat'))) return res.redirect(`/servers/${serverId}/worlds?error=Invalid world`);
      const backupsDir = path.join(resolveServerPath(serverId), 'backups');
      if (!fs.existsSync(backupsDir)) fs.mkdirSync(backupsDir, { recursive: true });
      const timestamp = new Date().toISOString().replace(/:/g, '-');
      const zipName = `${worldName}-${timestamp}.zip`;
      const zipPath = path.join(backupsDir, zipName);
      const output = fs.createWriteStream(zipPath);
      const archive = archiver('zip', { zlib: { level: 9 } });
      archive.pipe(output);
      archive.directory(worldDir, false);
      await archive.finalize();
      res.redirect(`/servers/${serverId}/worlds?success=Backup created: ${zipName}`);
    } catch (err) {
      console.error(`Backup error for server ${serverId}`, err);
      res.redirect(`/servers/${serverId}/worlds?error=Failed to create backup`);
    }
  });
 
  // Download Backup
  app.get('/servers/:id/worlds/backup/download/:backupName', requireAuth, async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).send('Access denied');
    const backupName = req.params.backupName;
    try {
      const backupsDir = resolveServerPath(serverId, 'backups');
      const zipPath = path.join(backupsDir, backupName);
      if (!fs.existsSync(zipPath)) return res.status(404).send('Backup not found');
      res.download(zipPath);
    } catch (err) {
      console.error(`Download backup error for server ${serverId}`, err);
      res.status(500).send('Download failed');
    }
  });
 
  // Delete Backup
  app.post('/servers/:id/worlds/backup/delete', requireAuth, async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    const { backupName } = req.body;
    if (!backupName) return res.status(400).json({ error: 'Backup name required' });
    try {
      const backupsDir = resolveServerPath(serverId, 'backups');
      const zipPath = path.join(backupsDir, backupName);
      if (fs.existsSync(zipPath)) {
        fs.unlinkSync(zipPath);
        res.redirect(`/servers/${serverId}/worlds?success=Backup deleted`);
      } else {
        res.redirect(`/servers/${serverId}/worlds?error=Backup not found`);
      }
    } catch (err) {
      console.error(`Delete backup error for server ${serverId}`, err);
      res.redirect(`/servers/${serverId}/worlds?error=Failed to delete backup`);
    }
  });
 
  // Restore from Backup
  app.post('/servers/:id/worlds/backup/restore', requireAuth, async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    const { backupName, worldName } = req.body;
    if (!backupName || !worldName) return res.status(400).json({ error: 'Backup and world name required' });
    const sanitizedWorldName = sanitize(worldName);
    if (!sanitizedWorldName) return res.status(400).json({ error: 'Invalid world name' });
    try {
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      const targetDir = resolveServerPath(serverId, sanitizedWorldName);
      if (fs.existsSync(targetDir)) return res.redirect(`/servers/${serverId}/worlds?error=World already exists`);
      const backupsDir = resolveServerPath(serverId, 'backups');
      const zipPath = path.join(backupsDir, backupName);
      if (!fs.existsSync(zipPath)) return res.redirect(`/servers/${serverId}/worlds?error=Backup not found`);
      await new Promise((resolve, reject) => {
        fs.createReadStream(zipPath)
          .pipe(unzipper.Extract({ path: targetDir }))
          .on('close', resolve)
          .on('error', reject);
      });
      // Normalize directory structure if needed
      if (!fs.existsSync(path.join(targetDir, 'level.dat'))) {
        const subdirs = fs.readdirSync(targetDir, { withFileTypes: true }).filter(d => d.isDirectory());
        if (subdirs.length === 1) {
          const subDirPath = path.join(targetDir, subdirs[0].name);
          if (fs.existsSync(path.join(subDirPath, 'level.dat'))) {
            fs.readdirSync(subDirPath).forEach(f => {
              fs.renameSync(path.join(subDirPath, f), path.join(targetDir, f));
            });
            fs.rmdirSync(subDirPath);
          }
        }
      }
      if (!fs.existsSync(path.join(targetDir, 'level.dat'))) {
        fs.rmSync(targetDir, { recursive: true, force: true });
        return res.redirect(`/servers/${serverId}/worlds?error=Not a valid Minecraft world`);
      }
      res.redirect(`/servers/${serverId}/worlds?success=Restored from backup`);
    } catch (err) {
      console.error(`Restore error for server ${serverId}`, err);
      if (fs.existsSync(targetDir)) fs.rmSync(targetDir, { recursive: true, force: true });
      res.redirect(`/servers/${serverId}/worlds?error=Failed to restore`);
    }
  });
 
  // Rename World
  app.post('/servers/:id/worlds/rename', requireAuth, async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    let { oldName, newName } = req.body;
    if (!oldName || !newName) return res.status(400).json({ error: 'Old and new names required' });
    const sanitizedNewName = sanitize(newName);
    if (!sanitizedNewName || oldName === sanitizedNewName) return res.status(400).json({ error: 'Invalid new name' });
    try {
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      const oldDir = resolveServerPath(serverId, oldName);
      if (!fs.existsSync(path.join(oldDir, 'level.dat'))) return res.redirect(`/servers/${serverId}/worlds?error=Invalid world`);
      const newDir = resolveServerPath(serverId, sanitizedNewName);
      if (fs.existsSync(newDir)) return res.redirect(`/servers/${serverId}/worlds?error=New name already exists`);
      fs.renameSync(oldDir, newDir);
      // Update properties if active
      const propertiesPath = resolveServerPath(serverId, 'server.properties');
      if (fs.existsSync(propertiesPath)) {
        let properties = parseProperties(fs.readFileSync(propertiesPath, 'utf8'));
        if (properties['level-name'] === oldName) {
          properties['level-name'] = sanitizedNewName;
          writeProperties(properties, propertiesPath);
        }
      }
      res.redirect(`/servers/${serverId}/worlds?success=World renamed to ${sanitizedNewName}`);
    } catch (err) {
      console.error(`Rename error for server ${serverId}`, err);
      res.redirect(`/servers/${serverId}/worlds?error=Failed to rename world`);
    }
  });
 
  // Change World Seed
  app.post('/servers/:id/worlds/change_seed', requireAuth, async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    const { worldName, newSeed } = req.body;
    if (!worldName || !newSeed) return res.status(400).json({ error: 'World name and seed required' });
    try {
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      const worldDir = resolveServerPath(serverId, worldName);
      const levelDatPath = path.join(worldDir, 'level.dat');
      
      // If level.dat exists, modify it
      if (fs.existsSync(levelDatPath)) {
        await setWorldSeed(worldDir, newSeed);
        res.redirect(`/servers/${serverId}/worlds?success=Seed changed to ${newSeed}`);
      } else {
        // If level.dat doesn't exist, update server.properties instead
        const propertiesPath = resolveServerPath(serverId, 'server.properties');
        if (fs.existsSync(propertiesPath)) {
          const propertiesContent = fs.readFileSync(propertiesPath, 'utf8');
          const properties = parseProperties(propertiesContent);
          properties['level-seed'] = newSeed;
          writeProperties(properties, propertiesPath);
          res.redirect(`/servers/${serverId}/worlds?success=Seed set to ${newSeed} (will apply on first start)`);
        } else {
          res.redirect(`/servers/${serverId}/worlds?error=Server properties not found`);
        }
      }
    } catch (err) {
      console.error(`Change seed error for server ${serverId}`, err);
      res.redirect(`/servers/${serverId}/worlds?error=Failed to change seed: ${err.message}`);
    }
  });
  app.get('/servers/:id/worlds/marketplace', requireAuth, async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).send('Access denied');
    
    try {
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      if (!server) return res.status(404).send('Server not found');
      
      res.render('servers/worlds_marketplace', await getTemplateVars(req, server, {
        serverId: server.id,
        activePage: 'worlds',
        currentPage: 'worlds_marketplace',
        title: `${server.name} - World Marketplace`
      }));
    } catch (err) {
      console.error('World marketplace page error:', err);
      res.status(500).send('Server error');
    }
  });

  // World Marketplace API - Fetch worlds from CurseForge
  app.get('/servers/:id/worlds/marketplace/api', requireAuth, async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    
    const { search = '', page = 1, category = '' } = req.query;
    
    try {
      const apiKey = process.env.CURSEFORGE_API_KEY || '$2a$10$bL4bIL5pUWqfcO7KQtnMReakwtfHbNKh6v1uTpKlzhwoueEJQnPnm';
      
      const params = {
        gameId: 432, // Minecraft
        classId: 17, // Worlds
        sortField: 2, // Popularity
        sortOrder: 'desc',
        index: (page - 1) * 20,
        pageSize: 20
      };
      
      if (search) params.searchFilter = search;
      
      const response = await axios.get('https://api.curseforge.com/v1/mods/search', {
        headers: {
          'x-api-key': apiKey,
          'Accept': 'application/json',
          'User-Agent': 'MinecraftServerPanel/1.0'
        },
        params: params,
        timeout: 15000
      });
      
      const worlds = response.data.data.map(mod => {
        const latestFile = mod.latestFiles && mod.latestFiles.length > 0 ? mod.latestFiles[0] : null;
        
        return {
          id: mod.id,
          name: mod.name,
          description: mod.summary || 'No description available',
          author: mod.authors && mod.authors.length > 0 ? mod.authors[0].name : 'Unknown',
          downloads: mod.downloadCount || 0,
          image: mod.logo ? mod.logo.url : 'https://media.forgecdn.net/avatars/thumbnails/default.png',
          fileId: latestFile ? latestFile.id : null,
          fileName: latestFile ? latestFile.fileName : 'world.zip',
          fileSize: latestFile ? latestFile.fileLength : 0,
          downloadUrl: latestFile ? latestFile.downloadUrl : null,
          projectUrl: mod.links ? mod.links.websiteUrl : `https://www.curseforge.com/minecraft/worlds/${mod.slug}`,
          dateModified: latestFile ? latestFile.fileDate : mod.dateModified
        };
      });
      
      res.json({
        success: true,
        worlds: worlds,
        total: response.data.pagination.totalCount,
        page: parseInt(page)
      });
      
    } catch (err) {
      console.error('CurseForge API error:', (err.response && err.response.data) || err.message);
      res.status(500).json({ 
        error: 'Failed to fetch worlds from CurseForge',
        details: (err.response && err.response.data && err.response.data.message) || err.message
      });
    }
  });

  // Direct download route - Downloads .zip to server directory
  app.get('/servers/:id/worlds/download/:worldId/:fileId', requireAuth, async (req, res) => {
    const serverId = req.params.id;
    const { worldId, fileId } = req.params;
    
    try {
      // Check authorization
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      if (!server) {
        return res.status(404).json({ success: false, error: 'Server not found' });
      }
      
      console.log(`[World Download] Starting download for worldId: ${worldId}, fileId: ${fileId}`);
      
      // Try to get file info from CurseForge API
      const apiKey = process.env.CURSEFORGE_API_KEY || '$2a$10$bL4bIL5pUWqfcO7KQtnMReakwtfHbNKh6v1uTpKlzhwoueEJQnPnm';
      let fileName = `world-${worldId}-${fileId}.zip`;
      let downloadUrl = null;
      
      try {
        const fileInfoResponse = await axios.get(`https://api.curseforge.com/v1/mods/${worldId}/files/${fileId}`, {
          headers: {
            'x-api-key': apiKey,
            'Accept': 'application/json',
            'User-Agent': 'MinecraftServerPanel/1.0'
          },
          timeout: 10000
        });
        
        const fileInfo = fileInfoResponse.data.data;
        fileName = fileInfo.fileName || fileName;
        downloadUrl = fileInfo.downloadUrl;
        
        console.log(`[World Download] API Response - fileName: ${fileName}, downloadUrl: ${downloadUrl}`);
        
        // CurseForge API returns null for downloadUrl on most files due to their download policy
        if (!downloadUrl || downloadUrl === 'null') {
          console.log('[World Download] CurseForge API returned null downloadUrl - this is expected behavior');
          return res.status(403).json({
            success: false,
            error: 'CurseForge requires manual downloads',
            reason: 'curseforge_policy',
            fileName: fileName,
            message: 'CurseForge does not allow automated downloads for this world. This is a CurseForge policy to ensure proper download tracking and attribution to mod authors.'
          });
        }
        
      } catch (apiError) {
        console.log(`[World Download] API request failed: ${apiError.message}`);
        return res.status(500).json({
          success: false,
          error: 'Failed to fetch world information from CurseForge',
          reason: 'api_error',
          message: apiError.message
        });
      }
      
      // If we got here, we have a valid download URL (rare case)
      const serverDir = resolveServerPath(serverId);
      if (!fs.existsSync(serverDir)) {
        fs.mkdirSync(serverDir, { recursive: true });
      }
      
      const filePath = path.join(serverDir, fileName);
      
      // Check if already exists
      if (fs.existsSync(filePath)) {
        const stats = fs.statSync(filePath);
        const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);
        return res.json({
          success: true,
          message: 'World already downloaded',
          fileName: fileName,
          filePath: `servers/${serverId}/${fileName}`,
          fileSize: `${fileSizeMB} MB`,
          alreadyExists: true
        });
      }
      
      console.log(`[World Download] Attempting download from: ${downloadUrl}`);
      
      // Try to download
      const response = await axios({
        url: downloadUrl,
        method: 'GET',
        responseType: 'stream',
        timeout: 300000, // 5 minutes
        maxRedirects: 10,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': '*/*',
          'Referer': 'https://www.curseforge.com/'
        }
      });
      
      // Check content type
      const contentType = response.headers['content-type'] || '';
      if (contentType.includes('text/html')) {
        throw new Error('Received HTML page instead of file - download blocked');
      }
      
      // Download file
      const writer = fs.createWriteStream(filePath);
      response.data.pipe(writer);
      
      await new Promise((resolve, reject) => {
        writer.on('finish', resolve);
        writer.on('error', reject);
        response.data.on('error', reject);
      });
      
      // Verify file
      if (!fs.existsSync(filePath)) {
        throw new Error('File was not created');
      }
      
      const stats = fs.statSync(filePath);
      if (stats.size === 0) {
        fs.unlinkSync(filePath);
        throw new Error('Downloaded file is empty');
      }
      
      const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);
      console.log(`[World Download] Success! Size: ${fileSizeMB} MB`);
      
      res.json({
        success: true,
        message: `World downloaded successfully!`,
        fileName: fileName,
        filePath: `servers/${serverId}/${fileName}`,
        fileSize: `${fileSizeMB} MB`,
        downloaded: true
      });
      
    } catch (err) {
      console.error('[World Download] Error:', err.message);
      
      // Clean up failed downloads
      try {
        const serverDir = resolveServerPath(serverId);
        if (fs.existsSync(serverDir)) {
          const files = fs.readdirSync(serverDir).filter(f => f.endsWith('.zip'));
          files.forEach(file => {
            const filePath = path.join(serverDir, file);
            if (fs.existsSync(filePath)) {
              const stats = fs.statSync(filePath);
              if (stats.size === 0) {
                fs.unlinkSync(filePath);
              }
            }
          });
        }
      } catch (cleanupError) {
        // Ignore cleanup errors
      }
      
      res.status(500).json({
        success: false,
        error: 'Download failed',
        reason: 'download_error',
        message: err.message || 'Could not download world file'
      });
    }
  });

  // List downloaded worlds
  app.get('/servers/:id/worlds/downloaded', requireAuth, async (req, res) => {
    const serverId = req.params.id;
    
    try {
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      if (!server) {
        return res.status(404).json({ error: 'Server not found' });
      }
      
      const serverDir = resolveServerPath(serverId);
      
      if (!fs.existsSync(serverDir)) {
        return res.json({ success: true, worlds: [] });
      }
      
      const files = fs.readdirSync(serverDir);
      const zipFiles = files.filter(f => f.endsWith('.zip'));
      
      const worlds = zipFiles.map(fileName => {
        const filePath = path.join(serverDir, fileName);
        const stats = fs.statSync(filePath);
        const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);
        
        return {
          fileName: fileName,
          filePath: `servers/${serverId}/${fileName}`,
          fileSize: `${fileSizeMB} MB`,
          downloadedAt: stats.mtime
        };
      });
      
      res.json({ success: true, worlds: worlds });
      
    } catch (err) {
      console.error('Error listing downloaded worlds:', err);
      res.status(500).json({ error: 'Failed to list downloaded worlds' });
    }
  });

  app.post('/servers/:id/worlds/marketplace/install', requireAuth, async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    
    const { worldName, downloadUrl, worldId } = req.body;
    if (!worldName || !downloadUrl) {
      return res.status(400).json({ error: 'World name and download URL required' });
    }
    
    const sanitizedWorldName = sanitize(worldName);
    if (!sanitizedWorldName) {
      return res.status(400).json({ error: 'Invalid world name' });
    }
    
    let tempPath = path.join(os.tmpdir(), `world-${Date.now()}.zip`);
    let targetDir = resolveServerPath(serverId, sanitizedWorldName);
    
    try {
      // Check if world already exists
      if (fs.existsSync(targetDir)) {
        return res.status(400).json({ error: 'World already exists' });
      }
      
      console.log(`Downloading world "${worldName}" from: ${downloadUrl}`);
      
      // Handle different URL types
      let fullUrl = downloadUrl;
      if (downloadUrl.startsWith('/')) {
        // Relative URL - convert to full URL
        fullUrl = `http://localhost:3000${downloadUrl}`;
      } else if (!downloadUrl.startsWith('http://') && !downloadUrl.startsWith('https://')) {
        // Invalid URL format - use fallback
        console.log('Invalid URL format, using fallback test world');
        fullUrl = `http://localhost:3000/test-world.zip`;
      }
      
      console.log(`Full download URL: ${fullUrl}`);
      
      // Enhanced headers for better compatibility
      const headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'application/octet-stream, application/zip, application/x-zip-compressed, */*',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept-Language': 'en-US,en;q=0.9',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache'
      };
      
      const response = await axios({
        url: fullUrl,
        method: 'GET',
        responseType: 'stream',
        timeout: 180000, // 3 minute timeout for large worlds
        maxRedirects: 10,
        headers: headers,
        validateStatus: function (status) {
          return status >= 200 && status < 400;
        },
        // Handle SSL issues
        httpsAgent: new (require('https').Agent)({
          rejectUnauthorized: false
        })
      });
      
      const fileStream = fs.createWriteStream(tempPath);
      
      await new Promise((resolve, reject) => {
        response.data.pipe(fileStream);
        response.data.on('error', reject);
        fileStream.on('finish', resolve);
        fileStream.on('error', reject);
      });
      
      console.log(`World downloaded to: ${tempPath}`);
      
      // Check file size
      const stats = fs.statSync(tempPath);
      if (stats.size < 1000) {
        throw new Error('Downloaded file is too small to be a valid world');
      }
      
      // Create target directory
      fs.mkdirSync(targetDir, { recursive: true });
      
      // Extract ZIP file
      console.log(`Extracting world to: ${targetDir}`);
      
      await new Promise((resolve, reject) => {
        const stream = fs.createReadStream(tempPath)
          .pipe(unzipper.Extract({ path: targetDir }));
        
        stream.on('close', resolve);
        stream.on('error', reject);
      });
      
      // Normalize directory structure - move contents up if nested in a single folder
      const items = fs.readdirSync(targetDir, { withFileTypes: true });
      const subdirs = items.filter(d => d.isDirectory());
      
      // If there's only one subdirectory and no files at root level, move contents up
      if (subdirs.length === 1 && items.length === 1) {
        const subDirPath = path.join(targetDir, subdirs[0].name);
        const subItems = fs.readdirSync(subDirPath);
        
        // Move all contents from subdirectory to target directory
        for (const item of subItems) {
          const srcPath = path.join(subDirPath, item);
          const destPath = path.join(targetDir, item);
          fs.renameSync(srcPath, destPath);
        }
        
        // Remove empty subdirectory
        fs.rmdirSync(subDirPath);
      }
      
      // Validate it's a Minecraft world
      const hasLevelDat = fs.existsSync(path.join(targetDir, 'level.dat'));
      const hasRegionFolder = fs.existsSync(path.join(targetDir, 'region'));
      const hasDataFolder = fs.existsSync(path.join(targetDir, 'data'));
      
      if (!hasLevelDat && !hasRegionFolder && !hasDataFolder) {
        fs.rmSync(targetDir, { recursive: true, force: true });
        return res.status(400).json({ 
          error: 'Not a valid Minecraft world - missing level.dat or region folder' 
        });
      }
      
      console.log(`World "${worldName}" installed successfully`);
      res.json({ 
        success: true, 
        message: `${worldName} installed successfully! Go to World Management to switch to this world.`,
        worldName: sanitizedWorldName
      });
      
    } catch (err) {
      console.error('World install error:', err);
      
      // Clean up on error
      if (fs.existsSync(targetDir)) {
        fs.rmSync(targetDir, { recursive: true, force: true });
      }
      
      // Try fallback download if original fails
      if (!downloadUrl.includes('test-world.zip')) {
        console.log('Trying fallback download...');
        try {
          const fallbackUrl = `http://localhost:3000/test-world.zip`;
          const fallbackResponse = await axios({
            url: fallbackUrl,
            method: 'GET',
            responseType: 'stream',
            timeout: 60000,
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
          });
          
          const fallbackStream = fs.createWriteStream(tempPath);
          await new Promise((resolve, reject) => {
            fallbackResponse.data.pipe(fallbackStream);
            fallbackResponse.data.on('error', reject);
            fallbackStream.on('finish', resolve);
            fallbackStream.on('error', reject);
          });
          
          // Create target directory and extract
          fs.mkdirSync(targetDir, { recursive: true });
          await new Promise((resolve, reject) => {
            const stream = fs.createReadStream(tempPath)
              .pipe(unzipper.Extract({ path: targetDir }));
            stream.on('close', resolve);
            stream.on('error', reject);
          });
          
          console.log(`Fallback world installed successfully: ${sanitizedWorldName}`);
          return res.json({ 
            success: true, 
            message: `${worldName} installed successfully using fallback world! Go to World Management to switch to this world.`,
            worldName: sanitizedWorldName,
            fallback: true
          });
          
        } catch (fallbackErr) {
          console.error('Fallback download also failed:', fallbackErr);
        }
      }
      
      let errorMessage = 'Failed to install world';
      if (err.code === 'ENOTFOUND') {
        errorMessage = 'Could not download world - server not found. The download link may be offline.';
      } else if (err.code === 'ETIMEDOUT') {
        errorMessage = 'Download timed out - the world file may be too large or the server is slow. Try again later.';
      } else if (err.response && err.response.status === 404) {
        errorMessage = 'World download link not found (404). The file may have been moved or deleted.';
      } else if (err.response && err.response.status === 403) {
        errorMessage = 'Access denied - the download link requires authentication or has restrictions.';
      } else if (err.code === 'ERR_INVALID_URL') {
        errorMessage = 'Invalid download URL format. Please check the world download link.';
      } else if (err.message) {
        errorMessage = err.message;
      }
      
      res.status(500).json({ error: errorMessage });
      
    } finally {
      // Clean up temp file
      if (fs.existsSync(tempPath)) {
        fs.unlinkSync(tempPath);
      }
    }
  });
app.get('/servers/:id/properties', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!(await isAuthorized(req, serverId))) {
            return res.status(403).send('Access denied');
        }

        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).send('Server not found');
        }

        res.render('servers/properties', await getTemplateVars(req, server, {
            activePage: 'properties',
            currentPage: 'server-properties'
        }));
    } catch (err) {
        console.error('Properties page error:', err);
        res.status(500).send('Internal server error');
    }
});

// Get current properties as JSON
app.get('/servers/:id/properties/get', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!(await isAuthorized(req, serverId))) {
            return res.status(403).json({ error: 'Access denied' });
        }

        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }

        const propertiesPath = resolveServerPath(serverId, 'server.properties');
        let properties = {};

        if (fs.existsSync(propertiesPath)) {
            try {
                const content = fs.readFileSync(propertiesPath, 'utf8');
                properties = parseProperties(content);
            } catch (err) {
                console.error('Error reading server.properties:', err);
                // Return default properties if file can't be read
                properties = getDefaultProperties(server);
            }
        } else {
            // Create default properties file if it doesn't exist
            properties = getDefaultProperties(server);
            await updateServerPropertiesPort(serverId, server.port);
        }

        res.json({ success: true, properties });
    } catch (err) {
        console.error('Get properties error:', err);
        res.status(500).json({ error: 'Failed to load properties' });
    }
});

// Save properties
app.post('/servers/:id/properties/save', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!(await isAuthorized(req, serverId))) {
            return res.status(403).json({ error: 'Access denied' });
        }

        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }

        const { properties } = req.body;
        if (!properties || typeof properties !== 'object') {
            return res.status(400).json({ error: 'Invalid properties data' });
        }

        // Ensure server port is protected
        properties['server-port'] = server.port;

        const propertiesPath = resolveServerPath(serverId, 'server.properties');
        
        // Write properties to file
        writeProperties(properties, propertiesPath);

        console.log(`Properties saved for server ${serverId}`);
        
        res.json({ 
            success: true, 
            message: 'Properties saved successfully!',
            warning: properties['server-port'] !== server.port ? 'Server port was protected and not changed' : null
        });
    } catch (err) {
        console.error('Save properties error:', err);
        res.status(500).json({ error: 'Failed to save properties' });
    }
});

// Reset properties to defaults
app.post('/servers/:id/properties/reset', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!(await isAuthorized(req, serverId))) {
            return res.status(403).json({ error: 'Access denied' });
        }

        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }

        // Get default properties and ensure correct port
        const defaultProperties = getDefaultProperties(server);
        defaultProperties['server-port'] = server.port;

        const propertiesPath = resolveServerPath(serverId, 'server.properties');
        
        // Write default properties to file
        writeProperties(defaultProperties, propertiesPath);

        console.log(`Properties reset to defaults for server ${serverId}`);
        
        res.json({ 
            success: true, 
            message: 'Properties reset to defaults successfully!'
        });
    } catch (err) {
        console.error('Reset properties error:', err);
        res.status(500).json({ error: 'Failed to reset properties' });
    }
});
app.get('/servers/:id/installing', requireAuth, async (req, res) => {
    try {
        const sId = parseInt(req.params.id);
        if (!await isAuthorized(req, sId)) return res.status(403).send('Access denied');
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [sId]);
        if (!server) return res.status(404).send('Not found');
        res.render('servers/installing', await getTemplateVars(req, server, { title:'Installing '+server.name, activePage:'installing' }));
    } catch(e) { res.status(500).send(e.message); }
});
app.get('/api/servers/:id/install-progress', requireAuth, async (req, res) => {
    const sId = parseInt(req.params.id);
    if (!await isAuthorized(req, sId)) return res.status(403).json({ error:'Access denied' });
    res.json(installProgress[sId] || { step:'Waiting...', percent:0, done:false, error:null });
});

// Delete progress
app.get('/servers/:id/deleting', requireAuth, async (req, res) => {
    try {
        const sId = parseInt(req.params.id);
        if (!await isAuthorized(req, sId)) return res.status(403).send('Access denied');
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [sId]);
        if (!server) return res.status(404).send('Not found');
        res.render('servers/deleting', await getTemplateVars(req, server, { title:'Deleting '+server.name, activePage:'deleting' }));
    } catch(e) { res.status(500).send(e.message); }
});
app.get('/api/servers/:id/delete-progress', requireAuth, async (req, res) => {
    const sId = parseInt(req.params.id);
    if (!await isAuthorized(req, sId)) return res.status(403).json({ error:'Access denied' });
    res.json(deleteProgress[sId] || { step:'Waiting...', percent:0, done:false, error:null });
});

// Reinstall progress
app.get('/servers/:id/reinstalling', requireAuth, async (req, res) => {
    try {
        const sId = parseInt(req.params.id);
        if (!await isAuthorized(req, sId)) return res.status(403).send('Access denied');
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [sId]);
        if (!server) return res.status(404).send('Not found');
        res.render('servers/reinstalling', await getTemplateVars(req, server, { title:'Reinstalling '+server.name, activePage:'reinstalling' }));
    } catch(e) { res.status(500).send(e.message); }
});
app.get('/api/servers/:id/reinstall-progress', requireAuth, async (req, res) => {
    const sId = parseInt(req.params.id);
    if (!await isAuthorized(req, sId)) return res.status(403).json({ error:'Access denied' });
    res.json(reinstallProgress[sId] || { step:'Waiting...', percent:0, done:false, error:null });
});
app.get('/servers/:id/mods', requireAuth, async (req, res) => {
    try {
        const sId = req.params.id;
        if (!await isAuthorized(req, sId)) return res.status(403).send('Access denied');
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [sId]);
        const modsDir = path.join(resolveServerPath(sId), 'mods');
        let mods = [];
        if (fs.existsSync(modsDir)) mods = fs.readdirSync(modsDir).filter(f=>/\.(jar|zip|disabled)$/.test(f)).map(f=>{ const s=fs.statSync(path.join(modsDir,f)); return {name:f,size:(s.size/1024).toFixed(1)+' KB',enabled:!f.endsWith('.disabled'),modified:s.mtime}; });
        res.render('servers/mods', await getTemplateVars(req, server, { mods, title:server.name+' — Mods', activePage:'mods' }));
    } catch(e) { res.status(500).send(e.message); }
});
app.post('/servers/:id/mods/upload', requireAuth, modUpload.single('mod'), async (req, res) => {
    try {
        const sId = req.params.id;
        if (!await isAuthorized(req, sId)) return res.status(403).json({error:'Access denied'});
        if (!req.file) return res.status(400).json({error:'No file'});
        const modsDir = path.join(resolveServerPath(sId), 'mods');
        fs.mkdirSync(modsDir, {recursive:true});
        fs.renameSync(req.file.path, path.join(modsDir, sanitize(req.file.originalname)));
        res.json({success:true});
    } catch(e) { res.status(500).json({error:e.message}); }
});
app.post('/servers/:id/mods/toggle', requireAuth, async (req, res) => {
    try {
        const sId = req.params.id;
        if (!await isAuthorized(req, sId)) return res.status(403).json({error:'Access denied'});
        const {filename} = req.body;
        const modsDir = path.join(resolveServerPath(sId), 'mods');
        const fp = path.join(modsDir, sanitize(filename));
        if (!fp.startsWith(modsDir)) return res.status(400).json({error:'Invalid'});
        if (filename.endsWith('.disabled')) { fs.renameSync(fp, fp.slice(0,-9)); res.json({success:true,enabled:true}); }
        else { fs.renameSync(fp, fp+'.disabled'); res.json({success:true,enabled:false}); }
    } catch(e) { res.status(500).json({error:e.message}); }
});
app.post('/servers/:id/mods/delete', requireAuth, async (req, res) => {
    try {
        const sId = req.params.id;
        if (!await isAuthorized(req, sId)) return res.status(403).json({error:'Access denied'});
        const fp = path.join(resolveServerPath(sId), 'mods', sanitize(req.body.filename));
        if (fs.existsSync(fp)) fs.unlinkSync(fp);
        res.json({success:true});
    } catch(e) { res.status(500).json({error:e.message}); }
});

// Modpacks
app.get('/servers/:id/modpacks', requireAuth, async (req, res) => {
    try {
        const sId = req.params.id;
        console.log('Modpacks route: serverId:', sId);
        if (!await isAuthorized(req, sId)) return res.status(403).send('Access denied');
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [sId]);
        console.log('Modpacks route: server:', server);
        if (!server) return res.status(404).send('Server not found');
        const query = req.query.q || '';
        // Fetch modpacks from Modrinth
        let modpacks = [];
        try {
            const r = await axios.get('https://api.modrinth.com/v2/search', {
                params: { query: query || 'modpack', facets: JSON.stringify([['project_type:modpack']]), limit: 20, index: query ? 'relevance' : 'downloads' },
                headers: { 'User-Agent': 'MinecraftPanel/1.0' }, timeout: 8000
            });
            modpacks = r.data.hits || [];
        } catch(e) {
            console.error('Modrinth modpacks error:', e.message);
            // Fallback to static list
            modpacks = [
                { project_id:'rlcraft', title:'RLCraft', description:'Hardcore survival challenge modpack', author:'Shivaxi', downloads:15000000, icon_url:'', categories:['adventure','challenging'] },
                { project_id:'atm9', title:'All The Mods 9', description:'Kitchen-sink modpack with 400+ mods', author:'AllTheMods', downloads:8000000, icon_url:'', categories:['technology','magic'] },
                { project_id:'bettermc', title:'Better MC', description:'Vanilla+ experience', author:'Drullkus', downloads:5000000, icon_url:'', categories:['adventure','optimization'] },
            ];
        }
        res.render('servers/modpacks', await getTemplateVars(req, server, { modpacks, query, title: server.name+' — Modpacks', activePage:'modpacks' }));
    } catch(e) { 
        console.error('Modpacks route error:', e);
        res.status(500).send(e.message); 
    }
});

// Log viewer
app.get('/servers/:id/logs', requireAuth, async (req, res) => {
    try {
        const sId = req.params.id;
        if (!await isAuthorized(req, sId)) return res.status(403).send('Access denied');
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [sId]);
        const logsDir = path.join(resolveServerPath(sId), 'logs');
        let logFiles = [];
        if (fs.existsSync(logsDir)) logFiles = fs.readdirSync(logsDir).filter(f=>/\.(log|gz|txt)$/.test(f)).map(f=>{ const s=fs.statSync(path.join(logsDir,f)); return {name:f,size:(s.size/1024).toFixed(1)+' KB',modified:s.mtime}; }).sort((a,b)=>new Date(b.modified)-new Date(a.modified));
        const latestLog = path.join(resolveServerPath(sId),'logs','latest.log');
        let logContent=''; const analysis={errors:0,warnings:0,joins:0,leaves:0,totalLines:0};
        if (fs.existsSync(latestLog)) { const lines=fs.readFileSync(latestLog,'utf8').split('\n'); logContent=lines.slice(-500).join('\n'); analysis.totalLines=lines.length; lines.forEach(l=>{ if(/ERROR|SEVERE/i.test(l))analysis.errors++; if(/WARN/i.test(l))analysis.warnings++; if(/joined the game/i.test(l))analysis.joins++; if(/left the game/i.test(l))analysis.leaves++; }); }
        res.render('servers/logs', await getTemplateVars(req, server, { logFiles, logContent, analysis, title:server.name+' — Logs', activePage:'logs' }));
    } catch(e) { res.status(500).send(e.message); }
});
app.get('/servers/:id/logs/download/:filename', requireAuth, async (req, res) => {
    try {
        const sId = req.params.id;
        if (!await isAuthorized(req, sId)) return res.status(403).send('Access denied');
        const fp = path.join(resolveServerPath(sId), 'logs', sanitize(req.params.filename));
        if (!fs.existsSync(fp)) return res.status(404).send('Not found');
        res.download(fp);
    } catch(e) { res.status(500).send(e.message); }
});

// MOTD editor
app.get('/servers/:id/motd', requireAuth, async (req, res) => {
    try {
        const sId = req.params.id;
        if (!await isAuthorized(req, sId)) return res.status(403).send('Access denied');
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [sId]);
        const propsPath = path.join(resolveServerPath(sId),'server.properties');
        let currentMotd = server.name;
        if (fs.existsSync(propsPath)) { const m=fs.readFileSync(propsPath,'utf8').match(/^motd=(.*)$/m); if(m)currentMotd=m[1]; }
        res.render('servers/motd', await getTemplateVars(req, server, { currentMotd, title:server.name+' — MOTD', activePage:'motd' }));
    } catch(e) { res.status(500).send(e.message); }
});
app.post('/servers/:id/motd', requireAuth, async (req, res) => {
    try {
        const sId = req.params.id;
        if (!await isAuthorized(req, sId)) return res.status(403).json({error:'Access denied'});
        const {motd} = req.body;
        const propsPath = path.join(resolveServerPath(sId),'server.properties');
        if (fs.existsSync(propsPath)) { let c=fs.readFileSync(propsPath,'utf8'); c=/^motd=/m.test(c)?c.replace(/^motd=.*$/m,`motd=${motd}`):c+`\nmotd=${motd}`; fs.writeFileSync(propsPath,c,'utf8'); }
        res.json({success:true});
    } catch(e) { res.status(500).json({error:e.message}); }
});

// Icon
app.get('/servers/:id/icon', requireAuth, async (req, res) => {
    try {
        const sId = req.params.id;
        if (!await isAuthorized(req, sId)) return res.status(403).send('Access denied');
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [sId]);
        const hasIcon = fs.existsSync(path.join(resolveServerPath(sId),'server-icon.png'));
        res.render('servers/icon', await getTemplateVars(req, server, { hasIcon, title:server.name+' — Icon', activePage:'icon' }));
    } catch(e) { res.status(500).send(e.message); }
});
app.post('/servers/:id/icon', requireAuth, iconUpload.single('icon'), async (req, res) => {
    try {
        const sId = req.params.id;
        if (!await isAuthorized(req, sId)) return res.status(403).json({error:'Access denied'});
        if (!req.file) return res.status(400).json({error:'No file'});
        fs.renameSync(req.file.path, path.join(resolveServerPath(sId),'server-icon.png'));
        res.json({success:true});
    } catch(e) { res.status(500).json({error:e.message}); }
});
app.delete('/servers/:id/icon', requireAuth, async (req, res) => {
    try {
        const sId = req.params.id;
        if (!await isAuthorized(req, sId)) return res.status(403).json({error:'Access denied'});
        const fp = path.join(resolveServerPath(sId),'server-icon.png');
        if (fs.existsSync(fp)) fs.unlinkSync(fp);
        res.json({success:true});
    } catch(e) { res.status(500).json({error:e.message}); }
});
app.get('/servers/:id/icon.png', (req,res) => {
    const fp = path.join(resolveServerPath(req.params.id),'server-icon.png');
    fs.existsSync(fp) ? res.sendFile(fp) : res.status(404).send('');
});

// Version manager
app.get('/servers/:id/versions', requireAuth, async (req, res) => {
    try {
        const sId = req.params.id;
        if (!await isAuthorized(req, sId)) return res.status(403).send('Access denied');
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [sId]);
        let versions = [];
        try { const panelPort = process.env.PORT || 3000; const r = await axios.get(`http://localhost:${panelPort}/api/versions/${server.server_type||'vanilla'}?limit=30`,{timeout:4000}); versions=r.data.versions||[]; } catch(e) { versions=getCompleteMinecraftVersions().slice(0,20); }
        const versionBanners = {'1.21':{color:'#6366f1',label:'Latest',badge:'badge-info'},'1.20':{color:'#3b82f6',label:'Stable',badge:'badge-success'},'1.19':{color:'#10b981',label:'Popular',badge:'badge-success'},'1.18':{color:'#f59e0b',label:'Older',badge:'badge-warning'},'1.16':{color:'#ef4444',label:'Legacy',badge:'badge-danger'},'1.12':{color:'#64748b',label:'Classic',badge:'badge-secondary'}};
        res.render('servers/versions', await getTemplateVars(req, server, { versions, versionBanners, title:server.name+' — Versions', activePage:'versions' }));
    } catch(e) { res.status(500).send(e.message); }
});
app.post('/servers/:id/versions/switch', requireAuth, async (req, res) => {
    try {
        const sId = req.params.id;
        if (!await isAuthorized(req, sId)) return res.status(403).json({error:'Access denied'});
        const {version, server_type} = req.body;
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [sId]);
        if (server.status==='running') return res.status(400).json({error:'Stop the server first'});
        const sDir = resolveServerPath(sId);
        const jarPath = path.join(sDir,'server.jar');
        if (fs.existsSync(jarPath)) fs.renameSync(jarPath, jarPath+'.bak');
        const newType = server_type||server.server_type;
        installProgress[sId] = {step:'Starting...',percent:0,done:false,error:null};
        res.json({success:true,installing:true});
        (async()=>{ try { setInstallProgress(sId,`Downloading ${newType} ${version}...`,20); const actual=await downloadServerJar(newType,version,sDir); await dbRun('UPDATE servers SET version=?,server_type=? WHERE id=?',[actual,newType,sId]); setInstallProgress(sId,'Done!',100,true); } catch(e){ installProgress[sId]={step:'Failed: '+e.message,percent:0,done:true,error:e.message}; if(fs.existsSync(jarPath+'.bak'))fs.renameSync(jarPath+'.bak',jarPath); }})();
    } catch(e) { res.status(500).json({error:e.message}); }
});

// Egg changer
app.get('/servers/:id/egg', requireAuth, async (req, res) => {
    try {
        const sId = req.params.id;
        if (!await isAuthorized(req, sId)) return res.status(403).send('Access denied');
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [sId]);
        const eggs = [
            {key:'vanilla',name:'Vanilla',icon:'fas fa-cube',color:'#f97316',desc:'Official Mojang server',category:'Java Edition'},
            {key:'paper',name:'Paper',icon:'fas fa-scroll',color:'#3b82f6',desc:'High-performance plugin server',category:'Java Edition'},
            {key:'purpur',name:'Purpur',icon:'fas fa-gem',color:'#8b5cf6',desc:'Feature-rich Paper fork',category:'Java Edition'},
            {key:'spigot',name:'Spigot',icon:'fas fa-fire',color:'#f59e0b',desc:'Classic plugin server',category:'Java Edition'},
            {key:'fabric',name:'Fabric',icon:'fas fa-cut',color:'#10b981',desc:'Lightweight mod loader',category:'Java Edition'},
            {key:'forge',name:'Forge',icon:'fas fa-hammer',color:'#ef4444',desc:'Heavy mod platform',category:'Java Edition'},
            {key:'mohist',name:'Mohist',icon:'fas fa-layer-group',color:'#06b6d4',desc:'Forge+Bukkit hybrid',category:'Java Edition'},
            {key:'velocity',name:'Velocity',icon:'fas fa-rocket',color:'#a855f7',desc:'Modern proxy',category:'Proxy'},
            {key:'bungeecord',name:'BungeeCord',icon:'fas fa-network-wired',color:'#f43f5e',desc:'Classic proxy',category:'Proxy'},
            {key:'waterfall',name:'Waterfall',icon:'fas fa-water',color:'#2563eb',desc:'Optimized BungeeCord',category:'Proxy'},
            {key:'bedrock',name:'Bedrock',icon:'fas fa-mobile-alt',color:'#16a34a',desc:'Cross-platform server',category:'Bedrock'},
        ];
        res.render('servers/egg', await getTemplateVars(req, server, { eggs, title:server.name+' — Egg Changer', activePage:'egg' }));
    } catch(e) { res.status(500).send(e.message); }
});
app.post('/servers/:id/egg/switch', requireAuth, async (req, res) => {
    try {
        const sId = req.params.id;
        if (!await isAuthorized(req, sId)) return res.status(403).json({error:'Access denied'});
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [sId]);
        if (server.status==='running') return res.status(400).json({error:'Stop the server first'});
        await dbRun('UPDATE servers SET server_type=? WHERE id=?',[req.body.egg,sId]);
        res.json({success:true,message:`Changed to ${req.body.egg}`});
    } catch(e) { res.status(500).json({error:e.message}); }
});

// ================================================
// MODS MARKETPLACE
// ================================================
app.get('/servers/:id/mods/marketplace', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        console.log('Mods marketplace route: serverId:', serverId);
        if (!await isAuthorized(req, serverId)) return res.status(403).send('Access denied');
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        console.log('Mods marketplace route: server:', server);
        if (!server) return res.status(404).send('Server not found');
        const query = req.query.q || '';
        const loader = req.query.loader || (server.server_type === 'fabric' ? 'fabric' : server.server_type === 'forge' ? 'forge' : server.server_type === 'quilt' ? 'quilt' : server.server_type === 'neoforge' ? 'neoforge' : 'fabric');
        const gameVersion = server.version || '1.21.1';
        let mods = [];
        try {
            const r = await axios.get('https://api.modrinth.com/v2/search', {
                params: { query, facets: JSON.stringify([['project_type:mod'], [`categories:${loader}`]]), limit: 20, index: 'relevance' },
                headers: { 'User-Agent': 'MinecraftPanel/1.0' }, timeout: 8000
            });
            mods = r.data.hits || [];
        } catch(e) { 
            console.error('Modrinth mods error:', e.message); 
        }
        res.render('servers/mods_marketplace', await getTemplateVars(req, server, { mods, query, loader, gameVersion, title: server.name + ' — Mods Marketplace', activePage: 'mods' }));
    } catch(err) { 
        console.error('Mods marketplace route error:', err);
        res.status(500).send(err.message); 
    }
});

app.post('/servers/:id/mods/marketplace/install', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { projectId, versionId, filename } = req.body;
        const serverDir = resolveServerPath(serverId);
        const modsDir = path.join(serverDir, 'mods');
        fs.mkdirSync(modsDir, { recursive: true });
        // Get download URL from Modrinth
        let downloadUrl;
        if (versionId) {
            const vr = await axios.get(`https://api.modrinth.com/v2/version/${versionId}`, { headers: { 'User-Agent': 'MinecraftPanel/1.0' } });
            const file = vr.data.files.find(f => f.primary) || vr.data.files[0];
            downloadUrl = (file && file.url) || undefined;
        } else {
            const vr = await axios.get(`https://api.modrinth.com/v2/project/${projectId}/version`, { params: { loaders: '["fabric","forge"]', game_versions: '[]' }, headers: { 'User-Agent': 'MinecraftPanel/1.0' } });
            let file;
            if (vr.data && vr.data[0]) {
                if (vr.data[0].files) {
                    file = vr.data[0].files.find(f => f.primary) || vr.data[0].files[0];
                }
            }
            downloadUrl = (file && file.url) || undefined;
        }
        if (!downloadUrl) return res.status(400).json({ error: 'No download URL found' });
        const destName = filename || `${projectId}.jar`;
        const dest = path.join(modsDir, sanitize(destName));
        const writer = fs.createWriteStream(dest);
        const response = await axios({ url: downloadUrl, method: 'GET', responseType: 'stream', headers: { 'User-Agent': 'MinecraftPanel/1.0' } });
        await new Promise((resolve, reject) => { response.data.pipe(writer); writer.on('finish', resolve); writer.on('error', reject); });
        res.json({ success: true, filename: destName });
    } catch(err) { res.status(500).json({ error: err.message }); }
});

};
