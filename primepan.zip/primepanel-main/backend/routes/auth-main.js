const bcrypt = require('bcryptjs');

module.exports = function(app, deps) {
    const { 
        dbGet, dbAll, dbRun, db,
        globalSettings, liveStats, serverProcesses, onlinePlayers,
        requireAuth, requireAdmin, isAuthorized,
        getTemplateVars,
        isServerRunning, startServer, stopServer, restartServer, sendCommand,
        fetchMinecraftVersions, getAvailableServerSoftware
    } = deps;

    // ================================================
    // AUTH ROUTES
    // ================================================
    app.get('/auth/login', async (req, res) => {
        if (req.session.user) return res.redirect('/dashboard');
        res.render('auth/login', await getTemplateVars(req, null, { error: null, title: 'Login' }));
    });
    app.post('/auth/login', async (req, res) => {
        const { username, password } = req.body;
    
        try {
            const user = await dbGet('SELECT * FROM users WHERE username = ?', [username]);
        
            if (!user) {
                return res.render('auth/login', await getTemplateVars(req, null, { error: 'Invalid username or password', title: 'Login' }));
            }
        
            if (user.status === 'suspended') {
                return res.render('auth/login', await getTemplateVars(req, null, { error: 'Account suspended', title: 'Login' }));
            }
        
            const validPassword = await bcrypt.compare(password, user.password);
            if (!validPassword) {
                return res.render('auth/login', await getTemplateVars(req, null, { error: 'Invalid username or password', title: 'Login' }));
            }
        
            req.session.user = {
                id: user.id,
                username: user.username,
                email: user.email,
                role: user.role
            };
        
            res.redirect('/dashboard');
        } catch (err) {
            console.error('Login error:', err);
            res.render('auth/login', await getTemplateVars(req, null, { error: 'Server error', title: 'Login' }));
        }
    });
    app.get('/auth/register', (req, res) => {
        if (!globalSettings.registrationEnabled) {
            return res.redirect('/auth/login');
        }
        if (req.session.user) return res.redirect('/dashboard');
        res.render('auth/register', { error: null });
    });
    app.post('/auth/register', async (req, res) => {
        if (!globalSettings.registrationEnabled) {
            return res.redirect('/auth/login');
        }
    
        const { username, email, password, confirmPassword } = req.body;
    
        if (password !== confirmPassword) {
            return res.render('auth/register', { error: 'Passwords do not match' });
        }
    
        try {
            const existing = await dbGet(
                'SELECT * FROM users WHERE username = ? OR email = ?',
                [username, email]
            );
        
            if (existing) {
                return res.render('auth/register', { error: 'Username or email already exists' });
            }
        
            const hashedPassword = await bcrypt.hash(password, 10);
            await dbRun(
                'INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
                [username, email, hashedPassword]
            );
        
            res.redirect('/auth/login?success=Registration successful');
        } catch (err) {
            console.error('Registration error:', err);
            res.render('auth/register', { error: 'Registration failed' });
        }
    });
    app.get('/auth/logout', (req, res) => {
        req.session.destroy();
        res.redirect('/auth/login');
    });
    // ================================================
    // MAIN ROUTES
    // ================================================
    app.get('/', (req, res) => {
        if (req.session.user) {
            return res.redirect('/dashboard');
        }
        res.render('home', { settings: globalSettings, user: null, title: globalSettings.panelName });
    });
    app.get('/dashboard', requireAuth, async (req, res) => {
        try {
          let servers = [];
    
          if (req.session.user.role === 'admin') {
            servers = await dbAll(`
              SELECT s.*, u.username AS owner_name
              FROM servers s
              LEFT JOIN users u ON s.owner_id = u.id
              ORDER BY s.created_at DESC
            `);
          } else {
            // Get servers owned by user OR where user is a subuser
            servers = await dbAll(`
              SELECT DISTINCT s.*, u.username AS owner_name,
                     CASE WHEN s.owner_id = ? THEN 1 ELSE 0 END as is_owner
              FROM servers s
              LEFT JOIN users u ON s.owner_id = u.id
              LEFT JOIN subusers su ON s.id = su.server_id
              WHERE s.owner_id = ? OR su.user_id = ?
              ORDER BY is_owner DESC, s.created_at DESC
            `, [req.session.user.id, req.session.user.id, req.session.user.id]);
          }
    
          // ✅ ALWAYS define these so EJS never throws ReferenceError
          const onlinePlayersLocal = {};
          const messages = [];
    
          res.render('dashboard', await getTemplateVars(req, null, {
            servers,
            onlinePlayers: onlinePlayersLocal,
            messages,
            currentPage: 'dashboard',
            totalServers: servers.length,
            title: 'Dashboard'
          }));
    
        } catch (err) {
          console.error('Dashboard error:', err);
          res.status(500).render('error', await getTemplateVars(req, null, {
            message: 'Failed to load dashboard',
            status: 500,
            title: 'Error'
          }));
        }
      });
};
