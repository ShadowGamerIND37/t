const jwt = require('jsonwebtoken');
const axios = require('axios');

const { generateRandomToken } = require('../../core/helpers');

function createNodeJWT(node, scope = ['*']) {
    const payload = {
        iss: 'minecraft-panel',
        sub: node.uuid,
        jti: node.daemon_token_id,
        scopes: scope,
        iat: Math.floor(Date.now() / 1000),
        nbf: Math.floor(Date.now() / 1000),
        exp: Math.floor(Date.now() / 1000) + 300
    };
    return jwt.sign(payload, node.daemon_token, {
        header: { kid: node.daemon_token_id }
    });
}

function getNodeConnectionAddress(node) {
    return `${node.scheme}://${node.fqdn}:${node.daemon_listen}`;
}

async function wingsRequest(node, method, path, data = null) {
    const token = createNodeJWT(node);
    const baseUrl = getNodeConnectionAddress(node);

    const config = {
        method: method,
        url: `${baseUrl}${path}`,
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
    };

    if (data) {
        config.data = data;
    }

    try {
        const response = await axios(config);
        return response.data;
    } catch (error) {
        console.error('Wings request error:', error.response ? error.response.data : error.message);
        throw error;
    }
}

function generateConnectionString(node, panelUrl) {
    const payload = {
        panel_url: panelUrl.replace(/\/+$/, ''),
        node_id: node.id,
        node_uuid: node.uuid,
        token_id: node.daemon_token_id,
        token: node.daemon_token,
        timestamp: Date.now()
    };
    return Buffer.from(JSON.stringify(payload)).toString('base64');
}

function decodeConnectionString(encoded) {
    try {
        const json = Buffer.from(encoded, 'base64').toString('utf8');
        return JSON.parse(json);
    } catch {
        return null;
    }
}

module.exports = {
    createNodeJWT,
    getNodeConnectionAddress,
    wingsRequest,
    generateRandomToken,
    generateConnectionString,
    decodeConnectionString
};
