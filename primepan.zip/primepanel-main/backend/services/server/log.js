const fs = require('fs');
const path = require('path');
const { resolveServerPath } = require('../../core/helpers');

function processLogLine(serverId, line, onlinePlayers, io) {
    if (!onlinePlayers[serverId]) {
        onlinePlayers[serverId] = [];
    }

    const joinedMatch = line.match(/\[.*?\].*?:\s*(\w+)\s+joined the game/i);
    if (joinedMatch) {
        const player = joinedMatch[1];
        if (!onlinePlayers[serverId].includes(player)) {
            onlinePlayers[serverId].push(player);
            if (io) {
                io.to(`server:${serverId}`).emit('playerJoined', {
                    player: player,
                    onlinePlayers: onlinePlayers[serverId],
                    count: onlinePlayers[serverId].length
                });
            }
        }
    }

    const leftMatch = line.match(/\[.*?\].*?:\s*(\w+)\s+left the game/i);
    if (leftMatch) {
        const player = leftMatch[1];
        onlinePlayers[serverId] = onlinePlayers[serverId].filter(p => p !== player);
        if (io) {
            io.to(`server:${serverId}`).emit('playerLeft', {
                player: player,
                onlinePlayers: onlinePlayers[serverId],
                count: onlinePlayers[serverId].length
            });
        }
    }

    const listMatch = line.match(/There are \d+(?:\/| of a max of )\d+ players online:\s*(.*)/i);
    if (listMatch) {
        const playerList = listMatch[1].trim();
        if (playerList && playerList !== '') {
            const players = playerList.split(',').map(p => p.trim()).filter(p => p && p !== '');
            onlinePlayers[serverId] = players;
        } else {
            onlinePlayers[serverId] = [];
        }
        if (io) {
            io.to(`server:${serverId}`).emit('playersUpdated', {
                onlinePlayers: onlinePlayers[serverId],
                count: onlinePlayers[serverId].length
            });
        }
    }
}

function startLogTail(serverId, serverProcesses, serverLogWatchers, serverLogPositions, onlinePlayersRef, ioRef) {
    const serverDir = resolveServerPath(serverId);
    const logPath = path.join(serverDir, 'logs', 'latest.log');

    if (!fs.existsSync(path.dirname(logPath))) {
        fs.mkdirSync(path.dirname(logPath), { recursive: true });
    }
    if (!fs.existsSync(logPath)) {
        fs.writeFileSync(logPath, '');
    }

    if (!serverLogPositions[serverId]) serverLogPositions[serverId] = 0;

    const readNewLines = () => {
        let stats;
        try {
            stats = fs.statSync(logPath);
        } catch {
            return;
        }
        if (stats.size < serverLogPositions[serverId]) {
            serverLogPositions[serverId] = 0;
        }
        if (stats.size > serverLogPositions[serverId]) {
            const stream = fs.createReadStream(logPath, {
                start: serverLogPositions[serverId],
                end: stats.size
            });
            let buffer = '';
            stream.on('data', (chunk) => {
                buffer += chunk.toString('utf8');
            });
            stream.on('end', () => {
                const lines = buffer.split('\n');
                for (let line of lines) {
                    if (line.trim()) {
                        if (ioRef) ioRef.to(`server:${serverId}`).emit('console', line + '\n');
                        processLogLine(serverId, line, onlinePlayersRef, ioRef);
                    }
                }
                serverLogPositions[serverId] = stats.size;
            });
        }
    };

    const serverProcess = serverProcesses[serverId];
    if (serverProcess && serverProcess.stdout) {
        serverProcess.stdout.on('data', (data) => {
            const output = data.toString();
            if (ioRef) ioRef.to(`server:${serverId}`).emit('console', output);
            output.split('\n').forEach(line => {
                if (line.trim()) processLogLine(serverId, line, onlinePlayersRef, ioRef);
            });
        });

        serverProcess.stderr.on('data', (data) => {
            const output = data.toString();
            if (ioRef) ioRef.to(`server:${serverId}`).emit('console', output);
        });
    }

    readNewLines();
    const watcher = fs.watch(logPath, (eventType) => {
        if (eventType === 'change') {
            readNewLines();
        }
    });

    watcher.on('error', (err) => {
        try { watcher.close(); } catch (e) { }
        delete serverLogWatchers[serverId];
    });

    serverLogWatchers[serverId] = watcher;
}

module.exports = {
    processLogLine,
    startLogTail
};
