const fs = require('fs');
const path = require('path');
const net = require('net');

const { dbGet, dbAll, dbRun } = require('../../core/database');
const { resolveServerPath, parseProperties, writeProperties, writePropertiesString, generateRandomSecret } = require('../../core/helpers');
const { PORT_CONFIG, getPortRangeForServerType } = require('../../config/ports');

async function findAvailablePortForServerType(serverType) {
    try {
        const portRange = getPortRangeForServerType(serverType);
        const usedPorts = await dbAll('SELECT port FROM servers WHERE port IS NOT NULL');
        const usedPortNumbers = usedPorts.map(row => parseInt(row.port));
        usedPortNumbers.push(...PORT_CONFIG.RESERVED_PORTS);

        for (let port = portRange.START_PORT; port <= portRange.MAX_PORT; port++) {
            if (!usedPortNumbers.includes(port)) {
                if (await isPortAvailable(port)) {
                    return port;
                }
            }
        }

        throw new Error(`No available ports in ${portRange.CATEGORY} range (${portRange.START_PORT}-${portRange.MAX_PORT})`);
    } catch (err) {
        throw new Error(`Failed to find available port for ${serverType}: ${err.message}`);
    }
}

function isPortAvailable(port) {
    return new Promise((resolve) => {
        const server = net.createServer();
        server.listen(port, '0.0.0.0', (err) => {
            if (err) {
                resolve(false);
            } else {
                server.once('close', () => resolve(true));
                server.close();
            }
        });
        server.on('error', () => resolve(false));
        setTimeout(() => {
            try { server.close(); } catch (e) { }
            resolve(false);
        }, 2000);
    });
}

async function ensureServerPortForType(serverId, serverType) {
    try {
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) throw new Error('Server not found');

        const portRange = getPortRangeForServerType(serverType);
        let assignedPort = server.port;
        const isPortInCorrectRange = assignedPort >= portRange.START_PORT && assignedPort <= portRange.MAX_PORT;

        if (!assignedPort || !isPortInCorrectRange || !(await isPortAvailable(assignedPort))) {
            assignedPort = await findAvailablePortForServerType(serverType);
            await dbRun('UPDATE servers SET port = ? WHERE id = ?', [assignedPort, serverId]);
        }

        await updateServerConfigurationPort(serverId, serverType, assignedPort);
        return assignedPort;
    } catch (err) {
        throw err;
    }
}

async function updateServerConfigurationPort(serverId, serverType, port) {
    try {
        const serverDir = resolveServerPath(serverId);

        if (['velocity', 'bungeecord', 'waterfall'].includes(serverType)) {
            await updateProxyServerPort(serverId, serverType, port);
        } else if (['bedrock', 'nukkit'].includes(serverType)) {
            await updateBedrockServerPort(serverId, serverType, port);
        } else {
            await updateServerPropertiesPort(serverId, port);
        }
    } catch (err) {
        throw err;
    }
}

async function updateProxyServerPort(serverId, serverType, port) {
    const serverDir = resolveServerPath(serverId);

    if (serverType === 'velocity') {
        const configPath = path.join(serverDir, 'velocity.toml');
        let config = '';

        if (fs.existsSync(configPath)) {
            config = fs.readFileSync(configPath, 'utf8');
            config = config.replace(/bind\s*=\s*"[^"]*"/g, `bind = "0.0.0.0:${port}"`);
        } else {
            config = `bind = "0.0.0.0:${port}"\nshow-ping-requests = true\nannounce-forge = false\nonline-mode = true\nplayer-info-forwarding-mode = "MODERN"\nforwarding-secret = "${generateRandomSecret()}"\n\n[servers]\ntry = ["lobby"]\n\n[advanced]\ncompression-threshold = 256\ncompression-level = -1`;
        }

        fs.writeFileSync(configPath, config, 'utf8');
    } else if (serverType === 'bungeecord' || serverType === 'waterfall') {
        const configPath = path.join(serverDir, 'config.yml');
        let config = '';

        if (fs.existsSync(configPath)) {
            config = fs.readFileSync(configPath, 'utf8');
            config = config.replace(/host:\s*[^\n\r]*/g, `host: 0.0.0.0:${port}`);
        } else {
            config = `host: 0.0.0.0:${port}\ntimeout: 5000\nlog_commands: false\nonline_mode: true\nplayer_limit: -1`;
        }

        fs.writeFileSync(configPath, config, 'utf8');
    }
}

async function updateBedrockServerPort(serverId, serverType, port) {
    const serverDir = resolveServerPath(serverId);

    if (serverType === 'bedrock') {
        const configPath = path.join(serverDir, 'server.properties');
        let properties = {};

        if (fs.existsSync(configPath)) {
            const content = fs.readFileSync(configPath, 'utf8');
            properties = parseProperties(content);
        }

        properties['server-port'] = port;
        properties['server-portv6'] = port;
        writeProperties(properties, configPath);
    } else if (serverType === 'nukkit') {
        const configPath = path.join(serverDir, 'nukkit.yml');
        let config = '';

        if (fs.existsSync(configPath)) {
            config = fs.readFileSync(configPath, 'utf8');
            config = config.replace(/server-port:\s*\d+/g, `server-port: ${port}`);
        } else {
            config = `server-port: ${port}\nserver-ip: "0.0.0.0"\ngamemode: 0\nmax-players: 20`;
        }

        fs.writeFileSync(configPath, config, 'utf8');
    }
}

async function updateServerPropertiesPort(serverId, port) {
    try {
        const propertiesPath = resolveServerPath(serverId, 'server.properties');
        let properties = {};

        if (fs.existsSync(propertiesPath)) {
            try {
                const content = fs.readFileSync(propertiesPath, 'utf8');
                properties = parseProperties(content);
            } catch (err) { }
        }

        properties['server-port'] = port;
        if (!properties['server-ip']) properties['server-ip'] = '';
        if (!properties['max-players']) properties['max-players'] = 20;
        if (!properties['online-mode']) properties['online-mode'] = true;
        if (!properties['view-distance']) properties['view-distance'] = 10;
        if (!properties['simulation-distance']) properties['simulation-distance'] = 10;
        if (!properties['motd']) {
            const server = await dbGet('SELECT name FROM servers WHERE id = ?', [serverId]);
            properties['motd'] = server ? server.name : 'Minecraft Server';
        }

        writeProperties(properties, propertiesPath);
    } catch (err) {
        throw err;
    }
}

// Sanitize functions
function sanitizeServerProperties(content, serverPort) {
    try {
        const properties = parseProperties(content);
        properties['server-port'] = serverPort;
        return writePropertiesString(properties);
    } catch (err) {
        throw err;
    }
}

function sanitizeVelocityToml(content, serverPort) {
    try {
        const bindRegex = /bind\s*=\s*"[^"]*"/g;
        const correctBind = `bind = "0.0.0.0:${serverPort}"`;

        if (bindRegex.test(content)) {
            content = content.replace(bindRegex, correctBind);
        } else {
            const lines = content.split('\n');
            const insertIndex = lines.findIndex(line => line.trim() && !line.trim().startsWith('#'));
            if (insertIndex >= 0) {
                lines.splice(insertIndex, 0, correctBind);
            } else {
                lines.unshift(correctBind);
            }
            content = lines.join('\n');
        }

        return content;
    } catch (err) {
        throw err;
    }
}

function sanitizeBungeeCordConfig(content, serverPort) {
    try {
        const hostRegex = /host:\s*([^:]+):(\d+)/g;
        content = content.replace(hostRegex, () => `host: 0.0.0.0:${serverPort}`);

        const listenRegex = /listen:\s*([^:]+):(\d+)/g;
        content = content.replace(listenRegex, () => `listen: 0.0.0.0:${serverPort}`);

        const bindLocalRegex = /bind_local_address:\s*([^:]+):(\d+)/g;
        content = content.replace(bindLocalRegex, () => `bind_local_address: 0.0.0.0:${serverPort}`);

        return content;
    } catch (err) {
        throw err;
    }
}

// Port enforcement
async function enforceProxyServerPort(serverId, serverType, correctPort) {
    try {
        const serverDir = resolveServerPath(serverId);

        if (serverType === 'velocity') {
            const configPath = path.join(serverDir, 'velocity.toml');
            if (fs.existsSync(configPath)) {
                let content = fs.readFileSync(configPath, 'utf8');
                content = sanitizeVelocityToml(content, correctPort);
                fs.writeFileSync(configPath, content, 'utf8');
            } else {
                const config = `bind = "0.0.0.0:${correctPort}"\nshow-ping-requests = true\nonline-mode = true\nplayer-info-forwarding-mode = "MODERN"\nforwarding-secret = "${generateRandomSecret()}"`;
                fs.writeFileSync(configPath, config, 'utf8');
            }
        } else if (serverType === 'bungeecord' || serverType === 'waterfall') {
            const configPath = path.join(serverDir, 'config.yml');
            if (fs.existsSync(configPath)) {
                let content = fs.readFileSync(configPath, 'utf8');
                content = sanitizeBungeeCordConfig(content, correctPort);
                fs.writeFileSync(configPath, content, 'utf8');
            } else {
                const config = `listeners:\n- query_port: ${correctPort}\n  host: 0.0.0.0:${correctPort}\n  max_players: 100\ntimeout: 30000\nplayer_limit: -1\nonline_mode: true`;
                fs.writeFileSync(configPath, config, 'utf8');
            }
        }
    } catch (err) {
        throw err;
    }
}

async function enforceMinecraftServerPort(serverId, correctPort) {
    try {
        const serverDir = resolveServerPath(serverId);
        const configPath = path.join(serverDir, 'server.properties');

        if (fs.existsSync(configPath)) {
            let content = fs.readFileSync(configPath, 'utf8');
            content = sanitizeServerProperties(content, correctPort);
            fs.writeFileSync(configPath, content, 'utf8');
        }
    } catch (err) {
        throw err;
    }
}

// Port info
function getPortInformation(serverId, serverType, port) {
    const portRange = getPortRangeForServerType(serverType);
    const validation = validatePortForServerType(port, serverType);

    return {
        port,
        serverType,
        category: portRange.CATEGORY,
        range: `${portRange.START_PORT}-${portRange.MAX_PORT}`,
        defaultPort: portRange.DEFAULT_PORT,
        isValid: validation.valid,
        isInCorrectRange: port >= portRange.START_PORT && port <= portRange.MAX_PORT,
        isReserved: PORT_CONFIG.RESERVED_PORTS.includes(port),
        message: validation.message,
        protectionLevel: getProtectionLevel(serverType),
        protectionDescription: getProtectionDescription(serverType)
    };
}

function validatePortForServerType(port, serverType) {
    const portRange = getPortRangeForServerType(serverType);

    if (port < portRange.START_PORT || port > portRange.MAX_PORT) {
        return {
            valid: false,
            message: `Port must be in ${portRange.CATEGORY} range (${portRange.START_PORT}-${portRange.MAX_PORT})`,
            suggestedPort: portRange.DEFAULT_PORT
        };
    }

    if (PORT_CONFIG.RESERVED_PORTS.includes(port)) {
        return {
            valid: false,
            message: `Port ${port} is reserved for system use`,
            suggestedPort: portRange.DEFAULT_PORT
        };
    }

    return { valid: true, message: `Port ${port} is valid for ${portRange.CATEGORY}`, portRange };
}

function getProtectionLevel(serverType) {
    if (['velocity', 'bungeecord', 'waterfall'].includes(serverType)) return 'High Protection';
    if (['bedrock', 'nukkit'].includes(serverType)) return 'Medium Protection';
    return 'Standard Protection';
}

function getProtectionDescription(serverType) {
    if (['velocity', 'bungeecord', 'waterfall'].includes(serverType)) {
        return 'Proxy servers use dedicated port range (25700-25799) for network isolation and security';
    }
    if (['bedrock', 'nukkit'].includes(serverType)) {
        return 'Bedrock servers use UDP protocol on dedicated range (19132-19232)';
    }
    return 'Java Edition servers use standard Minecraft port range (25565-25665)';
}

async function validateAndFixAllServerPorts() {
    try {
        const servers = await dbAll('SELECT id, server_type, port, name FROM servers');
        let fixedCount = 0, validCount = 0, preservedCount = 0;

        for (const server of servers) {
            const portRange = getPortRangeForServerType(server.server_type);
            const isInCorrectRange = server.port >= portRange.START_PORT && server.port <= portRange.MAX_PORT;
            const isReservedPort = PORT_CONFIG.RESERVED_PORTS.includes(server.port);

            if (isReservedPort) {
                const newPort = await ensureServerPortForType(server.id, server.server_type);
                fixedCount++;
            } else if (isInCorrectRange) {
                validCount++;
            } else {
                preservedCount++;
            }
        }

        return { validCount, fixedCount, preservedCount, totalCount: servers.length };
    } catch (err) {
        throw err;
    }
}

module.exports = {
    findAvailablePortForServerType,
    isPortAvailable,
    ensureServerPortForType,
    updateServerConfigurationPort,
    updateProxyServerPort,
    updateBedrockServerPort,
    updateServerPropertiesPort,
    sanitizeServerProperties,
    sanitizeVelocityToml,
    sanitizeBungeeCordConfig,
    enforceProxyServerPort,
    enforceMinecraftServerPort,
    getPortInformation,
    validatePortForServerType,
    validateAndFixAllServerPorts,
    getProtectionLevel,
    getProtectionDescription
};
