const { spawn, exec } = require('child_process');
const util = require('util');
const execAsync = util.promisify(exec);
const fs = require('fs');
const path = require('path');
const pidusage = require('pidusage');
const os = require('os');

const { dbGet, dbRun, dbAll } = require('../../core/database');
const { resolveServerPath } = require('../../core/helpers');
const { SERVERS_DIR } = require('../../config');

let serverProcesses = {};
let serverStartTimes = {};
let onlinePlayers = {};
let serverLogWatchers = {};
let serverLogPositions = {};
const totalBandwidthUsed = {};
let io = null;

function setSocketIO(socketIO) {
    io = socketIO;
}

function getServerProcesses() {
    return serverProcesses;
}

function getServerStartTimes() {
    return serverStartTimes;
}

function getOnlinePlayers() {
    return onlinePlayers;
}

async function isServerRunning(serverId) {
    try {
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return false;

        // For wings nodes, check DB status (daemon reports via heartbeats)
        if (server.node_id) {
            const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
            if (node && node.mode === 'wings') {
                return server.status === 'running';
            }
        }

        const serverProcess = serverProcesses[serverId];
        if (serverProcess && !serverProcess.killed) {
            return true;
        }

        const serverDir = resolveServerPath(serverId);
        const pidFile = path.join(serverDir, '.server.pid');

        if (fs.existsSync(pidFile)) {
            try {
                const pid = parseInt(fs.readFileSync(pidFile, 'utf8').trim());
                if (isProcessRunning(pid)) {
                    if (await isJavaProcess(pid)) {
                        return true;
                    }
                } else {
                    fs.unlinkSync(pidFile);
                }
            } catch (err) {
                // Ignore
            }
        }

        const pid = await getPidByPort(server.port);
        if (pid) {
            try {
                fs.writeFileSync(pidFile, pid.toString());
            } catch (err) {
                // Ignore
            }
            return true;
        }

        return false;
    } catch (err) {
        return false;
    }
}

function isProcessRunning(pid) {
    try {
        process.kill(pid, 0);
        return true;
    } catch (err) {
        return false;
    }
}

async function isJavaProcess(pid) {
    try {
        if (os.platform() === 'win32') {
            const { stdout } = await execAsync(`tasklist /FI "PID eq ${pid}" /FO CSV /NH`);
            return stdout.toLowerCase().includes('java');
        } else {
            const { stdout } = await execAsync(`ps -p ${pid} -o comm=`);
            return stdout.toLowerCase().includes('java');
        }
    } catch (err) {
        return false;
    }
}

async function getPidByPort(port) {
    try {
        if (os.platform() === 'win32') {
            const { stdout } = await execAsync(`netstat -ano | findstr :${port}`);
            const lines = stdout.trim().split('\n');
            for (const line of lines) {
                if (line.includes('LISTENING')) {
                    const parts = line.trim().split(/\s+/);
                    const pid = parseInt(parts[parts.length - 1]);
                    if (!isNaN(pid) && pid > 0) {
                        try {
                            const { stdout: taskList } = await execAsync(`tasklist /FI "PID eq ${pid}" /FO CSV /NH`);
                            if (taskList.toLowerCase().includes('java')) {
                                return pid;
                            }
                        } catch (err) { }
                    }
                }
            }
            return null;
        } else {
            const { stdout } = await execAsync(`lsof -iTCP:${port} -sTCP:LISTEN -t`);
            const pid = parseInt(stdout.trim());
            return isNaN(pid) ? null : pid;
        }
    } catch (err) {
        return null;
    }
}

async function startServer(serverId) {
    const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
    if (!server) throw new Error('Server not found');

    // If server is on a wings node, queue command for the remote daemon
    if (server.node_id) {
        const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
        if (node && node.mode === 'wings') {
            await dbRun(
                'INSERT INTO server_commands (node_id, server_id, action) VALUES (?, ?, ?)',
                [node.id, serverId, 'start']
            );
            console.log(`[Daemon] Queued start for server ${serverId} on node ${node.name}`);
            return { queued: true, message: 'Start command sent to remote node' };
        }
    }

    const assignedPort = server.port;

    if (await isServerRunning(serverId)) {
        throw new Error('Server already running');
    }

    const serverDir = resolveServerPath(serverId);

    // Check for world lock file
    const worldLockFile = path.join(serverDir, 'world', 'session.lock');
    if (fs.existsSync(worldLockFile)) {
        try {
            fs.unlinkSync(worldLockFile);
        } catch (err) {
            throw new Error('Server world is locked by another process.');
        }
    }

    let serverExecutable;
    let javaPath = 'java';
    let javaArgs = [];

    if (server.server_type === 'bedrock') {
        if (process.platform === 'win32') {
            serverExecutable = path.join(serverDir, 'bedrock_server.exe');
            if (!fs.existsSync(serverExecutable)) {
                const { downloadServerJar } = require('./download');
                await downloadServerJar(server.server_type, server.version, serverDir);
            }
            javaPath = serverExecutable;
            javaArgs = [];
        } else {
            serverExecutable = path.join(serverDir, 'bedrock_server');
            if (!fs.existsSync(serverExecutable)) {
                const { downloadServerJar } = require('./download');
                await downloadServerJar(server.server_type, server.version, serverDir);
            }
            javaPath = serverExecutable;
            javaArgs = [];
        }
    } else {
        const serverJarPath = path.join(serverDir, 'server.jar');
        if (!fs.existsSync(serverJarPath)) {
            const { downloadServerJar } = require('./download');
            await downloadServerJar(server.server_type, server.version, serverDir);
        }

        if (process.platform === 'win32') {
            const javaPaths = ['java', 'java.exe'];
            let javaFound = false;
            for (const testPath of javaPaths) {
                try {
                    const javaVersionOutput = await execAsync(`${testPath} -version`);
                    javaPath = testPath;
                    javaFound = true;
                    break;
                } catch (err) { }
            }
            if (!javaFound) {
                throw new Error('Java not found. Please install Java.');
            }
        }

        const xms = Math.max(256, Math.floor(server.ram / 4));
        const settings = JSON.parse(server.settings || '{}');
        javaArgs = ['-Xms' + xms + 'M', '-Xmx' + server.ram + 'M', '-jar', 'server.jar', 'nogui'];

        if (settings.startup) {
            const customArgs = settings.startup.split(' ').filter(arg => arg.trim());
            if (customArgs[0] === 'java' || customArgs[0] === 'java.exe') {
                javaArgs = customArgs.slice(1);
            } else {
                javaArgs = customArgs;
            }
        }
    }

    const serverProcess = spawn(javaPath, javaArgs, {
        cwd: serverDir,
        detached: true,
        stdio: ['pipe', 'pipe', 'pipe']
    });

    serverProcess.unref();
    serverProcesses[serverId] = serverProcess;

    const pidFile = path.join(serverDir, '.server.pid');
    try {
        fs.writeFileSync(pidFile, serverProcess.pid.toString());
    } catch (err) { }

    serverProcess.on('error', (err) => {
        delete serverProcesses[serverId];
    });

    serverProcess.on('exit', async (code, signal) => {
        const startTime = serverStartTimes[serverId] || Date.now();
        const uptime = Date.now() - startTime;
        const crashedImmediately = uptime < 10000;

        const pidFile = path.join(serverDir, '.server.pid');
        try { if (fs.existsSync(pidFile)) fs.unlinkSync(pidFile); } catch (err) { }
        deleteServerStartTime(serverId);

        try {
            const worldLockFile = path.join(serverDir, 'world', 'session.lock');
            if (fs.existsSync(worldLockFile)) fs.unlinkSync(worldLockFile);
        } catch (err) { }

        delete serverProcesses[serverId];
        delete serverStartTimes[serverId];
        onlinePlayers[serverId] = [];
        await dbRun('UPDATE servers SET status = ? WHERE id = ?', ['stopped', serverId]);

        if (code === 1 && io) {
            io.to(`server:${serverId}`).emit('console', '\n[PANEL ERROR] Server failed to start with exit code 1\n');
        }

        try {
            const serverData = await dbGet('SELECT settings FROM servers WHERE id = ?', [serverId]);
            const settings = JSON.parse((serverData && serverData.settings) || '{}');

            if (settings.autoRestart && code !== 0 && code !== null && !crashedImmediately) {
                setTimeout(() => {
                    startServer(serverId).catch(err => console.error('Auto-restart failed:', err));
                }, 5000);
            }
        } catch (err) { }
    });

    serverProcess.stderr.on('data', (data) => {
        const output = data.toString();
    });

    serverProcess.unref();

    await dbRun('UPDATE servers SET status = ? WHERE id = ?', ['running', serverId]);
    serverStartTimes[serverId] = Date.now();
    saveServerStartTime(serverId, serverStartTimes[serverId]);
    onlinePlayers[serverId] = [];
    const { startLogTail } = require('./log');
    startLogTail(serverId, serverProcesses, serverLogWatchers, serverLogPositions, onlinePlayers, io);
}

function saveServerStartTime(serverId, startTime) {
    try {
        const serverDir = resolveServerPath(serverId);
        const startTimeFile = path.join(serverDir, '.server.starttime');
        fs.writeFileSync(startTimeFile, startTime.toString());
    } catch (err) { }
}

function loadServerStartTime(serverId) {
    try {
        const serverDir = resolveServerPath(serverId);
        const startTimeFile = path.join(serverDir, '.server.starttime');
        if (fs.existsSync(startTimeFile)) {
            const startTime = parseInt(fs.readFileSync(startTimeFile, 'utf8').trim());
            if (!isNaN(startTime) && startTime > 0) return startTime;
        }
    } catch (err) { }
    return null;
}

function deleteServerStartTime(serverId) {
    try {
        const serverDir = resolveServerPath(serverId);
        const startTimeFile = path.join(serverDir, '.server.starttime');
        if (fs.existsSync(startTimeFile)) fs.unlinkSync(startTimeFile);
    } catch (err) { }
}

async function stopServer(serverId, force = false) {
    if (!await isServerRunning(serverId)) {
        // If server is on a wings node, queue stop anyway (daemon handles it)
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (server && server.node_id) {
            const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
            if (node && node.mode === 'wings') {
                await dbRun(
                    'INSERT INTO server_commands (node_id, server_id, action) VALUES (?, ?, ?)',
                    [node.id, serverId, 'stop']
                );
                console.log(`[Daemon] Queued stop for server ${serverId} on node ${node.name}`);
                return true;
            }
        }
        return false;
    }

    // If server is on a wings node, queue stop command instead of running locally
    const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
    if (server && server.node_id) {
        const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
        if (node && node.mode === 'wings') {
            await dbRun(
                'INSERT INTO server_commands (node_id, server_id, action) VALUES (?, ?, ?)',
                [node.id, serverId, 'stop']
            );
            console.log(`[Daemon] Queued stop for server ${serverId} on node ${node.name}`);
            return true;
        }
    }

    try {
        const serverDir = resolveServerPath(serverId);
        const pidFile = path.join(serverDir, '.server.pid');
        const serverProcess = serverProcesses[serverId];

        let pid = null;
        let stoppedGracefully = false;

        if (serverProcess && !serverProcess.killed) {
            pid = serverProcess.pid;
        } else if (fs.existsSync(pidFile)) {
            try {
                pid = parseInt(fs.readFileSync(pidFile, 'utf8').trim());
            } catch (err) { }
        }

        if (!pid) return false;
        if (!isProcessRunning(pid)) {
            if (serverProcess) delete serverProcesses[serverId];
            if (fs.existsSync(pidFile)) fs.unlinkSync(pidFile);
            deleteServerStartTime(serverId);
            onlinePlayers[serverId] = [];
            await dbRun('UPDATE servers SET status = ? WHERE id = ?', ['stopped', serverId]);
            return true;
        }

        if (force) {
            try {
                process.kill(pid, 'SIGKILL');
            } catch (err) { }
        } else {
            try {
                if (serverProcess && serverProcess.stdin && serverProcess.stdin.writable) {
                    serverProcess.stdin.write('stop\n');
                } else {
                    process.kill(pid, 'SIGTERM');
                }
                // Wait up to 30 seconds for graceful shutdown
                const maxWaitTime = 30000;
                const checkInterval = 1000;
                let waited = 0;

                const checkStopped = setInterval(() => {
                    waited += checkInterval;
                    if (!isProcessRunning(pid)) {
                        clearInterval(checkStopped);
                        stoppedGracefully = true;
                    } else if (waited >= maxWaitTime) {
                        clearInterval(checkStopped);
                        try { process.kill(pid, 'SIGKILL'); } catch (err) { }
                    }
                }, checkInterval);

                // Wait for interval to run
                await new Promise(resolve => setTimeout(resolve, 100));
            } catch (err) { }
        }

        try { if (fs.existsSync(pidFile)) fs.unlinkSync(pidFile); } catch (err) { }
        deleteServerStartTime(serverId);

        if (serverProcesses) delete serverProcesses[serverId];
        delete serverStartTimes[serverId];
        onlinePlayers[serverId] = [];
        await dbRun('UPDATE servers SET status = ? WHERE id = ?', ['stopped', serverId]);

        if (serverLogWatchers[serverId]) {
            serverLogWatchers[serverId].close();
            delete serverLogWatchers[serverId];
        }
        delete serverLogPositions[serverId];
        return true;
    } catch (err) {
        return false;
    }
}

async function restartServer(serverId) {
    const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
    if (server && server.node_id) {
        const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
        if (node && node.mode === 'wings') {
            await dbRun(
                'INSERT INTO server_commands (node_id, server_id, action) VALUES (?, ?, ?)',
                [node.id, serverId, 'restart']
            );
            console.log(`[Daemon] Queued restart for server ${serverId} on node ${node.name}`);
            return true;
        }
    }
    await stopServer(serverId, true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    await startServer(serverId);
    return true;
}

// EULA
function checkAndAcceptEula(serverId, accept = false) {
    try {
        const serverDir = resolveServerPath(serverId);
        const eulaPath = path.join(serverDir, 'eula.txt');

        if (!fs.existsSync(eulaPath)) {
            fs.writeFileSync(eulaPath, 'eula=false\n', 'utf8');
            return { accepted: false, exists: true };
        }

        const content = fs.readFileSync(eulaPath, 'utf8');
        const isAccepted = /eula\s*=\s*true/i.test(content);

        if (accept && !isAccepted) {
            const newContent = content.replace(/eula\s*=\s*false/i, 'eula=true');
            fs.writeFileSync(eulaPath, newContent, 'utf8');
            return { accepted: true, exists: true };
        }

        return { accepted: isAccepted, exists: true };
    } catch (err) {
        return { accepted: false, exists: false, error: err.message };
    }
}

// Transfer server between nodes
async function transferServer(serverId, newNodeId) {
    try {
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) throw new Error('Server not found');

        const newNode = await dbGet('SELECT * FROM nodes WHERE id = ?', [newNodeId]);
        if (!newNode) throw new Error('Node not found');

        if (await isServerRunning(serverId)) {
            await stopServer(serverId);
        }

        await dbRun('UPDATE servers SET node_id = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', [newNodeId, serverId]);
        return { success: true, message: 'Server transferred successfully' };
    } catch (err) {
        return { success: false, error: err.message };
    }
}

// RCON auto-enable
async function autoEnableRcon(serverId) {
    try {
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return false;

        const propertiesPath = resolveServerPath(serverId, 'server.properties');
        if (!fs.existsSync(propertiesPath)) return false;

        let content = fs.readFileSync(propertiesPath, 'utf8');
        if (content.includes('enable-rcon=true')) return true;

        const rconPort = server.port + 1000;
        const rconPassword = 'admin123';

        const rconSettings = `
enable-rcon=true
rcon.port=${rconPort}
rcon.password=${rconPassword}
`;
        content = content.replace(/enable-rcon=.*/g, '');
        content = content.replace(/rcon\.port=.*/g, '');
        content = content.replace(/rcon\.password=.*/g, '');
        content = content.trim() + '\n' + rconSettings;
        fs.writeFileSync(propertiesPath, content, 'utf8');

        const settings = JSON.parse(server.settings || '{}');
        settings.rcon = true;
        settings['rcon.port'] = rconPort;
        settings['rcon.password'] = rconPassword;
        await dbRun('UPDATE servers SET settings = ? WHERE id = ?', [JSON.stringify(settings), serverId]);
        return true;
    } catch (err) {
        return false;
    }
}

async function sendCommand(serverId, command) {
    if (!await isServerRunning(serverId)) return false;

    try {
        const serverProcess = serverProcesses[serverId];
        if (serverProcess && !serverProcess.killed && serverProcess.stdin && serverProcess.stdin.writable) {
            serverProcess.stdin.write(command + '\n');
            return true;
        } else {
            try {
                const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
                if (!server) return false;

                const settings = JSON.parse(server.settings || '{}');
                const rconEnabled = settings.rcon === true || settings['enable-rcon'] === true;
                const rconPort = settings['rcon.port'] || settings.rconPort || (server.port + 1000);
                const rconPassword = settings['rcon.password'] || settings.rconPassword || 'admin123';

                if (rconEnabled) {
                    const { Rcon } = require('rcon-client');
                    const rcon = await Rcon.connect({
                        host: 'localhost',
                        port: rconPort,
                        password: rconPassword,
                        timeout: 5000
                    });
                    await rcon.send(command);
                    await rcon.end();
                    return true;
                } else {
                    return false;
                }
            } catch (rconErr) {
                return false;
            }
        }
    } catch (err) {
        return false;
    }
}

module.exports = {
    setSocketIO,
    getServerProcesses,
    getServerStartTimes,
    getOnlinePlayers,
    isServerRunning,
    isProcessRunning,
    isJavaProcess,
    getPidByPort,
    startServer,
    stopServer,
    restartServer,
    checkAndAcceptEula,
    transferServer,
    autoEnableRcon,
    sendCommand,
    saveServerStartTime,
    loadServerStartTime,
    deleteServerStartTime
};
