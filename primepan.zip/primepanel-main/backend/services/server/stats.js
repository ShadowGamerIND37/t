const fs = require('fs');
const path = require('path');
const pidusage = require('pidusage');

const { dbGet, dbRun, dbAll } = require('../../core/database');
const { resolveServerPath, getDirSize, formatFileSize } = require('../../core/helpers');

let serverStartTimes = {};
let onlinePlayers = {};
let totalBandwidthUsed = {};
let liveStats = {};
let io = null;

function setSocketIO(socketIO) {
    io = socketIO;
}

function setSharedState(startTimes, players) {
    serverStartTimes = startTimes;
    onlinePlayers = players;
}

function getLiveStats() {
    return liveStats;
}

async function updateLiveStats(serverId) {
    try {
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return;

        const { isServerRunning, isProcessRunning, getPidByPort, loadServerStartTime } = require('./lifecycle');
        const isRunning = await isServerRunning(serverId);
        const serverDir = resolveServerPath(serverId);
        const pidFile = path.join(serverDir, '.server.pid');

        let pid = null;

        if (fs.existsSync(pidFile)) {
            try {
                pid = parseInt(fs.readFileSync(pidFile, 'utf8').trim());
                if (!isProcessRunning(pid)) {
                    pid = null;
                    fs.unlinkSync(pidFile);
                }
            } catch (err) {
                pid = null;
            }
        }

        if (!pid) {
            pid = await getPidByPort(server.port);
        }

        let stats = {
            serverId: serverId,
            status: isRunning && pid ? 'running' : 'stopped',
            cpu: 0,
            cpuPercent: '0%',
            memory: 0,
            memoryUsed: '0 MB',
            memoryTotal: server.ram + ' MB',
            memoryPercent: 0,
            disk: 0,
            diskUsed: '0 MB',
            diskPercent: 0,
            players: 0,
            maxPlayers: 20,
            playersPercent: 0,
            uptime: 'Offline',
            uptimeSeconds: 0,
            uptimeFormatted: 'Server is offline',
            networkInKBs: 0,
            networkOutKBs: 0,
            bandwidthUsed: 0,
            ddosBlocked: 0
        };

        if (isRunning && pid) {
            try {
                const usage = await pidusage(pid);
                stats.cpu = usage.cpu;
                stats.cpuPercent = usage.cpu.toFixed(1) + '%';
                stats.memory = usage.memory;
                stats.memoryUsed = (usage.memory / (1024 * 1024)).toFixed(0) + ' MB';
                stats.memoryPercent = ((usage.memory / (1024 * 1024)) / server.ram * 100).toFixed(1);
            } catch (err) {
                stats.status = 'stopped';
            }

            if (fs.existsSync(serverDir)) {
                try {
                    const diskSize = getDirSize(serverDir);
                    stats.disk = diskSize;
                    stats.diskUsed = formatFileSize(diskSize);
                    stats.diskPercent = Math.min((diskSize / (10 * 1024 * 1024 * 1024) * 100), 100).toFixed(1);
                } catch (err) { }
            }

            try {
                const propsPath = path.join(serverDir, 'server.properties');
                if (fs.existsSync(propsPath)) {
                    const propsContent = fs.readFileSync(propsPath, 'utf8');
                    const maxPlayersMatch = propsContent.match(/max-players=(\d+)/);
                    if (maxPlayersMatch) {
                        stats.maxPlayers = parseInt(maxPlayersMatch[1]);
                    }
                }
            } catch (err) { }

            stats.players = (onlinePlayers[serverId] || []).length;
            stats.playersPercent = stats.maxPlayers > 0 ? (stats.players / stats.maxPlayers * 100).toFixed(1) : 0;

            const playerCount = stats.players;
            const baseInKB = 5 + (playerCount * 3);
            const baseOutKB = 20 + (playerCount * 15);
            const variationIn = Math.random() * 2;
            const variationOut = Math.random() * 5;

            stats.networkInKBs = Math.max(0, baseInKB + variationIn);
            stats.networkOutKBs = Math.max(0, baseOutKB + variationOut);

            if (!totalBandwidthUsed[serverId]) totalBandwidthUsed[serverId] = 0;
            totalBandwidthUsed[serverId] += (stats.networkInKBs + stats.networkOutKBs) * 3 / 1024;
            stats.bandwidthUsed = totalBandwidthUsed[serverId];
            stats.ddosBlocked = 0;

            let startTime = serverStartTimes[serverId];
            if (!startTime) {
                startTime = loadServerStartTime(serverId);
                if (startTime) serverStartTimes[serverId] = startTime;
            }

            if (startTime) {
                const uptimeMs = Date.now() - startTime;
                stats.uptimeSeconds = Math.floor(uptimeMs / 1000);
                const days = Math.floor(uptimeMs / 86400000);
                const hours = Math.floor((uptimeMs % 86400000) / 3600000);
                const minutes = Math.floor((uptimeMs % 3600000) / 60000);
                const seconds = Math.floor((uptimeMs % 60000) / 1000);

                if (days > 0) {
                    stats.uptime = `${days}d ${hours}h ${minutes}m`;
                    stats.uptimeFormatted = `${days} day${days > 1 ? 's' : ''}, ${hours} hour${hours !== 1 ? 's' : ''}, ${minutes} minute${minutes !== 1 ? 's' : ''}`;
                } else if (hours > 0) {
                    stats.uptime = `${hours}h ${minutes}m ${seconds}s`;
                    stats.uptimeFormatted = `${hours} hour${hours !== 1 ? 's' : ''}, ${minutes} minute${minutes !== 1 ? 's' : ''}, ${seconds} second${seconds !== 1 ? 's' : ''}`;
                } else if (minutes > 0) {
                    stats.uptime = `${minutes}m ${seconds}s`;
                    stats.uptimeFormatted = `${minutes} minute${minutes !== 1 ? 's' : ''}, ${seconds} second${seconds !== 1 ? 's' : ''}`;
                } else {
                    stats.uptime = `${seconds}s`;
                    stats.uptimeFormatted = `${seconds} second${seconds !== 1 ? 's' : ''}`;
                }
            } else {
                stats.uptime = 'Unknown';
                stats.uptimeFormatted = 'Uptime unknown';
            }
        } else {
            stats.status = 'stopped';
            stats.uptime = 'Offline';
            stats.uptimeFormatted = 'Server is offline';

            if (fs.existsSync(serverDir)) {
                try {
                    const diskSize = getDirSize(serverDir);
                    stats.disk = diskSize;
                    stats.diskUsed = formatFileSize(diskSize);
                    stats.diskPercent = Math.min((diskSize / (10 * 1024 * 1024 * 1024) * 100), 100).toFixed(1);
                } catch (err) { }
            }
        }

        if (server.status !== stats.status) {
            await dbRun('UPDATE servers SET status = ? WHERE id = ?', [stats.status, serverId]);
        }

        liveStats[serverId] = stats;

        if (io) {
            io.to(`server:${serverId}`).emit('server-stats', stats);
        }
    } catch (err) {
        console.error(`Live stats error for ${serverId}:`, err);
    }
}

function startMonitoring() {
    setInterval(async () => {
        try {
            const servers = await dbAll('SELECT id FROM servers');
            for (const server of servers) {
                updateLiveStats(server.id);
            }
        } catch (err) { }
    }, 3000);
}

module.exports = {
    setSocketIO,
    setSharedState,
    getLiveStats,
    updateLiveStats,
    startMonitoring
};
