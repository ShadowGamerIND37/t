const fs = require('fs');
const path = require('path');
const axios = require('axios');

async function downloadServerJar(serverType, version, dir) {
    let url;
    let actualVersion = version;

    try {
        if (version === 'latest') {
            if (serverType === 'vanilla') {
                const manifestRes = await axios.get('https://launchermeta.mojang.com/mc/game/version_manifest.json');
                actualVersion = manifestRes.data.latest.release;
            } else if (serverType === 'paper') {
                const res = await axios.get('https://api.papermc.io/v2/projects/paper');
                actualVersion = res.data.versions[res.data.versions.length - 1];
            } else if (serverType === 'purpur') {
                const res = await axios.get('https://api.purpurmc.org/v2/purpur');
                actualVersion = res.data.versions[res.data.versions.length - 1];
            } else if (serverType === 'velocity') {
                const res = await axios.get('https://api.papermc.io/v2/projects/velocity');
                actualVersion = res.data.versions[res.data.versions.length - 1];
            } else if (serverType === 'waterfall') {
                const res = await axios.get('https://api.papermc.io/v2/projects/waterfall');
                actualVersion = res.data.versions[res.data.versions.length - 1];
            } else if (serverType === 'bungeecord') {
                actualVersion = 'latest';
            }
        }

        if (serverType === 'vanilla') {
            const manifestRes = await axios.get('https://launchermeta.mojang.com/mc/game/version_manifest.json');
            const ver = manifestRes.data.versions.find(v => v.id === actualVersion);
            if (!ver) throw new Error(`Vanilla version ${actualVersion} not found`);
            const verJsonRes = await axios.get(ver.url);
            url = verJsonRes.data.downloads.server.url;
        } else if (serverType === 'paper') {
            const buildsRes = await axios.get(`https://api.papermc.io/v2/projects/paper/versions/${actualVersion}/builds`);
            const build = buildsRes.data.builds[buildsRes.data.builds.length - 1];
            url = `https://api.papermc.io/v2/projects/paper/versions/${actualVersion}/builds/${build.build}/downloads/paper-${actualVersion}-${build.build}.jar`;
        } else if (serverType === 'purpur') {
            const latestBuildRes = await axios.get(`https://api.purpurmc.org/v2/purpur/${actualVersion}/latest`);
            const build = latestBuildRes.data.build;
            url = `https://api.purpurmc.org/v2/purpur/${actualVersion}/${build}/download`;
        } else if (serverType === 'spigot') {
            url = 'https://hub.spigotmc.org/jenkins/job/BuildTools/lastSuccessfulBuild/artifact/target/BuildTools.jar';
        } else if (serverType === 'fabric') {
            const loaderRes = await axios.get('https://meta.fabricmc.net/v2/versions/loader');
            const loader = loaderRes.data[0].version;
            url = `https://meta.fabricmc.net/v2/versions/loader/${actualVersion}/${loader}/server/jar`;
        } else if (serverType === 'forge') {
            url = `https://maven.minecraftforge.net/net/minecraftforge/forge/${actualVersion}/forge-${actualVersion}-installer.jar`;
        } else if (serverType === 'velocity') {
            const buildsRes = await axios.get(`https://api.papermc.io/v2/projects/velocity/versions/${actualVersion}/builds`);
            const build = buildsRes.data.builds[buildsRes.data.builds.length - 1];
            url = `https://api.papermc.io/v2/projects/velocity/versions/${actualVersion}/builds/${build.build}/downloads/velocity-${actualVersion}-${build.build}.jar`;
        } else if (serverType === 'waterfall') {
            const buildsRes = await axios.get(`https://api.papermc.io/v2/projects/waterfall/versions/${actualVersion}/builds`);
            const build = buildsRes.data.builds[buildsRes.data.builds.length - 1];
            url = `https://api.papermc.io/v2/projects/waterfall/versions/${actualVersion}/builds/${build.build}/downloads/waterfall-${actualVersion}-${build.build}.jar`;
        } else if (serverType === 'bungeecord') {
            url = 'https://ci.md-5.net/job/BungeeCord/lastSuccessfulBuild/artifact/bootstrap/target/BungeeCord.jar';
        } else if (serverType === 'bedrock') {
            if (process.platform === 'win32') {
                url = 'https://www.minecraft.net/bedrockdedicatedserver/bin-win/bedrock-server-1.26.14.1.zip';
                actualVersion = '1.26.14.1';
            } else {
                url = 'https://www.minecraft.net/bedrockdedicatedserver/bin-linux/bedrock-server-1.26.14.1.zip';
                actualVersion = '1.26.14.1';
            }
        } else if (serverType === 'nukkit') {
            url = 'https://ci.opencollab.dev/job/NukkitX/job/Nukkit/job/master/lastSuccessfulBuild/artifact/target/nukkit-1.0-SNAPSHOT.jar';
        } else if (serverType === 'mohist') {
            url = `https://mohistmc.com/api/v2/projects/mohist/${actualVersion}/builds/latest/download`;
        } else {
            throw new Error(`Unsupported server type: ${serverType}`);
        }

        const jarPath = path.join(dir, 'server.jar');
        let downloadPath = jarPath;

        if (serverType === 'bedrock') {
            downloadPath = path.join(dir, 'bedrock-server.zip');
        }

        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }

        const response = await axios({
            url,
            method: 'GET',
            responseType: 'stream',
            headers: {
                'User-Agent': 'Mozilla/5.0 (compatible; Minecraft Server Panel)',
                'Accept': 'application/java-archive, application/octet-stream, application/zip, */*'
            },
            timeout: 300000
        });

        const writer = fs.createWriteStream(downloadPath);
        const totalLength = parseInt(response.headers['content-length'], 10);
        let downloadedLength = 0;

        return new Promise((resolve, reject) => {
            response.data.on('data', (chunk) => {
                downloadedLength += chunk.length;
                if (totalLength) {
                    const percent = Math.round((downloadedLength / totalLength) * 100);
                    if (percent % 10 === 0) {
                        console.log(`Download progress: ${percent}% (${Math.round(downloadedLength / 1024 / 1024)}MB)`);
                    }
                }
            });

            response.data.pipe(writer);

            writer.on('finish', async () => {
                if (serverType === 'bedrock') {
                    try {
                        const unzipper = require('unzipper');
                        await fs.createReadStream(downloadPath)
                            .pipe(unzipper.Extract({ path: dir }))
                            .promise();
                        fs.unlinkSync(downloadPath);
                    } catch (extractErr) {
                        reject(new Error(`Bedrock server extraction failed: ${extractErr.message}`));
                        return;
                    }
                }
                resolve(actualVersion);
            });

            writer.on('error', reject);
            response.data.on('error', reject);
        });
    } catch (err) {
        throw err;
    }
}

async function downloadPluginJar(downloadUrl, destPath) {
    try {
        if (!downloadUrl || !downloadUrl.startsWith('http')) {
            throw new Error('Invalid download URL');
        }

        const response = await axios({
            url: downloadUrl,
            method: 'GET',
            responseType: 'stream',
            maxRedirects: 10,
            timeout: 60000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': '*/*'
            },
            validateStatus: function (status) {
                return status >= 200 && status < 400;
            }
        });

        if (!response.data) {
            throw new Error('No data received from download URL');
        }

        fs.mkdirSync(path.dirname(destPath), { recursive: true });

        const writer = fs.createWriteStream(destPath);

        return new Promise((resolve, reject) => {
            response.data.pipe(writer);
            writer.on('finish', () => {
                if (fs.existsSync(destPath)) {
                    const stats = fs.statSync(destPath);
                    if (stats.size > 0) {
                        resolve();
                    } else {
                        fs.unlinkSync(destPath);
                        reject(new Error('Downloaded file is empty'));
                    }
                } else {
                    reject(new Error('File was not created'));
                }
            });
            writer.on('error', (err) => {
                if (fs.existsSync(destPath)) fs.unlinkSync(destPath);
                reject(err);
            });
            response.data.on('error', (err) => {
                writer.close();
                if (fs.existsSync(destPath)) fs.unlinkSync(destPath);
                reject(err);
            });
        });
    } catch (err) {
        if (fs.existsSync(destPath)) {
            try { fs.unlinkSync(destPath); } catch (e) { }
        }
        throw new Error(`Failed to download plugin: ${err.message}`);
    }
}

function getInstalledPlugins(serverId) {
    const { resolveServerPath } = require('../../core/helpers');
    const pluginsDir = resolveServerPath(serverId, 'plugins');
    if (!fs.existsSync(pluginsDir)) fs.mkdirSync(pluginsDir, { recursive: true });
    return fs.readdirSync(pluginsDir).filter(f => f.endsWith('.jar'));
}

module.exports = {
    downloadServerJar,
    downloadPluginJar,
    getInstalledPlugins
};
