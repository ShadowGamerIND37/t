const { dbGet, dbRun, dbAll } = require('../core/database');

let io = null;

function setSocketIO(socketIO) {
    io = socketIO;
}

function getIconForType(type) {
    const icons = {
        success: 'check-circle',
        error: 'exclamation-triangle',
        warning: 'exclamation-circle',
        info: 'info-circle',
        server: 'server',
        user: 'user',
        security: 'shield-alt'
    };
    return icons[type] || 'info-circle';
}

async function createNotification(userId, title, message, type = 'info', options = {}) {
    try {
        const notification = {
            user_id: userId,
            title: title,
            message: message,
            type: type,
            icon: options.icon || getIconForType(type),
            action_url: options.actionUrl || null,
            action_text: options.actionText || null,
            server_id: options.serverId || null
        };

        const result = await dbRun(
            `INSERT INTO notifications (user_id, title, message, type, icon, action_url, action_text, server_id) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [notification.user_id, notification.title, notification.message, notification.type,
            notification.icon, notification.action_url, notification.action_text, notification.server_id]
        );

        if (io) {
            io.to(`user:${userId}`).emit('new-notification', {
                id: result.lastID,
                ...notification,
                created_at: new Date().toISOString()
            });
        }

        return result.lastID;
    } catch (error) {
        return null;
    }
}

async function getUserNotifications(userId, limit = 50, unreadOnly = false) {
    try {
        let sql = 'SELECT * FROM notifications WHERE user_id = ?';
        const params = [userId];

        if (unreadOnly) {
            sql += ' AND is_read = 0';
        }

        sql += ' ORDER BY created_at DESC LIMIT ?';
        params.push(limit);

        return await dbAll(sql, params);
    } catch (error) {
        return [];
    }
}

async function markNotificationAsRead(notificationId, userId) {
    try {
        await dbRun('UPDATE notifications SET is_read = 1, updated_at = datetime(\'now\') WHERE id = ? AND user_id = ?',
            [notificationId, userId]);
        return true;
    } catch (error) {
        return false;
    }
}

async function markAllNotificationsAsRead(userId, category = null) {
    try {
        let sql = 'UPDATE notifications SET is_read = 1, updated_at = datetime(\'now\') WHERE user_id = ?';
        const params = [userId];

        if (category) {
            sql += ' AND category = ?';
            params.push(category);
        }

        await dbRun(sql, params);
        return true;
    } catch (error) {
        return false;
    }
}

async function clearAllNotifications(userId, category = null) {
    try {
        let sql = 'DELETE FROM notifications WHERE user_id = ?';
        const params = [userId];

        if (category) {
            sql += ' AND category = ?';
            params.push(category);
        }

        await dbRun(sql, params);
        return true;
    } catch (error) {
        return false;
    }
}

async function getUnreadNotificationCount(userId) {
    try {
        const result = await dbGet(
            'SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0',
            [userId]
        );
        return result ? result.count : 0;
    } catch (error) {
        return 0;
    }
}

async function getNotificationsPaginated(userId, page = 1, limit = 20, filter = 'all', category = 'all') {
    try {
        const offset = (page - 1) * limit;
        let whereClause = 'WHERE user_id = ?';
        let params = [userId];

        if (filter === 'unread') {
            whereClause += ' AND is_read = 0';
        } else if (filter === 'read') {
            whereClause += ' AND is_read = 1';
        }

        if (category !== 'all') {
            whereClause += ' AND category = ?';
            params.push(category);
        }

        const notifications = await dbAll(`
            SELECT * FROM notifications ${whereClause} ORDER BY created_at DESC LIMIT ? OFFSET ?
        `, [...params, limit, offset]);

        const totalResult = await dbGet(`SELECT COUNT(*) as count FROM notifications ${whereClause}`, params);
        const total = totalResult ? totalResult.count : 0;
        const pages = Math.ceil(total / limit);

        return {
            data: notifications,
            pagination: { page, limit, total, pages, hasNext: page < pages, hasPrev: page > 1 }
        };
    } catch (error) {
        throw error;
    }
}

async function getNotificationStats(userId) {
    try {
        const total = await dbGet('SELECT COUNT(*) as count FROM notifications WHERE user_id = ?', [userId]);
        const unread = await dbGet('SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0', [userId]);
        const today = await dbGet(
            'SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND date(created_at) = date(\'now\')', [userId]);
        const thisWeek = await dbGet(
            'SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND created_at >= datetime(\'now\', \'-7 days\')', [userId]);
        const categories = await dbAll(
            'SELECT category, COUNT(*) as count FROM notifications WHERE user_id = ? GROUP BY category ORDER BY count DESC', [userId]);
        const types = await dbAll(
            'SELECT type, COUNT(*) as count FROM notifications WHERE user_id = ? GROUP BY type ORDER BY count DESC', [userId]);

        return {
            total: total ? total.count : 0,
            unread: unread ? unread.count : 0,
            read: total ? total.count - (unread ? unread.count : 0) : 0,
            today: today ? today.count : 0,
            thisWeek: thisWeek ? thisWeek.count : 0,
            categories: categories || [],
            types: types || []
        };
    } catch (error) {
        return { total: 0, unread: 0, read: 0, today: 0, thisWeek: 0, categories: [], types: [] };
    }
}

module.exports = {
    setSocketIO,
    createNotification,
    getUserNotifications,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    clearAllNotifications,
    getUnreadNotificationCount,
    getNotificationsPaginated,
    getNotificationStats,
    getIconForType
};
