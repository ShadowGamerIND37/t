const axios = require('axios');

async function searchModrinth(query, page = 1, limit = 12) {
    try {
        const offset = (page - 1) * limit;
        const res = await axios.get('https://api.modrinth.com/v2/search', {
            params: {
                query: query || '',
                limit,
                offset,
                facets: JSON.stringify([['project_type:plugin'], ['categories:bukkit', 'categories:spigot', 'categories:paper']])
            },
            headers: { 'User-Agent': 'MinecraftPanel/1.0' }
        });

        return {
            plugins: (res.data.hits || []).map(p => ({
                id: p.project_id, name: p.title, slug: p.slug, description: p.description,
                author: p.author, downloads: p.downloads, follows: p.follows,
                categories: p.categories || [], source: 'modrinth', projectId: p.project_id,
                icon: p.icon_url || null, url: `https://modrinth.com/plugin/${p.slug}`,
                dateModified: p.date_modified, clientSide: p.client_side, serverSide: p.server_side, hasVersions: true
            })),
            totalHits: res.data.total_hits || 0
        };
    } catch (err) {
        return { plugins: [], totalHits: 0 };
    }
}

async function searchSpigot(query, page = 1, limit = 12) {
    try {
        const searchQuery = query || 'popular';
        const res = await axios.get(`https://api.spiget.org/v2/search/resources/${encodeURIComponent(searchQuery)}`, {
            params: { size: limit, page: page - 1, sort: '-downloads', fields: 'id,name,tag,likes,downloads,rating,icon,premium,price,currency,file,author' },
            headers: { 'User-Agent': 'MinecraftPanel/1.0' }
        });

        const plugins = (res.data || []).filter(p => !p.premium).map(p => ({
            id: p.id, name: p.name, description: p.tag || 'No description available',
            author: (p.author && p.author.name) || 'Unknown', downloads: p.downloads || 0,
            rating: (p.rating && p.rating.average) || 0, likes: p.likes || 0, source: 'spiget', resourceId: p.id,
            icon: (p.icon && p.icon.url) ? `https://www.spigotmc.org/${p.icon.url}` : null,
            url: `https://www.spigotmc.org/resources/${p.id}/`, version: (p.file && p.file.version) || 'Unknown',
            testedVersions: p.testedVersions || [], hasVersions: true
        }));

        return { plugins, totalHits: plugins.length };
    } catch (err) {
        return { plugins: [], totalHits: 0 };
    }
}

async function searchHangar(query, page = 1, limit = 12) {
    try {
        const res = await axios.get('https://hangar.papermc.io/api/v1/projects', {
            params: { q: query || '', limit, offset: (page - 1) * limit, sort: '-downloads', category: 'plugin' },
            headers: { 'User-Agent': 'MinecraftPanel/1.0' }
        });

        const plugins = (res.data.result || []).map(p => ({
            id: p.name, name: p.name, slug: p.name, description: p.description || 'No description available',
            author: p.owner, downloads: (p.stats && p.stats.downloads) || 0,
            views: (p.stats && p.stats.views) || 0, stars: (p.stats && p.stats.stars) || 0,
            watchers: (p.stats && p.stats.watchers) || 0, categories: p.category ? [p.category] : [],
            source: 'hangar', projectId: p.name, icon: p.avatarUrl || null,
            url: `https://hangar.papermc.io/${p.owner}/${p.name}`, hasVersions: true
        }));

        return { plugins, totalHits: (res.data.pagination && res.data.pagination.count) || plugins.length };
    } catch (err) {
        return { plugins: [], totalHits: 0 };
    }
}

async function searchBukkit(query, page = 1, limit = 12) {
    try {
        const res = await axios.get('https://api.curseforge.com/v1/mods/search', {
            params: { gameId: 432, classId: 5, searchFilter: query || '', pageSize: limit, index: (page - 1) * limit, sortField: 2, sortOrder: 'desc' },
            headers: { 'User-Agent': 'MinecraftPanel/1.0', 'x-api-key': '$2a$10$bL4bIL5pUWqfcO7KQtnMReakwtfHbNKh6v1uTpKlzhwoueEJQnPnm' }
        });

        const plugins = (res.data.data || []).map(p => ({
            id: p.id, name: p.name, slug: p.slug, description: p.summary || 'No description available',
            author: (p.authors && p.authors[0] && p.authors[0].name) || 'Unknown', downloads: p.downloadCount || 0,
            categories: (p.categories || []).map(c => c.name), source: 'bukkit', projectId: p.id,
            icon: (p.logo && p.logo.thumbnailUrl) || null,
            url: (p.links && p.links.websiteUrl) || `https://www.curseforge.com/minecraft/bukkit-plugins/${p.slug}`,
            dateModified: p.dateModified, hasVersions: true
        }));

        return { plugins, totalHits: (res.data.pagination && res.data.pagination.totalCount) || plugins.length };
    } catch (err) {
        return { plugins: [], totalHits: 0 };
    }
}

async function searchPlugins(query, page = 1, limit = 12, provider = 'all') {
    const perProvider = Math.ceil(limit / 4);

    if (provider === 'modrinth') return await searchModrinth(query, page, limit);
    if (provider === 'spiget') return await searchSpigot(query, page, limit);
    if (provider === 'hangar') return await searchHangar(query, page, limit);
    if (provider === 'bukkit') return await searchBukkit(query, page, limit);

    const [modrinth, spigot, hangar, bukkit] = await Promise.all([
        searchModrinth(query, page, perProvider),
        searchSpigot(query, page, perProvider),
        searchHangar(query, page, perProvider),
        searchBukkit(query, page, perProvider)
    ]);

    return {
        plugins: [...modrinth.plugins, ...spigot.plugins, ...hangar.plugins, ...bukkit.plugins],
        totalHits: modrinth.totalHits + spigot.totalHits + hangar.totalHits + bukkit.totalHits
    };
}

async function getModrinthDownloadUrl(projectId, versionId = null) {
    try {
        const res = await axios.get(`https://api.modrinth.com/v2/project/${projectId}/version`, {
            headers: { 'User-Agent': 'MinecraftPanel/1.0' }
        });

        if (res.data && res.data.length > 0) {
            let targetVersion = versionId ? res.data.find(v => v.id === versionId) : res.data[0];
            if (!targetVersion) targetVersion = res.data[0];

            if (targetVersion.files && targetVersion.files.length > 0) {
                const primaryFile = targetVersion.files.find(f => f.primary) || targetVersion.files[0];
                return { url: primaryFile.url, filename: primaryFile.filename, version: targetVersion.version_number, versionId: targetVersion.id };
            }
        }
        throw new Error('No files found');
    } catch (err) {
        return null;
    }
}

async function getModrinthVersions(projectId) {
    try {
        const res = await axios.get(`https://api.modrinth.com/v2/project/${projectId}/version`, {
            headers: { 'User-Agent': 'MinecraftPanel/1.0' }
        });

        return (res.data || []).map(v => ({
            id: v.id, name: v.name, versionNumber: v.version_number, gameVersions: v.game_versions || [],
            loaders: v.loaders || [], datePublished: v.date_published, downloads: v.downloads || 0, featured: v.featured || false
        }));
    } catch (err) {
        return [];
    }
}

async function getSpigetDownloadUrl(resourceId, versionId = null) {
    try {
        const res = await axios.get(`https://api.spiget.org/v2/resources/${resourceId}`, {
            headers: { 'User-Agent': 'MinecraftPanel/1.0' }
        });

        if (res.data) {
            return {
                url: versionId ? `https://api.spiget.org/v2/resources/${resourceId}/versions/${versionId}/download`
                    : `https://api.spiget.org/v2/resources/${resourceId}/download`,
                filename: `${sanitize(res.data.name)}.jar`, version: (res.data.file && res.data.file.version) || 'latest'
            };
        }
        throw new Error('Resource not found');
    } catch (err) {
        return null;
    }
}

async function getSpigetVersions(resourceId) {
    try {
        const res = await axios.get(`https://api.spiget.org/v2/resources/${resourceId}/versions`, {
            params: { size: 50, sort: '-releaseDate' },
            headers: { 'User-Agent': 'MinecraftPanel/1.0' }
        });

        return (res.data || []).map(v => ({ id: v.id, name: v.name, versionNumber: v.name, releaseDate: v.releaseDate, downloads: v.downloads || 0 }));
    } catch (err) {
        return [];
    }
}

async function getHangarDownloadUrl(projectId, versionId = null) {
    try {
        const res = await axios.get(`https://hangar.papermc.io/api/v1/projects/${projectId}/versions`, {
            params: { limit: 25, offset: 0 },
            headers: { 'User-Agent': 'MinecraftPanel/1.0' }
        });

        if (res.data.result && res.data.result.length > 0) {
            const targetVersion = versionId ? res.data.result.find(v => v.name === versionId) : res.data.result[0];
            if (targetVersion) {
                const platforms = Object.keys(targetVersion.downloads || {});
                if (platforms.length > 0) {
                    const platform = platforms[0];
                    return {
                        url: `https://hangar.papermc.io/api/v1/projects/${projectId}/versions/${targetVersion.name}/${platform}/download`,
                        filename: `${sanitize(projectId)}-${targetVersion.name}.jar`, version: targetVersion.name
                    };
                }
            }
        }
        throw new Error('No versions found');
    } catch (err) {
        return null;
    }
}

async function getHangarVersions(projectId) {
    try {
        const res = await axios.get(`https://hangar.papermc.io/api/v1/projects/${projectId}/versions`, {
            headers: { 'User-Agent': 'MinecraftPanel/1.0' }
        });

        return (res.data.result || []).map(v => ({
            id: v.name, name: v.name, versionNumber: v.name, platformDependencies: v.platformDependencies || {},
            downloads: (v.stats && v.stats.downloads) || 0
        }));
    } catch (err) {
        return [];
    }
}

async function getBukkitDownloadUrl(projectId, fileId = null) {
    const apiKey = '$2a$10$bL4bIL5pUWqfcO7KQtnMReakwtfHbNKh6v1uTpKlzhwoueEJQnPnm';
    try {
        if (fileId) {
            const res = await axios.get(`https://api.curseforge.com/v1/mods/${projectId}/files/${fileId}`, {
                headers: { 'User-Agent': 'MinecraftPanel/1.0', 'x-api-key': apiKey }
            });
            if (res.data.data && res.data.data.downloadUrl) {
                return { url: res.data.data.downloadUrl, filename: res.data.data.fileName, version: res.data.data.displayName };
            }
        } else {
            const res = await axios.get(`https://api.curseforge.com/v1/mods/${projectId}/files`, {
                params: { pageSize: 10, index: 0 },
                headers: { 'User-Agent': 'MinecraftPanel/1.0', 'x-api-key': apiKey }
            });
            if (res.data.data && res.data.data.length > 0) {
                const file = res.data.data.find(f => f.downloadUrl);
                if (file && file.downloadUrl) {
                    return { url: file.downloadUrl, filename: file.fileName, version: file.displayName };
                }
            }
        }
        throw new Error('No downloadable files found');
    } catch (err) {
        return null;
    }
}

async function getBukkitVersions(projectId) {
    const apiKey = '$2a$10$bL4bIL5pUWqfcO7KQtnMReakwtfHbNKh6v1uTpKlzhwoueEJQnPnm';
    try {
        const res = await axios.get(`https://api.curseforge.com/v1/mods/${projectId}/files`, {
            params: { pageSize: 50, index: 0 },
            headers: { 'User-Agent': 'MinecraftPanel/1.0', 'x-api-key': apiKey }
        });

        return (res.data.data || []).map(f => ({
            id: f.id, name: f.displayName, versionNumber: f.displayName, gameVersions: f.gameVersions || [],
            fileDate: f.fileDate, downloads: f.downloadCount || 0
        }));
    } catch (err) {
        return [];
    }
}

module.exports = {
    searchPlugins,
    searchModrinth,
    searchSpigot,
    searchHangar,
    searchBukkit,
    getModrinthDownloadUrl,
    getModrinthVersions,
    getSpigetDownloadUrl,
    getSpigetVersions,
    getHangarDownloadUrl,
    getHangarVersions,
    getBukkitDownloadUrl,
    getBukkitVersions
};
