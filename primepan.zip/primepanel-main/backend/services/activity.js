const { dbRun } = require('../core/database');

let io = null;

function setSocketIO(socketIO) {
    io = socketIO;
}

async function logServerActivity(serverId, action, details = null, userId = null, ipAddress = null) {
    try {
        const result = await dbRun(
            `INSERT INTO server_activity (server_id, user_id, action, details, ip_address) 
             VALUES (?, ?, ?, ?, ?)`,
            [serverId, userId, action, details, ipAddress]
        );

        if (io) {
            io.to(`server:${serverId}`).emit('server-activity', {
                id: result.lastID,
                server_id: serverId,
                user_id: userId,
                action: action,
                details: details,
                ip_address: ipAddress,
                created_at: new Date().toISOString()
            });
        }

        return result.lastID;
    } catch (error) {
        return null;
    }
}

module.exports = {
    setSocketIO,
    logServerActivity
};
