// License Validation
// Supports built-in testing keys and optional external license manager

const axios = require('axios');

const LICENSE_MANAGER_URL = process.env.LICENSE_MANAGER_URL;
const LICENSE_API_KEY = process.env.LICENSE_API_KEY || '';

// Built-in testing keys that always work (for local development)
const TEST_KEYS = [
    'test',
    'demo',
    'trial',
    'testing',
    'DEMO-LICENSE-2024-ABCD',
    'PREMIUM-1234-5678-9012',
    'dev-mode',
    'development'
];

/**
 * Validate a license key
 * Supports built-in testing keys and optional external license manager
 */
async function validateLicenseKey(licenseKey) {
    const key = (licenseKey || '').trim();
    if (!key) {
        return { valid: false, message: 'License key is required' };
    }

    // Check built-in testing keys first
    if (TEST_KEYS.includes(key)) {
        return { valid: true, message: 'License is valid (testing key)' };
    }

    // If external license manager is configured, validate against it
    if (LICENSE_API_KEY && LICENSE_MANAGER_URL) {
        try {
            const response = await axios.post(`${LICENSE_MANAGER_URL}/api/license-manager/validate`, {
                key: key
            }, {
                headers: {
                    'Authorization': `Bearer ${LICENSE_API_KEY}`,
                    'Content-Type': 'application/json'
                },
                timeout: 10000
            });

            if (response.data && response.data.valid === true) {
                return {
                    valid: true,
                    message: response.data.message || 'License is valid',
                    data: response.data.data || null
                };
            }

            return {
                valid: false,
                message: response.data.message || 'Invalid license key'
            };
        } catch (error) {
            if (error.code === 'ECONNREFUSED' || error.code === 'ECONNRESET') {
                return { valid: false, message: 'License manager is offline' };
            }
            if (error.response) {
                const status = error.response.status;
                if (status === 401) {
                    return { valid: false, message: 'License manager authentication failed (invalid API key)' };
                }
                return {
                    valid: false,
                    message: error.response.data?.message || `License server error (${status})`
                };
            }
            return { valid: false, message: 'Failed to validate license: ' + error.message };
        }
    }

    // No external manager and not a testing key
    return { valid: false, message: 'Invalid license key. Try: test, demo, trial, or DEMO-LICENSE-2024-ABCD' };
}

/**
 * Check if the license manager is reachable
 */
async function isLicenseManagerReachable() {
    if (LICENSE_MANAGER_URL && LICENSE_API_KEY) {
        try {
            await axios.get(`${LICENSE_MANAGER_URL}/api/license-manager/status`, {
                headers: { 'Authorization': `Bearer ${LICENSE_API_KEY}` },
                timeout: 5000
            });
            return true;
        } catch {
            return false;
        }
    }
    return false;
}

module.exports = {
    validateLicenseKey,
    isLicenseManagerReachable
};
