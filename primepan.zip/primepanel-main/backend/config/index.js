const path = require('path');

const DATA_DIR = path.resolve(__dirname, '..', '..');
const DB_PATH = path.join(DATA_DIR, 'database.db');
const SERVERS_DIR = path.join(DATA_DIR, 'servers');

let globalSettings = {
    registrationEnabled: true,
    panelName: 'Minecraft Server Panel',
    panelDescription: 'Powerful Minecraft Server Management',
    siteIcon: '/default-icon.png',
    headerIcon: '/default-header.png',
    footerText: '\u00a9 2024 Minecraft Panel',
    theme: 'default',
    maxServersPerUser: 5,
    defaultRam: 1024,
    defaultPort: 25565,
    videoBackgroundUrl: 'https://motionbgs.com/media/9269/minecraft-falling-snow.960x540.mp4',
    maintenanceMode: false,
    maintenanceMessage: 'We are performing scheduled maintenance. Back soon!',
    licenseKey: '',
    licenseActivated: false,
    defaultCurrency: 'USD',
    billingEnabled: true,
    paymentGateways: {
        wallet: { enabled: true },
        qrcode: { enabled: false, qrImage: '' },
        upi: { enabled: false, upiId: '' },
        bank: { enabled: false, bankName: '', accountNo: '', ifsc: '' }
    }
};

const CURRENCY_SYMBOLS = {
    USD: '$', EUR: '\u20ac', GBP: '\u00a3', INR: '\u20b9',
    AUD: 'A$', CAD: 'C$', JPY: '\u00a5', BRL: 'R$', SGD: 'S$'
};

module.exports = {
    DATA_DIR,
    DB_PATH,
    SERVERS_DIR,
    globalSettings,
    CURRENCY_SYMBOLS
};
