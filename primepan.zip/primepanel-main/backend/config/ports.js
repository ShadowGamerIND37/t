const PORT_CONFIG = {
    JAVA_EDITION: {
        START_PORT: 25565,
        MAX_PORT: 25665,
        DEFAULT_PORT: 25565,
        CATEGORY: 'Java Edition'
    },
    PROXY_SERVERS: {
        START_PORT: 25700,
        MAX_PORT: 25799,
        DEFAULT_PORT: 25700,
        CATEGORY: 'Proxy Servers'
    },
    BEDROCK_EDITION: {
        START_PORT: 19132,
        MAX_PORT: 19232,
        DEFAULT_PORT: 19132,
        CATEGORY: 'Bedrock Edition'
    },
    RESERVED_PORTS: [
        3000, 22, 80, 443, 3306, 5432, 6379, 27017,
        8080, 8443, 21, 23, 53, 110, 143, 993, 995,
        1433, 1521, 5000, 5001, 9000, 9001
    ]
};

function getPortRangeForServerType(serverType) {
    if (['velocity', 'bungeecord', 'waterfall'].includes(serverType)) {
        return PORT_CONFIG.PROXY_SERVERS;
    }
    if (['bedrock', 'nukkit'].includes(serverType)) {
        return PORT_CONFIG.BEDROCK_EDITION;
    }
    return PORT_CONFIG.JAVA_EDITION;
}

module.exports = { PORT_CONFIG, getPortRangeForServerType };
