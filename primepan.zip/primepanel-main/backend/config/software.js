const SERVER_SOFTWARE = {
    vanilla: {
        name: 'Vanilla',
        description: 'Official Minecraft server software from Mojang',
        category: 'Java Edition',
        icon: 'fas fa-cube',
        color: '#8B4513',
        downloadUrl: 'https://launcher.mojang.com/v1/objects/{hash}/server.jar',
        manifestUrl: 'https://launchermeta.mojang.com/mc/game/version_manifest.json',
        supports: ['plugins: false', 'mods: false', 'datapacks: true']
    },
    paper: {
        name: 'Paper',
        description: 'High-performance Spigot fork with optimizations and bug fixes',
        category: 'Java Edition',
        icon: 'fas fa-scroll',
        color: '#2196F3',
        downloadUrl: 'https://api.papermc.io/v2/projects/paper/versions/{version}/builds/{build}/downloads/paper-{version}-{build}.jar',
        manifestUrl: 'https://api.papermc.io/v2/projects/paper',
        supports: ['plugins: true', 'mods: false', 'datapacks: true']
    },
    purpur: {
        name: 'Purpur',
        description: 'Paper fork with additional features and configuration options',
        category: 'Java Edition',
        icon: 'fas fa-gem',
        color: '#9C27B0',
        downloadUrl: 'https://api.purpurmc.org/v2/purpur/{version}/latest/download',
        manifestUrl: 'https://api.purpurmc.org/v2/purpur',
        supports: ['plugins: true', 'mods: false', 'datapacks: true']
    },
    spigot: {
        name: 'Spigot',
        description: 'Popular server software with plugin support and performance improvements',
        category: 'Java Edition',
        icon: 'fas fa-fire',
        color: '#FF9800',
        downloadUrl: 'https://hub.spigotmc.org/jenkins/job/BuildTools/lastSuccessfulBuild/artifact/target/BuildTools.jar',
        manifestUrl: null,
        supports: ['plugins: true', 'mods: false', 'datapacks: true']
    },
    bukkit: {
        name: 'CraftBukkit',
        description: 'Original modded server software with plugin API',
        category: 'Java Edition',
        icon: 'fas fa-hammer',
        color: '#795548',
        downloadUrl: 'https://hub.spigotmc.org/jenkins/job/BuildTools/lastSuccessfulBuild/artifact/target/BuildTools.jar',
        manifestUrl: null,
        supports: ['plugins: true', 'mods: false', 'datapacks: true']
    },
    fabric: {
        name: 'Fabric',
        description: 'Lightweight modding platform for modern Minecraft versions',
        category: 'Java Edition',
        icon: 'fas fa-thread',
        color: '#4CAF50',
        downloadUrl: 'https://meta.fabricmc.net/v2/versions/loader/{version}/{loader}/server/jar',
        manifestUrl: 'https://meta.fabricmc.net/v2/versions/game',
        supports: ['plugins: false', 'mods: true', 'datapacks: true']
    },
    forge: {
        name: 'Forge',
        description: 'Popular modding platform with extensive mod ecosystem',
        category: 'Java Edition',
        icon: 'fas fa-anvil',
        color: '#FF5722',
        downloadUrl: 'https://maven.minecraftforge.net/net/minecraftforge/forge/{version}/forge-{version}-installer.jar',
        manifestUrl: 'https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json',
        supports: ['plugins: false', 'mods: true', 'datapacks: true']
    },
    quilt: {
        name: 'Quilt',
        description: 'Modern modding platform forked from Fabric with enhanced features',
        category: 'Java Edition',
        icon: 'fas fa-puzzle-piece',
        color: '#673AB7',
        downloadUrl: 'https://meta.quiltmc.org/v3/versions/loader/{version}/{loader}/server/jar',
        manifestUrl: 'https://meta.quiltmc.org/v3/versions/game',
        supports: ['plugins: false', 'mods: true', 'datapacks: true']
    },
    velocity: {
        name: 'Velocity',
        description: 'Modern, high-performance Minecraft proxy server',
        category: 'Proxy Servers',
        icon: 'fas fa-rocket',
        color: '#00BCD4',
        downloadUrl: 'https://api.papermc.io/v2/projects/velocity/versions/{version}/builds/{build}/downloads/velocity-{version}-{build}.jar',
        manifestUrl: 'https://api.papermc.io/v2/projects/velocity',
        supports: ['plugins: true', 'networks: true', 'modern: true']
    },
    bungeecord: {
        name: 'BungeeCord',
        description: 'Popular proxy server for connecting multiple Minecraft servers',
        category: 'Proxy Servers',
        icon: 'fas fa-network-wired',
        color: '#FF6B35',
        downloadUrl: 'https://ci.md-5.net/job/BungeeCord/lastSuccessfulBuild/artifact/bootstrap/target/BungeeCord.jar',
        manifestUrl: null,
        supports: ['plugins: true', 'networks: true', 'legacy: true']
    },
    waterfall: {
        name: 'Waterfall',
        description: 'Paper fork of BungeeCord with performance improvements',
        category: 'Proxy Servers',
        icon: 'fas fa-water',
        color: '#2196F3',
        downloadUrl: 'https://api.papermc.io/v2/projects/waterfall/versions/{version}/builds/{build}/downloads/waterfall-{version}-{build}.jar',
        manifestUrl: 'https://api.papermc.io/v2/projects/waterfall',
        supports: ['plugins: true', 'networks: true', 'optimized: true']
    },
    bedrock: {
        name: 'Bedrock Dedicated Server',
        description: 'Official Minecraft Bedrock Edition server',
        category: 'Bedrock Edition',
        icon: 'fas fa-mobile-alt',
        color: '#4CAF50',
        downloadUrl: 'https://minecraft.azureedge.net/bin-linux/bedrock-server-{version}.zip',
        manifestUrl: null,
        supports: ['crossplay: true', 'mobile: true', 'console: true']
    },
    nukkit: {
        name: 'Nukkit',
        description: 'Third-party Bedrock Edition server with plugin support',
        category: 'Bedrock Edition',
        icon: 'fas fa-atom',
        color: '#9C27B0',
        downloadUrl: 'https://ci.opencollab.dev/job/NukkitX/job/Nukkit/job/master/lastSuccessfulBuild/artifact/target/nukkit-1.0-SNAPSHOT.jar',
        manifestUrl: null,
        supports: ['plugins: true', 'crossplay: true', 'mobile: true']
    },
    mohist: {
        name: 'Mohist',
        description: 'Forge + Bukkit hybrid server supporting both mods and plugins',
        category: 'Hybrid Servers',
        icon: 'fas fa-layer-group',
        color: '#607D8B',
        downloadUrl: 'https://mohistmc.com/api/v2/projects/mohist/{version}/builds/latest/download',
        manifestUrl: 'https://mohistmc.com/api/v2/projects/mohist',
        supports: ['plugins: true', 'mods: true', 'hybrid: true']
    },
    catserver: {
        name: 'CatServer',
        description: 'High-performance Forge + Bukkit server implementation',
        category: 'Hybrid Servers',
        icon: 'fas fa-cat',
        color: '#FF9800',
        downloadUrl: 'https://jenkins.rbqcloud.cn:30011/job/CatServer-1.18.2/lastSuccessfulBuild/artifact/target/CatServer-{version}.jar',
        manifestUrl: null,
        supports: ['plugins: true', 'mods: true', 'performance: true']
    }
};

function getAvailableServerSoftware() {
    const categories = {};
    Object.entries(SERVER_SOFTWARE).forEach(([key, software]) => {
        if (!categories[software.category]) {
            categories[software.category] = [];
        }
        categories[software.category].push({ key, ...software });
    });
    return categories;
}

module.exports = { SERVER_SOFTWARE, getAvailableServerSoftware };
