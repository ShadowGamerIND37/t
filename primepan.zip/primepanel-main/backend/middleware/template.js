const { dbGet } = require('../core/database');
const { globalSettings } = require('../config');

async function getTemplateVars(req, server = null, additionalVars = {}) {
    let userWithTheme = req.session.user;

    if (req.session.user) {
        try {
            const userProfile = await dbGet(`
                SELECT u.*, up.theme_preference, up.theme_primary_color, up.theme_accent_color,
                       up.language, up.timezone, up.display_name as profile_display_name,
                       up.profile_picture
                FROM users u
                LEFT JOIN user_profiles up ON u.id = up.user_id
                WHERE u.id = ?
            `, [req.session.user.id]);

            if (userProfile) {
                userWithTheme = {
                    ...req.session.user,
                    theme_preference: userProfile.theme_preference || 'dark',
                    theme_primary_color: userProfile.theme_primary_color || '#2d6a4f',
                    theme_accent_color: userProfile.theme_accent_color || '#40916c',
                    language: userProfile.language || 'en',
                    timezone: userProfile.timezone || 'UTC',
                    display_name: userProfile.profile_display_name || userProfile.display_name || req.session.user.username,
                    profile_picture: userProfile.profile_picture || null
                };
            }
        } catch (err) { }
    }

    return {
        settings: globalSettings,
        user: userWithTheme,
        currentPage: additionalVars.currentPage || 'dashboard',
        server: server,
        req: req,
        showMaintenanceBanner: false,
        ...additionalVars
    };
}

function setupTemplateGlobals(app) {
    app.use((req, res, next) => {
        res.locals.user = req.session.user || null;
        res.locals.settings = globalSettings;
        res.locals.formatCurrency = (amount, currency) => {
            const cur = currency || globalSettings.defaultCurrency || 'USD';
            const symbols = { USD: '$', EUR: '€', GBP: '£', INR: '₹', AUD: 'A$', CAD: 'C$', JPY: '¥', BRL: 'R$', SGD: 'S$' };
            return (symbols[cur] || cur + ' ') + (parseFloat(amount) || 0).toFixed(2);
        };
        res.locals.currencySymbol = (currency) => {
            const cur = currency || globalSettings.defaultCurrency || 'USD';
            const symbols = { USD: '$', EUR: '€', GBP: '£', INR: '₹', AUD: 'A$', CAD: 'C$', JPY: '¥', BRL: 'R$', SGD: 'S$' };
            return symbols[cur] || cur + ' ';
        };
        next();
    });
}

module.exports = {
    getTemplateVars,
    setupTemplateGlobals
};
