const { dbGet } = require('../core/database');

async function isAuthorized(req, serverId) {
    if (!req.session || !req.session.user) return false;
    try {
        const server = await dbGet('SELECT owner_id FROM servers WHERE id = ?', [serverId]);
        if (!server) return false;

        if (req.session.user.role === 'admin' || server.owner_id === req.session.user.id) {
            return true;
        }

        const subuser = await dbGet(
            'SELECT * FROM subusers WHERE server_id = ? AND user_id = ?',
            [serverId, req.session.user.id]
        );
        return !!subuser;
    } catch (err) {
        return false;
    }
}

function requireAdmin(req, res, next) {
    if (!req.session.user) {
        const isApiRequest = req.xhr ||
            (req.headers.accept && req.headers.accept.toLowerCase().includes('application/json')) ||
            (req.headers['content-type'] && req.headers['content-type'].toLowerCase().includes('application/json')) ||
            req.path.startsWith('/api/');

        if (isApiRequest) {
            return res.status(401).json({ error: 'Authentication required' });
        }
        return res.redirect('/auth/login');
    }

    if (req.session.user.role !== 'admin') {
        const isApiRequest = req.xhr ||
            (req.headers.accept && req.headers.accept.toLowerCase().includes('application/json')) ||
            (req.headers['content-type'] && req.headers['content-type'].toLowerCase().includes('application/json')) ||
            req.path.startsWith('/api/');

        if (isApiRequest) {
            return res.status(403).json({ error: 'Admin privileges required' });
        }
        req.flash('error', 'Access denied. Admin privileges required.');
        return res.redirect('/dashboard');
    }
    next();
}

function requireAuth(req, res, next) {
    if (!req.session.user) {
        const isApiRequest = req.xhr ||
            (req.headers.accept && req.headers.accept.toLowerCase().includes('application/json')) ||
            (req.headers['content-type'] && req.headers['content-type'].toLowerCase().includes('application/json')) ||
            req.path.startsWith('/api/');

        if (isApiRequest) {
            return res.status(401).json({ error: 'Authentication required' });
        }
        return res.redirect('/auth/login');
    }
    next();
}

module.exports = {
    isAuthorized,
    requireAdmin,
    requireAuth
};
