const auth = require('./auth');
const template = require('./template');

module.exports = {
    ...auth,
    ...template
};
