const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const jwt = require('jsonwebtoken');

module.exports = (db, dbGet, dbAll, dbRun, globalSettings, serverProcesses, onlinePlayers, liveStats) => {
  // ================================================
  // API KEY AUTHENTICATION MIDDLEWARE
  // ================================================
  const authenticateAPIKey = async (req, res, next) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Unauthorized: No API key provided' });
      }

      const apiKey = authHeader.substring(7);
      const keyRecord = await dbGet('SELECT * FROM api_keys WHERE key = ? AND is_active = 1', [apiKey]);

      if (!keyRecord) {
        return res.status(401).json({ error: 'Unauthorized: Invalid API key' });
      }

      const user = await dbGet('SELECT * FROM users WHERE id = ?', [keyRecord.user_id]);
      if (!user) {
        return res.status(401).json({ error: 'Unauthorized: User not found' });
      }

      req.apiKey = keyRecord;
      req.user = user;
      req.permissions = JSON.parse(keyRecord.permissions || '["read"]');
      next();
    } catch (error) {
      console.error('API auth error:', error);
      return res.status(500).json({ error: 'Internal server error' });
    }
  };

  // ================================================
  // WINGS DAEMON AUTHENTICATION MIDDLEWARE
  // ================================================
  const authenticateDaemon = async (req, res, next) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Unauthorized' });
      }

      const token = authHeader.substring(7);
      let decoded;
      
      // First, try to find the node by daemon_token_id from the request or decoded JWT
      let node;
      
      // Try to decode JWT first to get the token ID
      try {
        const decodedHeader = jwt.decode(token, { complete: true });
        const keyId = decodedHeader?.header?.kid || decodedHeader?.payload?.jti;
        
        if (keyId) {
          node = await dbGet('SELECT * FROM nodes WHERE daemon_token_id = ?', [keyId]);
        }
      } catch (e) {
        // If decode fails, we'll try all nodes (fallback)
      }
      
      // If we didn't find the node from the header, try all nodes (less efficient but works)
      if (!node) {
        const allNodes = await dbAll('SELECT * FROM nodes');
        for (const n of allNodes) {
          try {
            jwt.verify(token, n.daemon_token);
            node = n;
            break;
          } catch (e) {
            continue;
          }
        }
      }
      
      if (!node) {
        return res.status(401).json({ error: 'Unauthorized' });
      }
      
      req.node = node;
      next();
    } catch (error) {
      console.error('Daemon auth error:', error);
      return res.status(500).json({ error: 'Internal server error' });
    }
  };

  // Check permission helper
  const hasPermission = (required) => {
    return (req, res, next) => {
      if (!req.permissions.includes(required) && !req.permissions.includes('*')) {
        return res.status(403).json({ error: 'Forbidden: Insufficient permissions' });
      }
      next();
    };
  };

  // ================================================
  // API ENDPOINTS
  // ================================================

  // Health check
  router.get('/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // ================================================
  // API KEY MANAGEMENT (requires admin)
  // ================================================
  router.post('/keys', authenticateAPIKey, hasPermission('admin'), async (req, res) => {
    try {
      const { name, user_id, permissions = ['read'] } = req.body;

      if (!name) {
        return res.status(400).json({ error: 'Name is required' });
      }

      const targetUserId = user_id || req.user.id;
      const newKey = 'mcpanel_' + uuidv4().replace(/-/g, '');

      await dbRun(
        'INSERT INTO api_keys (user_id, name, key, permissions) VALUES (?, ?, ?, ?)',
        [targetUserId, name, newKey, JSON.stringify(permissions)]
      );

      res.status(201).json({ key: newKey, name, permissions, user_id: targetUserId });
    } catch (error) {
      console.error('Create API key error:', error);
      res.status(500).json({ error: 'Failed to create API key' });
    }
  });

  router.get('/keys', authenticateAPIKey, hasPermission('admin'), async (req, res) => {
    try {
      const keys = await dbAll('SELECT id, user_id, name, permissions, is_active, created_at FROM api_keys');
      res.json({ keys });
    } catch (error) {
      console.error('Get API keys error:', error);
      res.status(500).json({ error: 'Failed to get API keys' });
    }
  });

  router.delete('/keys/:id', authenticateAPIKey, hasPermission('admin'), async (req, res) => {
    try {
      await dbRun('DELETE FROM api_keys WHERE id = ?', [req.params.id]);
      res.json({ success: true });
    } catch (error) {
      console.error('Delete API key error:', error);
      res.status(500).json({ error: 'Failed to delete API key' });
    }
  });

  // ================================================
  // SERVER ENDPOINTS
  // ================================================
  router.get('/servers', authenticateAPIKey, hasPermission('read'), async (req, res) => {
    try {
      let servers;
      if (req.user.role === 'admin') {
        servers = await dbAll('SELECT * FROM servers');
      } else {
        servers = await dbAll('SELECT * FROM servers WHERE owner_id = ?', [req.user.id]);
      }

      // Add live stats if available
      const serversWithStats = servers.map(server => ({
        ...server,
        stats: liveStats[server.id] || null
      }));

      res.json({ servers: serversWithStats });
    } catch (error) {
      console.error('Get servers error:', error);
      res.status(500).json({ error: 'Failed to get servers' });
    }
  });

  router.get('/servers/:id', authenticateAPIKey, hasPermission('read'), async (req, res) => {
    try {
      const serverId = req.params.id;
      let server;

      if (req.user.role === 'admin') {
        server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      } else {
        server = await dbGet('SELECT * FROM servers WHERE id = ? AND owner_id = ?', [serverId, req.user.id]);
      }

      if (!server) {
        return res.status(404).json({ error: 'Server not found' });
      }

      res.json({
        server,
        stats: liveStats[serverId] || null
      });
    } catch (error) {
      console.error('Get server error:', error);
      res.status(500).json({ error: 'Failed to get server' });
    }
  });

  // ================================================
  // USER ENDPOINTS (admin only)
  // ================================================
  router.get('/users', authenticateAPIKey, hasPermission('admin'), async (req, res) => {
    try {
      const users = await dbAll('SELECT id, username, email, role, status, created_at FROM users');
      res.json({ users });
    } catch (error) {
      console.error('Get users error:', error);
      res.status(500).json({ error: 'Failed to get users' });
    }
  });

  router.get('/users/:id', authenticateAPIKey, hasPermission('admin'), async (req, res) => {
    try {
      const user = await dbGet('SELECT id, username, email, role, status, created_at FROM users WHERE id = ?', [req.params.id]);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      res.json({ user });
    } catch (error) {
      console.error('Get user error:', error);
      res.status(500).json({ error: 'Failed to get user' });
    }
  });

  // ================================================
  // WINGS DAEMON API ENDPOINTS
  // ================================================

  // Get node configuration
  router.get('/wings/configuration', authenticateDaemon, async (req, res) => {
    try {
      // Get node with location
      const location = await dbGet('SELECT * FROM locations WHERE id = ?', [req.node.location_id]);
      
      const config = {
        debug: false,
        uuid: req.node.uuid,
        token_id: req.node.daemon_token_id,
        token: req.node.daemon_token,
        api: {
          host: '0.0.0.0',
          port: req.node.daemon_listen,
          ssl: {
            enabled: !req.node.behind_proxy && req.node.scheme === 'https',
            cert: `/etc/letsencrypt/live/${req.node.fqdn}/fullchain.pem`,
            key: `/etc/letsencrypt/live/${req.node.fqdn}/privkey.pem`
          },
          upload_limit: req.node.upload_size
        },
        system: {
          data: req.node.daemon_base,
          sftp: {
            bind_port: req.node.daemon_sftp
          }
        },
        allowed_mounts: [],
        remote: `${req.protocol}://${req.get('host')}`
      };

      res.json(config);
    } catch (error) {
      console.error('Get wings config error:', error);
      res.status(500).json({ error: 'Failed to get configuration' });
    }
  });

  // Get all servers for a node
  router.get('/wings/servers', authenticateDaemon, async (req, res) => {
    try {
      const servers = await dbAll('SELECT * FROM servers WHERE node_id = ?', [req.node.id]);
      
      // Convert to Wings format
      const wingsServers = await Promise.all(servers.map(async (server) => {
        // Get allocation for server
        let allocation = await dbGet('SELECT * FROM allocations WHERE server_id = ?', [server.id]);
        
        return {
          uuid: server.uuid || uuidv4().toString(),
          internal_id: server.id,
          settings: {},
          process_configuration: {},
          invocation: 'java -jar server.jar',
          skip_egg_scripts: false,
          container: {
            image: 'ghcr.io/pterodactyl/yolks:java_21'
          },
          allocations: {
            default: {
              ip: allocation ? allocation.ip : '127.0.0.1',
              port: allocation ? allocation.port : server.port,
              alias: allocation ? allocation.alias : (server.server_ip || null)
            },
            mappings: allocation ? { [allocation.ip]: [allocation.port] } : { '127.0.0.1': [server.port] }
          },
          build: {
            memory_limit: server.ram,
            swap: -1, // -1 = unlimited in Pterodactyl
            io_weight: 500,
            cpu_limit: (server.cpu || 2) * 100,
            disk_space: server.disk || 10240,
            threads: null,
            oom_disabled: false
          },
          labels: {},
          mounts: [],
          resources: {
            memory_bytes: 0,
            cpu_absolute: 0,
            disk_bytes: 0,
            network_rx_bytes: 0,
            network_tx_bytes: 0,
            uptime: 0
          },
          is_suspended: false,
          is_transferring: false
        };
      }));

      // Return paginated response (what Wings expects)
      res.json({
        data: wingsServers,
        meta: {
          current_page: 1,
          from: 1,
          last_page: 1,
          per_page: wingsServers.length,
          to: wingsServers.length,
          total: wingsServers.length
        }
      });
    } catch (error) {
      console.error('Get wings servers error:', error);
      res.status(500).json({ error: 'Failed to get servers' });
    }
  });

  // Get single server for node
  router.get('/wings/servers/:uuid', authenticateDaemon, async (req, res) => {
    try {
      const server = await dbGet('SELECT * FROM servers WHERE node_id = ? AND (uuid = ? OR id = ?)', [req.node.id, req.params.uuid, req.params.uuid]);
      
      if (!server) {
        return res.status(404).json({ error: 'Server not found' });
      }

      // Get allocation for server
      const allocation = await dbGet('SELECT * FROM allocations WHERE server_id = ?', [server.id]);

      // Convert to Wings format
      const wingsServer = {
        uuid: server.uuid || uuidv4().toString(),
        internal_id: server.id,
        settings: {},
        process_configuration: {},
        invocation: 'java -jar server.jar',
        skip_egg_scripts: false,
        container: {
          image: 'ghcr.io/pterodactyl/yolks:java_21'
        },
        allocations: {
          default: {
            ip: allocation ? allocation.ip : '127.0.0.1',
            port: allocation ? allocation.port : server.port,
            alias: allocation ? allocation.alias : (server.server_ip || null)
          },
          mappings: allocation ? { [allocation.ip]: [allocation.port] } : { '127.0.0.1': [server.port] }
        },
        build: {
          memory_limit: server.ram,
          swap: -1, // -1 = unlimited in Pterodactyl
          io_weight: 500,
          cpu_limit: (server.cpu || 2) * 100,
          disk_space: server.disk || 10240,
          threads: null,
          oom_disabled: false
        },
        labels: {},
        mounts: [],
        resources: {
          memory_bytes: 0,
          cpu_absolute: 0,
          disk_bytes: 0,
          network_rx_bytes: 0,
          network_tx_bytes: 0,
          uptime: 0
        },
        is_suspended: false,
        is_transferring: false
      };

      res.json(wingsServer);
    } catch (error) {
      console.error('Get wings server error:', error);
      res.status(500).json({ error: 'Failed to get server' });
    }
  });

  // Update server state
  router.post('/wings/servers/:uuid', authenticateDaemon, async (req, res) => {
    try {
      res.status(204).send();
    } catch (error) {
      console.error('Update wings server error:', error);
      res.status(500).json({ error: 'Failed to update server' });
    }
  });

  // Get allocations
  router.get('/wings/servers/:uuid/allocations', authenticateDaemon, async (req, res) => {
    try {
      res.json([]);
    } catch (error) {
      console.error('Get allocations error:', error);
      res.status(500).json({ error: 'Failed to get allocations' });
    }
  });

  // Update server power state
  router.post('/wings/servers/:uuid/power', authenticateDaemon, async (req, res) => {
    try {
      res.status(204).send();
    } catch (error) {
      console.error('Update power state error:', error);
      res.status(500).json({ error: 'Failed to update power state' });
    }
  });

  // Send command to server
  router.post('/wings/servers/:uuid/commands', authenticateDaemon, async (req, res) => {
    try {
      res.status(204).send();
    } catch (error) {
      console.error('Send command error:', error);
      res.status(500).json({ error: 'Failed to send command' });
    }
  });

  // Heartbeat endpoint
  router.post('/wings/heartbeat', authenticateDaemon, async (req, res) => {
    try {
      const now = new Date().toISOString();
      const stats = JSON.stringify(req.body || {});
      const daemonIp = req.ip || req.connection?.remoteAddress || 'unknown';
      
      await dbRun(
        'UPDATE nodes SET last_heartbeat = ?, stats = ?, daemon_ip = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [now, stats, daemonIp, req.node.id]
      );
      
      // Check for node-level pending commands (restart/stop daemon)
      let command = null;
      if (req.node.pending_command) {
        command = req.node.pending_command;
        await dbRun('UPDATE nodes SET pending_command = NULL WHERE id = ?', [req.node.id]);
      }
      
      // Check for pending server commands
      const pendingServerCommands = await dbAll(
        "SELECT * FROM server_commands WHERE node_id = ? AND status = 'pending' ORDER BY created_at ASC LIMIT 50",
        [req.node.id]
      );
      if (pendingServerCommands.length > 0) {
        const ids = pendingServerCommands.map(c => c.id);
        await dbRun(
          `UPDATE server_commands SET status = 'delivered' WHERE id IN (${ids.join(',')})`
        );
      }
      
      // Process server status reports from daemon
      const body = typeof req.body === 'object' && req.body ? req.body : {};
      if (body.server_statuses && Array.isArray(body.server_statuses)) {
        for (const report of body.server_statuses) {
          const newStatus = report.running ? 'running' : 'stopped';
          await dbRun('UPDATE servers SET status = ? WHERE id = ? AND node_id = ?',
            [newStatus, report.server_id, req.node.id]);
        }
      }
      
      res.json({
        status: 'ok',
        command: command,
        server_commands: pendingServerCommands.map(c => ({
          id: c.id,
          server_id: c.server_id,
          action: c.action
        }))
      });
    } catch (error) {
      console.error('Heartbeat error:', error);
      res.status(500).json({ error: 'Failed to process heartbeat' });
    }
  });

  // Get backups
  router.get('/wings/servers/:uuid/backups', authenticateDaemon, async (req, res) => {
    try {
      const server = await dbGet('SELECT * FROM servers WHERE node_id = ? AND (uuid = ? OR id = ?)', [req.node.id, req.params.uuid, req.params.uuid]);
      if (!server) {
        return res.status(404).json({ error: 'Server not found' });
      }
      
      const backups = await dbAll('SELECT * FROM backups WHERE server_id = ?', [server.id]);
      
      const wingsBackups = backups.map(backup => ({
        uuid: backup.uuid || uuidv4().toString(),
        name: backup.name || 'Backup',
        ignored_files: [],
        checksum: null,
        disk_size: parseInt(backup.size || 0),
        created_at: backup.created_at,
        completed_at: backup.created_at,
        is_successful: true,
        is_locked: false
      }));
      
      res.json(wingsBackups);
    } catch (error) {
      console.error('Get backups error:', error);
      res.status(500).json({ error: 'Failed to get backups' });
    }
  });

  return router;
};
