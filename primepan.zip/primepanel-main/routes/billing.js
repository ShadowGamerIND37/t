const express = require('express');
const router = express.Router();

// This router is intentionally minimal - all billing routes are defined directly in app.js
module.exports = router;
