const fs = require('fs');
const { execSync } = require('child_process');
const { v4: uuidv4 } = require('uuid');

console.log('========================================');
console.log('PMS Panel Auto-Installer');
console.log('========================================\n');

// Check if we already have a .env file
if (fs.existsSync('.env')) {
  console.log('.env file already exists! Skipping env setup.');
} else {
  console.log('Creating .env file...');
  const sessionSecret = uuidv4();
  const envContent = `# PMS Panel Configuration
PORT=3000
NODE_ENV=production
SESSION_SECRET=${sessionSecret}
`;
  fs.writeFileSync('.env', envContent);
  console.log('✓ .env file created successfully!');
}

// Check if database exists
const dbPath = './database.db';
if (fs.existsSync(dbPath)) {
  console.log('database.db already exists! Skipping database setup.');
} else {
  console.log('Initializing database...');
  // Run init-database.js
  try {
    const initDbPath = './init-database.js';
    if (fs.existsSync(initDbPath)) {
      require(initDbPath);
      console.log('✓ Database initialized successfully!');
    } else {
      console.warn('Warning: init-database.js not found!');
    }
  } catch (err) {
    console.error('Error initializing database:', err);
  }
}

console.log('\n========================================');
console.log('Installation complete!');
console.log('========================================');
console.log('To start the panel, run:');
console.log('  npm start');
console.log('========================================');
