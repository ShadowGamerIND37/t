// ================================================
// PMS - Panel Management System
// Modular entry point for the Minecraft Server Panel
// ================================================

const express = require('express');
const session = require('express-session');
const flash = require('connect-flash');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');
const fs = require('fs');
const os = require('os');

// ================================================
// BACKEND MODULES
// ================================================
const config = require('./backend/config');
const { initDatabase, db, dbGet, dbAll, dbRun } = require('./backend/core/database');
const helpers = require('./backend/core/helpers');
const versions = require('./backend/core/versions');
const serverLifecycle = require('./backend/services/server/lifecycle');
const serverStats = require('./backend/services/server/stats');
const serverLog = require('./backend/services/server/log');
const serverDownload = require('./backend/services/server/download');
const serverPort = require('./backend/services/server/port');
const notificationService = require('./backend/services/notification');
const activityService = require('./backend/services/activity');
const pluginSearch = require('./backend/services/plugin/search');
const wingsService = require('./backend/services/wings/node');
const licenseService = require('./backend/services/license');
const { requireAuth, requireAdmin, isAuthorized } = require('./backend/middleware/auth');
const { getTemplateVars, setupTemplateGlobals } = require('./backend/middleware/template');

// ================================================
// EXPRESS SETUP
// ================================================
const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// ================================================
// SHARED STATE
// ================================================
const globalSettings = { ...config.globalSettings };
const liveStats = {};

// Expose globalSettings on app.locals
app.locals.globalSettings = globalSettings;

// Progress tracking (shared between admin and server routes)
const installProgress = {};
const deleteProgress = {};
const reinstallProgress = {};
function setInstallProgress(sId, step, pct, done, error) {
    if (done === undefined) done = false;
    if (error === undefined) error = null;
    installProgress[sId] = { step, percent: pct, done, error };
    io.to(`install:${sId}`).emit('install-progress', { step, percent: pct, done, error });
}
function setDeleteProgress(sId, step, pct, done, error) {
    if (done === undefined) done = false;
    if (error === undefined) error = null;
    deleteProgress[sId] = { step, percent: pct, done, error };
    io.to(`delete:${sId}`).emit('delete-progress', { step, percent: pct, done, error });
}
function setReinstallProgress(sId, step, pct, done, error) {
    if (done === undefined) done = false;
    if (error === undefined) error = null;
    reinstallProgress[sId] = { step, percent: pct, done, error };
    io.to(`reinstall:${sId}`).emit('reinstall-progress', { step, percent: pct, done, error });
}

// ================================================
// SHARED DEPS OBJECT
// ================================================
const deps = {
    // Core
    db, dbGet, dbAll, dbRun,
    globalSettings, liveStats,
    
    // Server process tracking (shared reference to lifecycle module's internal state)
    serverProcesses: serverLifecycle.getServerProcesses(),
    onlinePlayers: serverLifecycle.getOnlinePlayers(),
    serverStartTimes: serverLifecycle.getServerStartTimes(),
    
    // Progress tracking (shared)
    installProgress, deleteProgress, reinstallProgress,
    setInstallProgress, setDeleteProgress, setReinstallProgress,
    
    // Middleware
    requireAuth, requireAdmin, isAuthorized,
    getTemplateVars,
    
    // Paths
    DATA_DIR: config.DATA_DIR,
    SERVERS_DIR: config.SERVERS_DIR,
    DB_PATH: config.DB_PATH,
    APP_DIR: __dirname,
    
    // Server lifecycle
    isServerRunning: serverLifecycle.isServerRunning,
    isProcessRunning: serverLifecycle.isProcessRunning,
    isJavaProcess: serverLifecycle.isJavaProcess,
    getPidByPort: serverLifecycle.getPidByPort,
    startServer: serverLifecycle.startServer,
    stopServer: serverLifecycle.stopServer,
    restartServer: serverLifecycle.restartServer,
    sendCommand: serverLifecycle.sendCommand,
    executeCommand: serverLifecycle.executeCommand,
    checkAndAcceptEula: serverLifecycle.checkAndAcceptEula,
    transferServer: serverLifecycle.transferServer,
    autoEnableRcon: serverLifecycle.autoEnableRcon,
    loadServerStartTime: serverLifecycle.loadServerStartTime,
    saveServerStartTime: serverLifecycle.saveServerStartTime,
    deleteServerStartTime: serverLifecycle.deleteServerStartTime,
    
    // Stats
    updateLiveStats: serverStats.updateLiveStats,
    startMonitoring: serverStats.startMonitoring,
    
    // Logs
    startLogTail: serverLog.startLogTail,
    processLogLine: serverLog.processLogLine,
    
    // Downloads
    downloadServerJar: serverDownload.downloadServerJar,
    downloadPluginJar: serverDownload.downloadPluginJar,
    getInstalledPlugins: serverDownload.getInstalledPlugins,
    
    // Port management
    findAvailablePortForServerType: serverPort.findAvailablePortForServerType,
    isPortAvailable: serverPort.isPortAvailable,
    ensureServerPortForType: serverPort.ensureServerPortForType,
    updateServerConfigurationPort: serverPort.updateServerConfigurationPort,
    getPortInformation: serverPort.getPortInformation,
    validateAndFixAllServerPorts: serverPort.validateAndFixAllServerPorts,
    
    // Notifications
    createNotification: notificationService.createNotification,
    getNotificationsPaginated: notificationService.getNotificationsPaginated,
    markNotificationAsRead: notificationService.markNotificationAsRead,
    markAllNotificationsAsRead: notificationService.markAllNotificationsAsRead,
    clearAllNotifications: notificationService.clearAllNotifications,
    getUnreadNotificationCount: notificationService.getUnreadNotificationCount,
    getNotificationStats: notificationService.getNotificationStats,
    
    // Activity
    logServerActivity: activityService.logServerActivity,
    
    // Plugin search
    searchPlugins: pluginSearch.searchPlugins,
    getModrinthVersions: pluginSearch.getModrinthVersions,
    getSpigetVersions: pluginSearch.getSpigetVersions,
    getHangarVersions: pluginSearch.getHangarVersions,
    getBukkitVersions: pluginSearch.getBukkitVersions,
    getModrinthDownloadUrl: pluginSearch.getModrinthDownloadUrl,
    getSpigetDownloadUrl: pluginSearch.getSpigetDownloadUrl,
    getHangarDownloadUrl: pluginSearch.getHangarDownloadUrl,
    getBukkitDownloadUrl: pluginSearch.getBukkitDownloadUrl,
    
    // Wings
    generateRandomToken: wingsService.generateRandomToken,
    createNodeJWT: wingsService.createNodeJWT,
    getNodeConnectionAddress: wingsService.getNodeConnectionAddress,
    wingsRequest: wingsService.wingsRequest,
    
    // Helpers
    resolveServerPath: helpers.resolveServerPath,
    formatFileSize: helpers.formatFileSize,
    parseProperties: helpers.parseProperties,
    writeProperties: helpers.writeProperties,
    writePropertiesString: helpers.writePropertiesString,
    getDirSize: helpers.getDirSize,
    generateRandomToken: helpers.generateRandomToken,
    generateRandomSecret: helpers.generateRandomSecret,
    
    // Versions
    fetchMinecraftVersions: versions.fetchMinecraftVersions,
    compareVersions: versions.compareVersions,
    isValidMinecraftVersion: versions.isValidMinecraftVersion,
    getAvailableServerSoftware: versions.getAvailableServerSoftware,
    getCompleteMinecraftVersions: versions.getCompleteMinecraftVersions,
    
    // Socket.IO
    io,
    
    // License
    validateLicenseKey: licenseService.validateLicenseKey,
    isLicenseManagerReachable: licenseService.isLicenseManagerReachable
};

// ================================================
// DATABASE INITIALIZATION
// ================================================
initDatabase(globalSettings, app).then(() => {
    console.log('Database initialized successfully');
}).catch(err => {
    console.error('Database initialization failed:', err);
    process.exit(1);
});

// ================================================
// MIDDLEWARE
// ================================================
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Session
app.use(session({
    secret: process.env.SESSION_SECRET || 'your-secret-key-change-this',
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: false,
        maxAge: 24 * 60 * 60 * 1000
    }
}));

// Flash messages
app.use(flash());
app.use((req, res, next) => {
    res.locals.messages = req.flash();
    next();
});

// View engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Global template variables
app.use((req, res, next) => {
    res.locals.user = req.session.user || null;
    res.locals.settings = globalSettings;
    res.locals.formatCurrency = (amount, currency) => {
        const cur = currency || globalSettings.defaultCurrency || 'USD';
        const symbols = {USD:'$',EUR:'€',GBP:'£',INR:'₹',AUD:'A$',CAD:'C$',JPY:'¥',BRL:'R$',SGD:'S$'};
        return (symbols[cur]||cur+' ') + (parseFloat(amount)||0).toFixed(2);
    };
    res.locals.currencySymbol = (currency) => {
        const cur = currency || globalSettings.defaultCurrency || 'USD';
        const symbols = {USD:'$',EUR:'€',GBP:'£',INR:'₹',AUD:'A$',CAD:'C$',JPY:'¥',BRL:'R$',SGD:'S$'};
        return symbols[cur]||cur+' ';
    };
    next();
});

// License check middleware
app.use((req, res, next) => {
    const publicRoutes = ['/activate-license', '/auth', '/api', '/maintenance', '/css', '/js', '/favicon.ico'];
    const isPublicRoute = publicRoutes.some(route => req.path.startsWith(route));
    if (!isPublicRoute && !globalSettings.licenseActivated) {
        return res.redirect('/activate-license');
    }
    next();
});

// ================================================
// MOUNT ROUTE MODULES
// ================================================
require('./backend/routes/auth-main')(app, deps);
require('./backend/routes/profile-notifications')(app, deps);
require('./backend/routes/servers')(app, deps);
require('./backend/routes/admin')(app, deps);

// Mount existing API router
const apiRouter = require('./routes/api');
app.use('/api', apiRouter(db, dbGet, dbAll, dbRun, globalSettings, deps.serverProcesses, deps.onlinePlayers, liveStats));

// ================================================
// SOCKET.IO
// ================================================
io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);
    
    socket.on('join-install', (sId) => {
        socket.join(`install:${sId}`);
        if (installProgress[sId]) socket.emit('install-progress', installProgress[sId]);
    });
    socket.on('join-delete', (sId) => {
        socket.join(`delete:${sId}`);
        if (deleteProgress[sId]) socket.emit('delete-progress', deleteProgress[sId]);
    });
    socket.on('join-reinstall', (sId) => {
        socket.join(`reinstall:${sId}`);
        if (reinstallProgress[sId]) socket.emit('reinstall-progress', reinstallProgress[sId]);
    });
    
    socket.on('subscribe', (serverId) => {
        socket.join(`server:${serverId}`);
        console.log(`Socket ${socket.id} subscribed to server ${serverId}`);
    });
    
    socket.on('unsubscribe', (serverId) => {
        socket.leave(`server:${serverId}`);
        console.log(`Socket ${socket.id} unsubscribed from server ${serverId}`);
    });
    
    socket.on('disconnect', () => {
        console.log('Client disconnected:', socket.id);
    });
});

// ================================================
// 404 HANDLER
// ================================================
app.use(async (req, res) => {
    res.status(404).render('error', await getTemplateVars(req, null, {
        message: 'Page not found',
        status: 404,
        title: 'Error'
    }));
});

// ================================================
// ERROR HANDLER
// ================================================
app.use(async (err, req, res, next) => {
    console.error('Server error:', err);
    res.status(500).render('error', await getTemplateVars(req, null, {
        message: 'Internal server error',
        status: 500,
        error: process.env.NODE_ENV === 'development' ? err : null,
        title: 'Error'
    }));
});

// ================================================
// RECONNECT TO RUNNING SERVERS ON STARTUP
// ================================================
async function reconnectToRunningServers() {
    console.log('Checking for running servers...');
    try {
        const servers = await dbAll('SELECT * FROM servers');
        for (const server of servers) {
            const serverId = server.id;
            const serverDir = helpers.resolveServerPath(serverId);
            const pidFile = path.join(serverDir, '.server.pid');
            
            if (fs.existsSync(pidFile)) {
                try {
                    const pid = parseInt(fs.readFileSync(pidFile, 'utf8').trim());
                    if (serverLifecycle.isProcessRunning(pid)) {
                        console.log(`Found running server ${serverId} (PID: ${pid})`);
                        await dbRun('UPDATE servers SET status = ? WHERE id = ?', ['running', serverId]);
                        
                        if (!global.serverProcesses) {
                            global.serverProcesses = {};
                        }
                        
                        const pseudoProcess = {
                            pid: pid,
                            killed: false,
                            stdin: null,
                            on: () => {},
                            kill: (signal) => {
                                try {
                                    process.kill(pid, signal || 'SIGTERM');
                                    return true;
                                } catch (err) {
                                    console.error(`Failed to kill process ${pid}:`, err);
                                    return false;
                                }
                            }
                        };
                        global.serverProcesses[serverId] = pseudoProcess;
                        
                        if (!onlinePlayers[serverId]) {
                            onlinePlayers[serverId] = [];
                        }
                        
                        const savedStartTime = serverLifecycle.loadServerStartTime(serverId);
                        if (savedStartTime) {
                            serverStartTimes[serverId] = savedStartTime;
                        } else {
                            serverStartTimes[serverId] = Date.now();
                        }
                        
                        serverLog.startLogTail(serverId);
                        console.log(`Reconnected to server ${serverId}`);
                    } else {
                        console.log(`Server ${serverId} PID file exists but process not running, cleaning up`);
                        fs.unlinkSync(pidFile);
                        serverLifecycle.deleteServerStartTime(serverId);
                        await dbRun('UPDATE servers SET status = ? WHERE id = ?', ['stopped', serverId]);
                    }
                } catch (err) {
                    console.error(`Error reconnecting to server ${serverId}:`, err);
                    try {
                        if (fs.existsSync(pidFile)) fs.unlinkSync(pidFile);
                    } catch (e) {}
                    await dbRun('UPDATE servers SET status = ? WHERE id = ?', ['stopped', serverId]);
                }
            } else {
                if (server.status !== 'stopped') {
                    await dbRun('UPDATE servers SET status = ? WHERE id = ?', ['stopped', serverId]);
                }
            }
        }
        console.log('Server reconnection check complete');
    } catch (err) {
        console.error('Error during server reconnection:', err);
    }
}

// ================================================
// START SERVER
// ================================================
const PORT = process.env.PORT || 3000;

server.listen(PORT, async () => {
    console.log(`PMS Panel running on http://localhost:${PORT}`);
    console.log(`Admin login: admin / admin123`);
    
    // Ensure default Local location and Local Node exist
    try {
        let loc = await dbGet("SELECT id FROM locations WHERE short = 'local' OR name = 'Local' LIMIT 1");
        if (!loc) {
            console.log('Creating default Local location...');
            const result = await dbRun(
                `INSERT INTO locations (name, description, short) VALUES (?, ?, ?)`,
                ['Local', 'Default local location', 'local']
            );
            loc = { id: result.lastID };
        }
        
        const localNode = await dbGet("SELECT id FROM nodes WHERE mode = 'local' LIMIT 1");
        if (!localNode) {
            console.log('Creating default Local Node...');
            const { v4: uuidv4 } = require('uuid');
            const tokenId = require('crypto').randomBytes(16).toString('hex');
            const token = require('crypto').randomBytes(64).toString('hex');
            await dbRun(
                `INSERT INTO nodes (uuid, name, description, location_id, fqdn, scheme, memory, disk, daemon_token_id, daemon_token, mode)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [uuidv4(), 'Local Node', 'Default local node',
                 loc.id, 'localhost', 'http', 10240, 102400, tokenId, token, 'local']
            );
        }
    } catch (e) {
        console.error('Error seeding local location/node:', e.message);
    }
    
    // Reconnect to running servers
    await reconnectToRunningServers();
    
    console.log('PMS Panel ready');
    
    // Periodic status check every 30 seconds
    setInterval(async () => {
        try {
            const servers = await dbAll('SELECT * FROM servers');
            for (const srv of servers) {
                const serverId = srv.id;
                const running = await serverLifecycle.isServerRunning(serverId);
                const dbStatus = srv.status;
                
                if (running && dbStatus === 'stopped') {
                    await dbRun('UPDATE servers SET status = ? WHERE id = ?', ['running', serverId]);
                    if (!onlinePlayers[serverId]) onlinePlayers[serverId] = [];
                    if (!serverStartTimes[serverId]) serverStartTimes[serverId] = Date.now();
                    if (!serverLogWatchers[serverId]) serverLog.startLogTail(serverId);
                } else if (!running && (dbStatus === 'running' || dbStatus === 'starting')) {
                    await dbRun('UPDATE servers SET status = ? WHERE id = ?', ['stopped', serverId]);
                    delete serverStartTimes[serverId];
                    onlinePlayers[serverId] = [];
                    if (serverLogWatchers[serverId]) {
                        serverLogWatchers[serverId].close();
                        delete serverLogWatchers[serverId];
                    }
                }
            }
        } catch (err) {
            console.error('Error in periodic status check:', err);
        }
    }, 30000);
});

// ================================================
// GRACEFUL SHUTDOWN
// ================================================
process.on('SIGINT', () => {
    console.log('Shutting down panel...');
    console.log('Servers will continue running in background');
    
    if (global.serverProcesses) {
        Object.keys(global.serverProcesses).forEach(serverId => {
            const proc = global.serverProcesses[serverId];
            if (proc && !proc.killed) {
                if (typeof proc.unref === 'function') {
                    proc.unref();
                }
            }
        });
    }
    
    db.close((err) => {
        if (err) console.error('Error closing database:', err);
        else console.log('Database closed');
        console.log('Panel stopped. Servers are still running.');
        process.exit(0);
    });
});

module.exports = { app, server, deps };
