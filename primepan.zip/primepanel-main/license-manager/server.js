// ================================================
// License Manager - Mock Server
// Run: node license-manager/server.js
// Replace this file with your actual license manager
// ================================================

const express = require('express');
const app = express();
app.use(express.json());

const PORT = process.env.LM_PORT || 3001;
const VALID_API_KEY = process.env.LICENSE_API_KEY || 'd39c4f0d68b8312a87f79bf5f01f102fe91631f17f293232b5adbe905449c6b6';

// In-memory valid license keys (replace with your DB)
const validKeys = new Set([
    'DEMO-LICENSE-2024-ABCD',
    'PREMIUM-1234-5678-9012'
]);

// Auth middleware
function authenticate(req, res, next) {
    const auth = req.headers.authorization;
    if (!auth || !auth.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Missing or invalid Authorization header' });
    }
    const token = auth.slice(7);
    if (token !== VALID_API_KEY) {
        return res.status(401).json({ error: 'Invalid API key' });
    }
    next();
}

// Health check
app.get('/api/license-manager/status', authenticate, (req, res) => {
    res.json({ status: 'online', version: '1.0.0' });
});

// Validate a license key
app.post('/api/license-manager/validate', authenticate, (req, res) => {
    const { key } = req.body;

    if (!key || !key.trim()) {
        return res.json({ valid: false, message: 'License key is required' });
    }

    const trimmedKey = key.trim();

    if (validKeys.has(trimmedKey)) {
        console.log(`License validated: ${trimmedKey}`);
        return res.json({
            valid: true,
            message: 'License is valid',
            data: {
                key: trimmedKey,
                plan: 'premium',
                expiresAt: '2026-12-31',
                maxServers: 10
            }
        });
    }

    console.log(`Invalid license attempt: ${trimmedKey}`);
    return res.json({
        valid: false,
        message: 'Invalid license key'
    });
});

// List all valid keys (admin endpoint)
app.get('/api/license-manager/keys', authenticate, (req, res) => {
    res.json({ keys: Array.from(validKeys) });
});

app.listen(PORT, () => {
    console.log(`License Manager running on http://localhost:${PORT}`);
    console.log(`API Key: ${VALID_API_KEY}`);
    console.log(`Valid demo keys: ${Array.from(validKeys).join(', ')}`);
});
