const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');

function initializeBillingDatabase() {
    const db = new sqlite3.Database('./database.db');
    
    console.log('Initializing billing & hosting features database...');
    
    const schemaSQL = fs.readFileSync(path.join(__dirname, 'database-billing.sql'), 'utf8');
    const statements = schemaSQL.split(';').filter(stmt => stmt.trim().length > 0);
    
    db.serialize(() => {
        let successCount = 0;
        
        statements.forEach((statement, index) => {
            const trimmedStatement = statement.trim();
            if (trimmedStatement) {
                db.run(trimmedStatement, function(err) {
                    if (err) {
                        if (!err.message.includes('already exists')) {
                            console.error(`Error executing statement ${index + 1}:`, err.message);
                        }
                    } else {
                        successCount++;
                        console.log(`✓ Executed statement ${index + 1}`);
                    }
                });
            }
        });
        
        // Insert default company settings
        const defaultSettings = [
            { key: 'company_name', value: 'MC Hosting' },
            { key: 'company_email', value: 'support@example.com' },
            { key: 'company_address', value: '123 Main Street' },
            { key: 'currency', value: 'USD' }
        ];
        
        defaultSettings.forEach(setting => {
            db.run(`INSERT OR IGNORE INTO company_settings (key, value) VALUES (?, ?)`, 
                [setting.key, setting.value], (err) => {
                    if (!err) {
                        console.log(`✓ Added company setting: ${setting.key}`);
                    }
                }
            );
        });
        
        // Create wallets for existing users
        db.all('SELECT id FROM users', [], (err, users) => {
            if (err) {
                console.error('Error fetching users:', err.message);
                return;
            }
            
            users.forEach(user => {
                db.run('INSERT OR IGNORE INTO wallets (user_id, balance) VALUES (?, 0)', [user.id], (err) => {
                    if (!err) {
                        console.log(`✓ Created wallet for user ${user.id}`);
                    }
                });
            });
        });
        
        console.log(`\nBilling database initialization complete!`);
    });
    
    db.close((err) => {
        if (err) {
            console.error('Error closing database:', err.message);
        }
    });
}

if (require.main === module) {
    initializeBillingDatabase();
}

module.exports = { initializeBillingDatabase };
